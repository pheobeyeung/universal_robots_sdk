package com.ur.urcap.examples.userinput.impl;

import java.awt.*;

public class V3Style extends Style {
	private static final Dimension INPUTFIELD_SIZE = new Dimension(200, 24);

	@Override
	public Dimension getInputfieldDimension() {
		return INPUTFIELD_SIZE;
	}
}
