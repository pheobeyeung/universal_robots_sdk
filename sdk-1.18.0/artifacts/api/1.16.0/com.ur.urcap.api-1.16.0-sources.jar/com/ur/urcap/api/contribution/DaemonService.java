/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import java.net.URL;

/**
 * Defines an API that makes it possible to define daemons of a URCap within PolyScope.
 *
 * @since 1.0.0
 */
public interface DaemonService {
	/**
	 * This method is called from PolyScope when the daemon service is registered by
	 * PolyScope. The {@link DaemonContribution} object control is set by PolyScope. The object can be used to install,
	 * start, stop, and monitor the registered daemon.
	 *
	 * @param daemon - object that is used to install, control, and monitor the registered daemon.
	 */
	void init(DaemonContribution daemon);

	/**
	 * Implement this method so that it returns an URL to the daemon executable resource inside the jar
	 * that contains the implementation of DaemonService.
	 *
	 * @return Path to the daemon (an executable) as an URL.
	 */
	URL getExecutable();
}
