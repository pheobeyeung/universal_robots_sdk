/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 *  API for installation node contributions.
 *
 * 	@since 1.0.0
 */
public interface InstallationNodeContribution {
	/**
	 * Called each time the end user opens this URCap contribution in the Installation Tab.
	 */
	void openView();

	/**
	 * Called each time the end user exits this URCap contribution in the Installation Tab.
	 */
	void closeView();

	/**
	 * Defines script code that is added to the beginning of the script code executed when a program is launched.
	 *
	 * @param writer serves to add script commands to program script code preamble.
	 */
	void generateScript(ScriptWriter writer);
}
