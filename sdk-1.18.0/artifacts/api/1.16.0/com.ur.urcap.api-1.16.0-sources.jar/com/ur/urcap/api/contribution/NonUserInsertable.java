/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.domain.program.nodes.ProgramNodeFactory;


/**
 * <p>
 * This interface is a marker interface that can be used in combination with {@link ProgramNodeService}.
 * </p>
 *
 * <p>
 * If an implementation of {@link ProgramNodeService} also implements {@link NonUserInsertable}, the
 * {@link ProgramNodeContribution} offered by the given service will not appear on the URCap sub tab of the Program tab
 * in PolyScope, and can not be inserted in the program tree by the end user. It can only be inserted programmatically
 * using the {@link ProgramNodeFactory}. This also means, it can not be inserted using copy/paste of that node directly.
 * It can however be inserted by copy/paste of an ancestor of such a node.
 * </p>
 *
 * <b>NOTE:</b> This interface is only relevant for URCaps with a HTML-based userinterface.
 *
 * @since 1.1.0
 */
public interface NonUserInsertable {

}
