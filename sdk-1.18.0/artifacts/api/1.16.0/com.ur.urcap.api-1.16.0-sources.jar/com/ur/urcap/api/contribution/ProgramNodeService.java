/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;

import java.io.InputStream;


/**
 * Defines an API required for adding a new type of program node to PolyScope.
 *
 * @since 1.0.0
 */
public interface ProgramNodeService extends URCapProgramNodeService {

	/**
	 * Get the unique identifier for this kind of program node. The identifier will be used when storing programs that
	 * use the program node.
	 *
	 * @return the unique identifier.
	 */
	String getId();

	/**
	 * By returning {@code true} it is not possible for the user to create new program nodes of this type.
	 * Loading of existing programs will however still be supported for this program node.<br>
	 *
	 * <b>NOTE</b>: This method is only called once when the URCap is activated and never called again afterwards.
	 *
	 * @return {@code true} if deprecated, {@code false} otherwise.
	 */
	boolean isDeprecated();

	/**
	 * By returning {@code true} it is possible for the program node to have child nodes.<br>
	 *
	 * <b>NOTE</b>: This method is only called once when the URCap is activated and never called again afterwards.
	 *
	 * @return {@code true} if children are allowed, {@code false} otherwise.
	 */
	boolean isChildrenAllowed();

	/**
	 *
	 * @return The text displayed in the Structure Tab for program nodes created by this factory.
	 */
	String getTitle();

	/**
	 *
	 * @return Return an input stream with the HTML contents of the node.
	 */
	InputStream getHTML();

	/**
	 *
	 * <p>
	 * Creates a new program node contribution instance.
	 * </p>
	 *
	 * <p>
	 * The returned node must use the supplied data model object to retrieve and store the data contained in it.
	 * All modifications to the supplied data model from the program node constructor are ignored when an existing program
	 * node is loaded or copy/pasted. Every change to the model object is registered as a separate undo/redo event in
	 * the program tree.
	 * </p>
	 *
	 * @param api the URCap API object with access to domain data
	 * @param model object where all configuration data of the new program node
	 * instance is to be stored in and retrieved from
	 * @return the newly constructed program node contribution instance
	 */
	ProgramNodeContribution createNode(URCapAPI api, DataModel model);
}
