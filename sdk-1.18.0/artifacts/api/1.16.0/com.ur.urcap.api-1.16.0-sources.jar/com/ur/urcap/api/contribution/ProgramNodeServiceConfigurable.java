/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;


/**
 * This interface can be used in combination with the {@link ProgramNodeService} interface. If an implementation of
 * {@link ProgramNodeService} also implements the {@link ProgramNodeServiceConfigurable} interface, additional properties
 * for the program node contribution can be configured.
 *
 * <p>
 * <b>NOTE:</b> This interface is only relevant to URCap program nodes with a HTML-based user interface
 * </p>
 *
 * @since 1.5.0
 */
public interface ProgramNodeServiceConfigurable {

	/**
	 * <p>
	 * This method is called once after the {@link ProgramNodeService} is registered. Modify the configuration parameter
	 * to configure your contribution. The configuration object will already have default values for its properties
	 * matching most use cases.
	 * </p>
	 *
	 * <p>
	 * The values of this object will be read once immediately after this method call. Changing values at a later stage
	 * will have no effect, so do not store a reference to the configuration object.<br>
	 * </p>
	 *
	 * If the default values are appropriate, leave this method empty.
	 *
	 * @param configuration A modifiable {@link ProgramNodeConfiguration} object with default values
	 */
	void configureContribution(ProgramNodeConfiguration configuration);
}
