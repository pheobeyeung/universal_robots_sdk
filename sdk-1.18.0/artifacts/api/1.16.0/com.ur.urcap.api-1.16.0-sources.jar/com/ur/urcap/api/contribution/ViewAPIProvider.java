/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.UserInterfaceAPI;


/**
 * <p>
 * Provides access to functionality relevant for the View (UI) of an installation or a program node
 * contribution.
 * </p>
 *
 * <b>NOTE:</b> This interface is not relevant for URCap program and installation nodes with a HTML-based user interface.
 *
 * @since 1.3.0
 */
public interface ViewAPIProvider {

	/**
	 * Provides access to system related functionality.
	 *
	 * @return an instance of SystemAPI.
	 */
	SystemAPI getSystemAPI();

	/**
	 * Provides access to functionality related to user interface and user interaction.
	 *
	 * @return an instance of UserInterfaceAPI.
	 */
	UserInterfaceAPI getUserInterfaceAPI();
}
