/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.tcp;

import com.ur.urcap.api.domain.tcp.IllegalTCPNameException;
import com.ur.urcap.api.domain.tcp.TCP;
import com.ur.urcap.api.domain.value.Pose;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * With this interface, it it possible to add a TCP for a device to PolyScope as well as update the TCP's offset and
 * remove the TCP again.
 * </p>
 *
 * <b>Note:</b> Any attempts to overwrite (calling the {@link #setTCP(String, Pose)} method when a TCP has already been
 * added), remove or update an existing TCP are ignored when an existing installation is loaded. This is to ensure that
 * the end user’s previous settings are retained and not unintentionally modified.
 *
 * @since 1.8.0
 */
@ProviderType
public interface TCPConfiguration {

	/**
	 * <p>
	 * Add a TCP for the device to PolyScope.
	 * </p>
	 *
	 * There can only exist one TCP for the device. If a TCP has already been defined, it will be overwritten with the
	 * new TCP.
	 *
	 * @param suggestedName Suggested name for the TCP. Valid names must match regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a
	 *                      total of 15 characters. The final name can be retrieved from the TCP instance (see {@link #getTCP()}).
	 * @param tcpPose A pose for the offset of the TCP with respect to the tool output flange
	 * @throws IllegalTCPNameException If the suggested name does not match required regex.
	 * @throws IllegalArgumentException If any of the values of the pose specified for the TCP offset are not inside the 
	 *                                  valid range of a TCP offset as defined by PolyScope.
	 */
	void setTCP(String suggestedName, Pose tcpPose);

	/**
	 * Update the offset of the device's TCP.
	 *
	 * @param tcpPose The pose for the new offset to set for the TCP with respect to the tool output flange.
	 */
	void updateTCP(Pose tcpPose);

	/**
	 * Remove the TCP of the device.
	 */
	void removeTCP();

	/**
	 * @return the TCP instance
	 *
	 * @since 1.10.0
	 */
	TCP getTCP();
}
