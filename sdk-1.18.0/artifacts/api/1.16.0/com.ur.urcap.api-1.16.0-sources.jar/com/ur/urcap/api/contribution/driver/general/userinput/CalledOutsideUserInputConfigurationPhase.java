/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput;

/**
 This exception is thrown when calls to any of the methods in the {@link CustomUserInputConfiguration} interface (e.g.
 * to register or deprecate user inputs) is performed outside the method scope of the Configuration phase (e.g.
 * the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method).
 *
 * @since 1.8.0
 */
public class CalledOutsideUserInputConfigurationPhase extends RuntimeException {

	public CalledOutsideUserInputConfigurationPhase(String message) {
		super(message);
	}
}
