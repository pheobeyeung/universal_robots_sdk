/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput;

import com.ur.urcap.api.contribution.driver.general.userinput.enterableinput.DoubleUserInput;
import com.ur.urcap.api.contribution.driver.general.userinput.enterableinput.IntegerUserInput;
import com.ur.urcap.api.contribution.driver.general.userinput.enterableinput.InvalidUserInputRange;
import com.ur.urcap.api.contribution.driver.general.userinput.enterableinput.StringUserInput;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.BooleanUserInput;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.DuplicateElementID;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.ElementListCannotBeEmpty;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.ElementResolver;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.InvalidSelection;
import com.ur.urcap.api.contribution.driver.general.userinput.selectableinput.SelectableUserInput;

import javax.swing.Icon;
import java.util.List;

/**
 *
 * This interface handles registration of custom user inputs (typically for device configuration in an installation node).
 * <br>
 *
 * After all user inputs have been registered and the method scope of the Configuration phase
 * (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method) has
 * been exited, an UI with corresponding UI elements (that allows the end user to configure the settings) will be
 * generated.
 * <br>
 *
 * The order in which user inputs (including fillers and texts) are registered will be the order in which elements are
 * displayed in the UI. The order is similar to adding cells to a HTML table, i.e. row-based adding, so the first element
 * is added in the first row and first column, the second element is added in the first row and second column. The third
 * element will be in the second row and first column and so on.
 * <br>
 *
 * A total maximum of 10 user input elements and/or non-user input UI elements (such as text components and fillers) can
 * be defined. Registering more elements will throw a {@link TooManyUserInputsRegistered} exception, except for setting
 * the description text (using the {@link CustomUserInputConfiguration#setDescriptionText(String)} method).
 * <br>
 *
 * Labels are all limited in space. Text which is too long, will automatically be truncated with 3 dots accordingly
 * in order to fit within the space provided.
 * <br>
 *
 * The {@code id} identifier parameter of all the user input registration methods must be unique and constant over time
 * and versions of the driver URCap as this is used for persistence of user input values.
 *
 * @since 1.8.0
 */
public interface CustomUserInputConfiguration {

	/**
	 * Set a description text displayed in a dedicated section above the first registered user input. The description
	 * allows roughly up to 4 full lines of text (undecorated). Text which is too long, will simply be cut-off without
	 * proper truncation support.
	 *
	 * @param text the description text, not {@code null}.
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	void setDescriptionText(String text);

	/**
	 * Request a user input where the end user can enter a string through a text input field.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the text input field, not {@code null}. The text will automatically be
	 *              truncated (with 3 dots) when text is too long.
	 * @param initialText the initial (default) text displayed in the text input field field if the user has not yet entered
	 *                    a string, not {@code null}
	 * @return a user input instance used for retrieving the string values entered by the end user as well as optionally
	 * setting a value change listener and/or adding a custom error input validator
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	StringUserInput registerStringInput(String id, String label, String initialText);

	/**
	 * Request a string-based user input where the end user can enter an IP-address through a text input field. The user
	 * input accepts any IPv4 address (ensuring the correct address format).
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the text input field, not {@code null}. The text will automatically be
	 *              truncated (with 3 dots) when text is too long.
	 * @param initialIPAddressStr the initial IP address string (default) displayed in the text input field if the user
	 *                            has not yet entered an IP address, not {@code null}
	 * @return a user input instance used for retrieving the IP address string values entered by the end user as well as
	 *         optionally setting a value change listener and/or adding a custom error input validator
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	StringUserInput registerIPAddressInput(String id, String label, String initialIPAddressStr);

	/**T
	 * Request a boolean-based user input where the end user can check/uncheck a checkbox.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the checkbox, not {@code null}. The text will automatically be truncated
	 *              (with 3 dots)when text is too long.
	 * @param initialSelection the initial (default) state of the checkbox if the user has not yet altered it. A {@code true} value
	 *                         corresponds to the checked state and {@code false} corresponds to the unchecked state.
	 * @return a user input instance used for retrieving boolean values selected by the end user as well as optionally
	 *          setting a value change listener and/or adding a custom error input validator
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	BooleanUserInput registerBooleanInput(String id, String label, boolean initialSelection);

	/**
	 * Request a user input where the end user can enter an integer through a number input field.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the number input field, not {@code null}. The text will automatically
	 *              be truncated (with 3 dots) when text is too long.
	 * @param unit the text for the unit of the input displayed after the number input field, not {@code null}. Pass an
	 *             empty string if the input is has no unit.
	 * @param initialValue the initial (default) value displayed in the number input field if the user has not yet entered
	 *                     a value
	 * @param minValue the minimum value allowed to be entered
	 * @param maxValue the maximum value allowed to be entered
	 * @return a user input instance used for retrieving the values entered by the end user as well as optionally setting
	 * a value change listener and/or adding a custom error input validator
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws InvalidUserInputRange if {@code minValue} > {@code maxValue} or {@code initialValue} is outside the
	 * 	  	                         range defined by {@code minValue} and {@code maxValue}.
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	IntegerUserInput registerIntegerInput(String id, String label, String unit, int initialValue, int minValue, int maxValue);

	/**
	 * Request a user input where the end user can enter a double (a decimal number) through a number input field.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the number input field, not {@code null}. The text will automatically
	 *              be truncated (with 3 dots) when text is too long.
	 * @param unit the text for the unit of the input displayed after the number input field, not {@code null}. Pass an
	 *             empty string if the input is has no unit.
	 * @param initialValue the initial (default) value displayed in the number input field if the user has not yet entered
	 *                     a value
	 * @param minValue the minimum value allowed to be entered
	 * @param maxValue the maximum value allowed to be entered
	 * @return a user input instance used for retrieving the values entered by the end user as well as optionally setting
	 * a value change listener and/or adding a custom error input validator
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws InvalidUserInputRange if {@code minValue} > {@code maxValue} or {@code initialValue} is outside the
	 * 	  	                         range defined by {@code minValue} and {@code maxValue}.
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	DoubleUserInput registerDoubleInput(String id, String label, String unit, double initialValue, double minValue, double maxValue);

	/**
	 * Request a combo box user input with a static list of elements (i.e. the combo box content can not be updated after
	 * registration) of a proprietary (custom) type with one of the elements pre-selected.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the combo box, not {@code null}. The text will automatically be truncated
	 * 	  	        (with 3 dots) when text is too long.
	 * @param initialSelection the initial default selection if the user has not yet altered it.
	 * @param elements the elements to be selectable in the combo box, not {@code null}
	 * @param resolver a custom resolver responsible for correctly identifying each element in the combo box, not {@code null}
	 * @param <T> The (generic) type parameter for the method representing the type of elements selected by the user
	 * @return a user input instance used for retrieving values selected by the end user as well as optionally setting a
	 * 	       value change listener
	 * @throws ElementListCannotBeEmpty if elements is an empty list
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws DuplicateElementID if the {@link ElementResolver#getId(Object)} method does not return a unique identifier
	 * for all elements in the {@code elements} list.
	 * @throws InvalidSelection if the {@code initialSelection} element is not in the {@code elements} list, i.e. the
	 * resolved identifier of the {@code initialSelection} element (returned by {@link ElementResolver#getId(Object)})
	 * is not equal to the resolved identifier of any of the elements in the {@code elements} list.
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	<T> SelectableUserInput<T> registerPreselectedComboBoxInput(String id, String label, T initialSelection, List<T> elements, ElementResolver<T> resolver);

	/**
	 * <p>
	 * Request a combo box user input with a static list of elements (i.e. the combo box content can not be updated after
	 * registration) of a proprietary (custom) type.
	 * </p>
	 *
	 * <p>
	 * The initial selection is a string which by definition is not a valid selection. The string should guide the user
	 * to make a correct selection, i.e. describe what action to do or what is to be selected, e.g. {@literal "<Mounting>"}
	 * or "Select".
	 * </p>
	 *
	 * The selection is not valid until the user changes it and will mark any program nodes for the driver contribution
	 * as undefined.
	 *
	 * @param id the unique identifier for the input, not {@code null} nor an empty string. Must be unique and constant
	 *           over time and versions of the driver URCap as this is used for persistence of user input values.
	 * @param label the text displayed in front of the combo box, not {@code null}. The text will automatically be truncated
	 * 	  	         (with 3 dots) when text is too long.
	 * @param undefinedSelection the initial default selection if the user has not yet altered it, not {@code null}. The
	 *                           string should guide the user to make a correct selection (i.e. describe what action to
	 *                           do or what is to be selected, e.g. {@literal "<Mounting>"} or "Select").
	 * @param elements the elements to be selectable in the combo box, not {@code null}.
	 * @param resolver a custom resolver responsible for correctly identifying each element in the combo box, not {@code null}
	 * @param <T> The (generic) type parameter for the method representing the type of elements selected by the user
	 * @return a user input instance used for retrieving values selected by the end user as well as optionally setting a
	 * 	       value change listener
	 * @throws ElementListCannotBeEmpty if elements is an empty list
	 * @throws TooManyUserInputsRegistered if adding this user input will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws IDAlreadyDefined if a different user input previously has been registered with the same {@code id} identifier
	 * @throws DuplicateElementID if the {@link ElementResolver#getId(Object)} method does not return a unique identifier
	 * for all elements in the {@code elements} list.
	 * @throws InvalidSelection if the {@code initialSelection} element is not in the {@code elements} list, i.e. the
	 * resolved identifier of the {@code initialSelection} element (returned by {@link ElementResolver#getId(Object)})
	 * is not equal to the resolved identifier of any of the elements in the {@code elements} list.
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	<T> SelectableUserInput<T> registerComboBoxInput(String id, String label, String undefinedSelection, List<T> elements, ElementResolver<T> resolver);

	/**
	 * Add a label and an associated text. This can be used for, e.g. displaying status information for the end user.
	 *
	 * @param label the text displayed in front of the text itself, not {@code null}. The text will automatically be
	 *              truncated (with 3 dots) when text is too long.
	 * @param text the text, not {@code null}. The text will automatically be truncated (with 3 dots) when text is too
	 *             long.
	 * @return a text component instance with the option of updating the text
	 * @throws TooManyUserInputsRegistered if adding this UI element will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	TextComponent addText(String label, String text);

	/**
	 * <p>
	 * Add a label, an icon and an associated text. This can be used for, e.g. displaying status information for the
	 * end user.
	 * </p>
	 *
	 * Supports 24x24 pixels icons for CB3 robots and 30x30 pixel icons for e-Series robots. The provided icon will be
	 * scaled automatically, if necessary.
	 *
	 * @param label the text displayed in front of the text itself, not {@code null}. The text will automatically be
	 * 	            truncated (with 3 dots) when text is too long.
	 * @param icon the icon displayed immediately in front of the text itself. Passing {@code null} is allowed and will
	 *             clear the icon.
	 * @param text the text, not {@code null}. The text will automatically be truncated (with 3 dots) when text is too
	 *             long.
	 * @return a text component instance with the option of updating the text and updating/clearing the icon
	 * @throws TooManyUserInputsRegistered if adding this UI element will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	TextComponent addText(String label, Icon icon, String text);

	/**
	 * Add a filler element to control/group layout. A blank space will be added to fill the column element.
	 *
	 * @throws TooManyUserInputsRegistered if adding this UI element will exceed the total maximum of 10 registered user
	 *                                     inputs and/or non-user input UI elements (such as text components and fillers)
	 *                                     allowed
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	void addFiller();

	/**
	 * <p>
	 * Deprecate a registered user input that was used in an older version of the driver URCap to handle backwards
	 * compatibility between driver URCap versions. The end user will no longer be able see the deprecated user input UI
	 * element or modify the value of it in this URCap version.
	 * </p>
	 *
	 * <p>
	 * Deprecating a user input is useful when a previous version of the driver URCap had a need for the
	 * given user input, but the current version no longer needs it. This can for instance be relevant when the "format"
	 * of the user input needs to be changed in a new URCap version, e.g. a previous checkbox user input needs to be
	 * changed to a combo box user input. Using this method, the old user input value can be migrated/adapted to the new
	 * user input definition/format, so the end user's previously stored configuration is not lost.
	 * </p>
	 *
	 * <b>Note:</b> The user input to be deprecated still needs to be registered (prior to deprecation) in order to have
	 * access to the old value.<br>
	 * <b>Note:</b> After deprecating a user input, the old user input value will no longer be available for the driver
	 * URCap.<br>
	 * <b>Note:</b> Deprecating a user input must happen immediately after registering it.
	 *
	 * @param userInput the user input to deprecate
	 * @return the value entered or selected by the user prior to deprecation. This value can be used to adapt/migrate
	 * the old user input value to the new user input "format".
	 * @throws CalledOutsideUserInputConfigurationPhase when this method is called from outside the method scope of the
	 * Configuration phase (e.g. the {@link com.ur.urcap.api.contribution.driver.gripper.GripperContribution#configureInstallation} method)
	 */
	<T> T deprecateUserInput(UserInput<T> userInput);
}
