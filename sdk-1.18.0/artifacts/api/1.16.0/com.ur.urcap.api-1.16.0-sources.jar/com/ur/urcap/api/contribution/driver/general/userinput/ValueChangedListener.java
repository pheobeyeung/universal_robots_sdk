/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput;


/**
 *  <p>
 *  This interface can be used to listen for changes of the value of a user input.
 * </p>
 *
 *  Implement this interface to execute custom code when the end user has entered or selected a new value as well as
 *  when a new installation is loaded or created.
 *
 *
 * @param <T> The (generic) type parameter for the interface representing the type of input data entered or selected by
 *           the end user. Relevant types are, e.g. {@link Integer} and {@link Double}.
 *
 * @since 1.8.0
 */
public interface ValueChangedListener<T> {

	/**
	 * Called upon a change of the current value of the user input. This also includes when a new installation is loaded
	 * or created.
	 *
	 * @param value The new value.
	 */
	void onValueChanged(T value);
}
