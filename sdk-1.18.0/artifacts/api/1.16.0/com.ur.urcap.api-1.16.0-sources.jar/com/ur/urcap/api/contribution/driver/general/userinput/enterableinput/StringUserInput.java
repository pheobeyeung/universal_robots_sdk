/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput.enterableinput;

import com.ur.urcap.api.contribution.driver.general.userinput.UserInput;
import com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidator;


/**
 * This interface provides access to the string entered by the end user with the option of adding special error input
 * validation.
 *
 * @since 1.8.0
 */
public interface StringUserInput extends UserInput<String> {

	/**
	 * <p>
	 * Set a custom input validator for detecting errors for the user input.
	 * </p>
	 *
	 * <b>Note:</b> For user inputs where an IP address can be entered, a validator verifying that the input value is a
	 * valid IP address is by default always attached to the user input.<br>
	 * The custom validator will be applied to the input, if the default validation is successful. An entered input is
	 * only valid, if both the default and the custom validation succeed.
	 *
	 * @param validator the custom error input validator
	 */
	void setErrorValidator(InputValidator<String> validator);
}