/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperFeedbackCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.GripperListProvider;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.domain.value.simple.Force;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Pressure;
import com.ur.urcap.api.domain.value.simple.Speed;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface represents parameters for a gripping action defined/configured by the end user.
 * </p>
 *
 * These parameters are used when generating script code for a gripping action (see
 * {@link GripperContribution#generateGripActionScript(ScriptWriter, GripActionParameters)}).
 *
 * @since 1.8.0
 */
@ProviderType
public interface GripActionParameters {

	/**
	 * <p>
	 * Get the selected force to be used the gripping action.
	 * </p>
	 *
	 * This is only valid, if the force capability has been registered (using the method
	 * {@link GripperCapabilities#registerGrippingForceCapability(double, double, double, Force.Unit)}).
	 *
	 * @return The force to use for the gripping action
	 * @throws UnsupportedOperationException if the gripper has not registered the force capability
	 */
	Force getForce();

	/**
	 * <p>
	 * Get the selected width to be used for the gripping action.
	 * </p>
	 *
	 * This is only valid, if the width capability has been registered (using the method
	 * {@link GripperCapabilities#registerWidthCapability(double, double, double, double, Length.Unit)}).
	 *
	 * @return The width to use for the gripping action
	 * @throws UnsupportedOperationException if the gripper has not registered the width capability
	 */
	Length getWidth();

	/**
	 * <p>
	 * Get the selected vacuum level to be used for the gripping action.
	 * </p>
	 *
	 * This is only valid, if the vacuum capability has been registered (using the method
	 * {@link GripperCapabilities#registerGrippingVacuumCapability(double, double, double, Pressure.Unit)}).
	 *
	 * @return The vacuum level to use for the gripping action
	 * @throws UnsupportedOperationException if the gripper has not registered the vacuum capability
	 */
	Pressure getVacuum();

	/**
	 * <p>
	 * Get the selected speed to be used for the gripping action.
	 * </p>
	 *
	 * This is only valid, if the speed capability has been registered (using the method
	 * {@link GripperCapabilities#registerSpeedCapability(double, double, double, double, Speed.Unit)}).
	 *
	 * @return The speed to use for the gripping action
	 * @throws UnsupportedOperationException if the gripper has not registered the speed capability
	 */
	Speed getSpeed();

	/**
	 * <p>
	 * Get the gripper selected by the end user for the grip action.
	 * </p>
	 *
	 * This is only valid if the contribution has registered the multi-gripper capability
	 * (see {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}).
	 *
	 * @return the selected gripper to use for the grip action
	 * @throws UnsupportedOperationException if the gripper contribution is not a multi-gripper
	 *
	 * @since 1.11.0
	 */
	SelectableGripper getGripperSelection();

	/**
	 * <p>
	 * Use this method to determine whether the grip detection option in the Gripper program node is on or off.
	 * </p>
	 *
	 * <p>
	 * Note that this method will report that grip detection is off, when script code is to be generated due to the
	 * user testing a grip configuration of a gripper program or operating the gripper using the toolbar.
	 * </p>
	 *
	 * <p>
	 * This method should only be called, if the grip detected feedback capability has been registered (using
	 * {@link GripperFeedbackCapabilities#registerGripDetectedCapability(ScriptCodeGenerator)}).
	 * </p>
	 *
	 * <p>
	 * The purpose of this method is to ensure that the appropriate script code for performing a grip action is generated
	 * when the end user has specified a new payload value. The user-defined payload value will be applied by PolyScope
	 * immediately after the generated grip action script code has finished executing. Depending on the enablement state
	 * of grip detection, the generated script should have the following properties:
	 *  <ul>
	 *      <li>
	 *          <i>Grip detection off:</i> The script code should not finish earlier than when it is appropriate to apply
	 *          the new payload value (i.e. when the object has been gripped). This typically means that the script code
	 *          should wait a time period corresponding to closing the gripper's "fingers" fully (if the gripper is vacuum
	 *          operated then long enough to achieve some level of vacuum).
	 *      </li>
	 *      <li>
	 * 	        <i>Grip detection on:</i> The payload will only be set if the grip detection was successful, i.e.
	 * 	        it will be applied immediately after a grip was detected. This means that it is not necessary for the
	 * 	        script code to wait (since the built-in detection timeout functionality will handle the waiting part).
	 * 	     </li>
	 *  </ul>
	 * </p>
	 *
	 * @return {@code true} if the end user has enabled grip detection, and {@code false} if grip detection is disabled.
	 * @throws UnsupportedOperationException if the gripper has not registered the grip detected feedback capability
	 *
	 * @since 1.10.0
	 */
	boolean isGripDetectionEnabled();
}
