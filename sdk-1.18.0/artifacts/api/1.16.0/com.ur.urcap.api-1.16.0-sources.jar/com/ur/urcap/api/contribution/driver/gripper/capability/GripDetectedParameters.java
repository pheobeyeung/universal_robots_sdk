/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.GripperListProvider;

import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;
import com.ur.urcap.api.domain.script.ScriptWriter;

import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface provides parameters relevant for generating script code for the Grip Detected feedback capability
 * (registered using {@link GripperFeedbackCapabilities#registerGripDetectedCapability(ScriptCodeGenerator)}).
 * </p>
 *
 * <p>
 * These parameters are passed when PolyScope calls the implementation of the method 
 * {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} responsible for generating the script code.
 * </p>.
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripDetectedParameters {

	/**
	 * <p>
	 * Get the individual gripper/zone selected by the end user for the grip detection.
	 * </p>
	 *
	 * This is only valid if the contribution has registered the multi-gripper capability (using 
	 * {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}).
	 *
	 * @return The selected individual gripper/zone to use for the grip detection
	 * @throws UnsupportedOperationException if the gripper contribution is not a multi-gripper, i.e. the multi-gripper
	 * capability has not been registered
	 *
	 * @since 1.11.0
	 */
	SelectableGripper getGripperSelection();
}
