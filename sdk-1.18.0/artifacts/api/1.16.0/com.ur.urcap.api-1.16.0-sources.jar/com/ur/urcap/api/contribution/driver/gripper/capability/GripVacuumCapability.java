/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.domain.value.simple.Pressure;


/**
 * <p>
 * This interface represents a registered vacuum capability for a gripper which supports gripping using a user configurable 
 * vacuum level.
 * </p>
 *
 * Through this interface, it is possible to adjust the range and default value for the vacuum level after the capability
 * has been registered. This is typically not applicable for most grippers, but can be relevant when the range depends on
 * another custom gripper setting (which can be configured by the user).
 *
 * @since 1.8.0
 */
public interface GripVacuumCapability {

	/**
	 * <p>
	 * Update the range and default value for the vacuum level supported by the gripper.
	 * </p>
	 *
	 * <p>
	 * Updating the range could result in an already entered value in the configuration of a gripper program node being 
	 * outside the range. This will make the given program node undefined, and force the end user to adjust the value to 
	 * be valid again.
	 * </p>
	 * 
	 * If the gripper works with absolute pressure, specify a positive range for the supported vacuum level.
	 * If the gripper works with relative pressure (vacuum), specify a negative range for the supported vacuum level.
	 *
	 * @param minVacuum minimum vacuum level supported by the gripper
	 * @param maxVacuum maximum vacuum level supported by the gripper
	 * @param defaultGripVacuum default value for the vacuum level for a grip action. This value is used for, e.g.
	 *                          performing a "default" grip action using the toolbar
	 * @param unit the unit for all specified values, not {@code null}
	 * @throws InvalidCapabilityRange if {@code minVacuum} > {@code maxVacuum} or {@code defaultGripVacuum} is outside the
	 * range defined by {@code minVacuum} and {@code maxVacuum}.
	 */
	void updateCapability(double minVacuum, double maxVacuum, double defaultGripVacuum, Pressure.Unit unit);
}
