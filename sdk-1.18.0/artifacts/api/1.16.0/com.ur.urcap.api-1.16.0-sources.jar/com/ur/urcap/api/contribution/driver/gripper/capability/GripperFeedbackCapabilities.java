/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.gripper.CalledOutsideGripperConfigurationPhase;
import com.ur.urcap.api.contribution.driver.gripper.GripActionParameters;
import com.ur.urcap.api.contribution.driver.gripper.GripperAPIProvider;
import com.ur.urcap.api.contribution.driver.gripper.GripperConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.ReleaseActionParameters;

import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 * <p>
 * Register the feedback capabilities of the gripper using this interface. A feedback capability is a type of status the
 * gripper is capable of informing PolyScope about.
 * </p>
 *
 * PolyScope will execute the script code associated with a feedback capability at appropriate times in the given context.
 * Script code generated must be idempotent (meaning it has no side effects when called multiple times if all other state
 * has not changed in between calls). The script code generated must also execute fast, since the feedback could be checked
 * often.
 *
 * @since 1.9.0
 */
public interface GripperFeedbackCapabilities {

	/**
	 * <p>
	 * Register this feedback capability if the gripper can inform PolyScope whether it has detected that an object has
	 * been gripped, after a grip action has been triggered. This will enable the end user to configure the actions to
	 * take when the gripper has detected that an object has been gripped and/or when the grip action timed out.
	 * </p>
	 *
	 * <p>
	 * The provided implementation of the {@link ScriptCodeGenerator} interface must generate the script code for
	 * determining if a grip was detected. The return value of the script code <b>must</b> be a boolean, i.e. 'True' or 
	 * 'False'.
	 * </p>
	 *
	 * <b>Note:</b> When this capability has been registered, the
	 * {@link GripperContribution#generateGripActionScript(ScriptWriter, GripActionParameters)} method should generate
	 * different grip action script code depending on whether the end user has enabled or disabled the grip detection
	 * option (in the Gripper program node). For more details, see Javadoc for
	 * {@link GripActionParameters#isGripDetectionEnabled()}.
	 *
	 * @param scriptCodeGenerator script generator that generates the script code for determining if a grip was detected.
	 *                            When the script code needs to be generated, the method
	 *                            {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} will be called (by
	 *                            PolyScope). The resulting script code will be embedded in a script function and
	 *                            <b>must</b> return a boolean, i.e. 'True' or 'False'.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time, i.e. outside the scope
	 * of the {@link GripperContribution#configureGripper(GripperConfiguration, GripperAPIProvider)} method.
	 */
	void registerGripDetectedCapability(ScriptCodeGenerator<GripDetectedParameters> scriptCodeGenerator);

	/**
	 * <p>
	 * Register this feedback capability if the gripper can inform PolyScope whether it has detected an object has
	 * been released, after a release action has been triggered. This will enable the end user to configure the actions
	 * to take when the gripper has detected that an object has been released and/or when the release action timed out.
	 * </p>
	 *
	 * <p>
	 * The provided implementation of the {@link ScriptCodeGenerator} interface must generate the script code for
	 * determining if a release was detected. The return value of the script code <b>must</b> be a boolean, i.e. 'True' 
	 * or 'False'.
	 * </p>
	 *
	 * <b>Note:</b> When this capability has been registered, the
	 * {@link GripperContribution#generateReleaseActionScript(ScriptWriter, ReleaseActionParameters)} method should
	 * generate different release action script code depending on whether the end user has enabled or disabled the release
	 * detection option (in the Gripper program node). For more details, see Javadoc for
	 * {@link GripActionParameters#isGripDetectionEnabled()}.
	 *
	 * @param scriptCodeGenerator script generator that generates the script code for determining if a release was
	 *                            detected. When the script code needs to be generated, the method
	 *                            {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} will be called (by
	 *                            PolyScope). The resulting script code will be embedded in a script function and
	 *                            <b>must</b> return a boolean, i.e. 'True' or 'False'.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time, i.e. outside the scope
	 * of the {@link GripperContribution#configureGripper(GripperConfiguration, GripperAPIProvider)} method.
	 */
	void registerReleaseDetectedCapability(ScriptCodeGenerator<ReleaseDetectedParameters> scriptCodeGenerator);
}
