/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.contribution.driver.general.userinput.CustomUserInputConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.GripperAPIProvider;
import com.ur.urcap.api.contribution.driver.gripper.GripperConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.SystemConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.RegisteredCapabilities;

import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;

import java.util.List;


/**
 * <p>
 * This interface represents a registered multi-gripper capability for a gripper which supports multiple individual
 * grippers/zones.
 * </p>
 *
 * After the capability has been registered, this interface provides various functionality such as:
 * <ul>
 *     <li>
 *         The ability to disable and enable each of the individual grippers
 *     </li>
 *     <li>
 *         Access to all (other) registered capabilities, such as the width capability (see {@link WidthCapability}),
 *         speed capability (see {@link SpeedCapability}), etc, to dynamically adjust their properties (including the
 *         value range and default values) exclusively for a specific gripper (independently of the other grippers).
 *     </li>
 * 	   <li>
 * 	      Access to the list of individual grippers
 * 	   </li>
 * </ul>
 *
 * @since 1.11.0
 */
public interface MultiGripperCapability {

	/**
	 * Get the list of supported individual grippers/zones added when the multi-gripper capability was registered.
	 * 
	 * @return The list of supported individual grippers/zones
	 */
	List<SelectableGripper> getSelectableGrippers();

	/**
	 * Determine if the specified individual gripper is enabled.
	 * 
	 * @param gripper The individual gripper for which to check the enabled state, not {@code null}
	 * @return {@code true} if the gripper is enabled, otherwise {@code false}
	 * @throws IllegalArgumentException if this contribution is not the owner of the individual gripper, i.e. the
	 * specified gripper was not added by this URCap.
	 */
	boolean isEnabled(SelectableGripper gripper);

	/**
	 * <p>
	 * Enable or disable the specified individual gripper.
	 * </p>
	 *
	 * <p>
	 * The disable/enable functionality can be used, if the gripper URCap is meant to support both a use case with only
	 * a single gripper as well as supporting the option of mounting several separate, identical grippers on the robot
	 * at the same time (e.g. using on a special mounting bracket). In this case, the secondary gripper(s) can be created
	 * in an initial disabled state, and then enabled when the end user is using a multi-gripper setup. If the URCap
	 * is implementing the {@link GripperContribution} interface, control of the enablement of the added grippers can be
	 * handled using custom user input(s) (see the {@link CustomUserInputConfiguration} interface).
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> It is not necessary to use the enable/disable functionality, if the multi-gripper is physically
	 * constructed in a way where it is logically partitioned in multiple zones/grippers "built into" the gripping device.
	 * In this case, all grippers should be in created in an initial enabled state and always remain enabled.
	 * </p>
	 *
	 * <p>
	 * Disabling a gripper will have the following effects:
	 * <ul>
	 *     <li>
	 *         The gripper will not be available (nor visible) in PolyScope, i.e. the end user will not be able to
	 *         select it in the Gripper toolbar and program node. This only applies to URCaps implementing the
	 *         {@link GripperContribution} interface.
	 *     </li>
	 *     <li>
	 *         If a TCP has been added for the gripper (using the instance returned by
	 *         {@link SystemConfiguration#getTCPConfiguration(SelectableGripper)}), it will not be available (nor
	 *         visible) in PolyScope to the end user. This only applies to URCaps implementing the
	 *         {@link GripperContribution} interface. Any existing selection of the disabled TCP will become unresolved
	 *         and will be displayed accordingly in combo boxes in PolyScope.
	 *     </li>
	 *     <li>
	 *         Any existing selection of the disabled gripper will become unresolved and will be displayed accordingly
	 *         in combo boxes in PolyScope, e.g. in the Gripper toolbar and program node as well as in other 3rd party
	 *         contributions.
	 *     </li>
	 *     <li>
	 *         The gripper will not be accessible to other contributions (for example contributed by other 3rd party
	 *         URCaps), i.e. it will not be included in the list returned by {@link MultiGripperSupport#getSelectableGrippers()}.
	 *         The gripper will, however, still be included in the list returned by {@link #getSelectableGrippers()}.
	 *     </li>
	 *     <li>
	 *         The return value of {@link SelectableGripper#isResolvable()} will reflect the disabled state (return
	 *         {@code false}) for any {@link SelectableGripper} instance representing the disabled gripper
	 *     </li>
	 * </ul>
	 *
	 * All these effects will be reverted when the gripper is enabled again.
	 * </p>
	 *
	 * @param gripper The individual gripper to enable or disable, not {@code null}
	 * @param enabled Indicates whether to enable/disable the specified gripper. {@code true} to enable, {@code false} 
	 *                to disable.
	 * @throws IllegalArgumentException if this contribution is not the owner of the individual gripper, i.e. the
	 * specified gripper was not added by this URCap.
	 */
	void setEnabled(SelectableGripper gripper, boolean enabled);

	/**
	 * <p>
	 * Get access to all (other) registered capabilities, such as the width capability (see {@link WidthCapability}),
	 * etc., to dynamically adjust their properties (including the value range and default values) exclusively for the
	 * specified gripper/zone (independently of the other grippers). This is typically not applicable for most grippers,
	 * but can be relevant when the range depends on another custom gripper setting (which can be configured by the user).
	 * </p>
	 *
	 * Each capability <b>must</b> be registered using the {@link GripperCapabilities} interface (when
	 * {@link GripperContribution#configureGripper(GripperConfiguration, GripperAPIProvider)} is called) before they can
	 * be accessed using this method.
	 *
	 * @param gripper The individual gripper/zone for which to get an interface providing access to the registered 
	 *                capabilities
	 * @return An interface providing access to all registered capabilities
	 * @throws IllegalArgumentException if this contribution is not the owner of the individual gripper/zone, i.e. the
	 *         specified gripper was not added by this URCap.
	 */
	RegisteredCapabilities getRegisteredCapabilities(SelectableGripper gripper);
}
