/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability.multigripper;

import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;

import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.MultiGripperCapability;

import java.util.Locale;


/**
 * <p>
 * This interface must be implemented by the gripper URCap to register the multi-gripper capability. The implementation
 * is responsible for providing PolyScope the list of individual grippers/zones available in the multi-gripper device.
 * </p>
 *
 * <p>
 * Pass the implementation of this interface to the {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}
 * method when registering the multi-gripper capability.
 * </p>
 *
 * All supported grippers <b>must</b> be created and added to the list upfront, but they can initially be disabled. The
 * method {@link #getGripperList(GripperListBuilder, Locale)} is only called once when the capability is registered, so
 * it is not possible to add more grippers at later time.
 *
 * @since 1.11.0
 */
public interface GripperListProvider {
	/**
	 * When the multi-gripper capability is registered (using the method
	 * {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}), this method is called once (by
	 * PolyScope) to retrieve the complete list of individual grippers/zones supported by this multi-gripper.
	 *
	 * <p>
	 * <b>Note</b> This method is only called once, so it is not possible to add more grippers at a later time.
	 * Grippers can, however, be created in an initial disabled state if needed. This can be useful, if
	 * the gripper URCap is meant to support both a use case with only a single gripper as well as supporting the option
	 * of mounting several separate, identical grippers on the robot at the same time (e.g. using on a special mounting
	 * bracket). In this case, the secondary gripper(s) should still be added to the list, but can initially be disabled,
	 * and then enabled (with {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}) when the end user is 
	 * using a multi-gripper setup.
	 * </p>
	 *
	 * @param gripperListBuilder A builder for creating individual grippers/zones and finally building the complete list 
	 *                           (to be returned by this method)
	 * @param locale The current locale of PolyScope. Can be used for supporting gripper/zone names in several languages.
	 * @return The list with all the individual grippers/zones, not {@code null}
	 * @throws LessThanTwoGrippers if {@code null} is returned by this method (instead of a list)
	 */
	GripperList getGripperList(GripperListBuilder gripperListBuilder, Locale locale);
}
