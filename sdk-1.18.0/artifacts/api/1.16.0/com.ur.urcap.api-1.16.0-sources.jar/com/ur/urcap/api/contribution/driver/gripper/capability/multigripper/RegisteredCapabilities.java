/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability.multigripper;

import com.ur.urcap.api.contribution.driver.gripper.GripperAPIProvider;
import com.ur.urcap.api.contribution.driver.gripper.GripperConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripForceCapability;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripVacuumCapability;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.SpeedCapability;
import com.ur.urcap.api.contribution.driver.gripper.capability.WidthCapability;

import com.ur.urcap.api.domain.value.simple.Force;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Pressure;
import com.ur.urcap.api.domain.value.simple.Speed;


/**
 * <p>
 * Each of the individual grippers/zones available in a multi-gripper device supports all capabilities that has been
 * registered, i.e. all the individual grippers have the exact same set of capabilities. This interface gives access to
 * all registered capabilities, such as the width capability (see {@link WidthCapability}), speed capability (see
 * {@link SpeedCapability}), etc. This enables dynamic adjustment of capability properties, including the value range and
 * default values, exclusively per individual gripper (independently of the other grippers).
 * </p>
 *
 * <p>
 * This interface is only relevant if the multi-gripper capability has been registered (using the method
 * {@link GripperCapabilities#registerWidthCapability(double, double, double, double, Length.Unit)}).
 * </p>
 *
 * <p>
 * Each capability <b>must</b> be registered using the {@link GripperCapabilities} interface (when
 * {@link GripperContribution#configureGripper(GripperConfiguration, GripperAPIProvider)} is called) before they can be
 * accessed using this interface.
 * </p>
 *
 * <b>NOTE:</b> If an update of the properties of a capability needs to apply for all individual grippers, it is more
 * convenient to perform the adjustment simultaneously for all grippers using the capability instance (e.g.
 * {@link WidthCapability}) returned when the capability was registered (with the {@link GripperCapabilities} interface).
 *
 * @since 1.11.0
 */
public interface RegisteredCapabilities {

	/**
	 * <p>
	 * Access the width capability interface which allows for dynamic adjustments of the capability properties exclusively
	 * for this specific individual gripper (independently of the other grippers), including the value range and default
	 * value.
	 * </p>
	 *
	 * This is only valid, if the width capability has been registered (using the method
	 * {@link GripperCapabilities#registerWidthCapability(double, double, double, double, Length.Unit)}).
	 *
	 * @return The width capability for this individual gripper
	 * @throws UnsupportedOperationException if the gripper has not registered the width capability
	 */
	WidthCapability getWidthCapability();

	/**
	 * <p>
	 * Access the grip force capability interface which allows for dynamic adjustments of the capability properties
	 * exclusively for this specific individual gripper (independently of the other grippers), including the value range
	 * and default value.
	 * </p>
	 *
	 *
	 * This is only valid, if the force capability has been registered (using the method
	 * {@link GripperCapabilities#registerGrippingForceCapability(double, double, double, Force.Unit)}).
	 *
	 * @return The grip force capability for this individual gripper
	 * @throws UnsupportedOperationException if the gripper has not registered the force capability
	 */
	GripForceCapability getGripForceCapability();

	/**
	 * <p>
	 * Access the speed capability interface which allows for dynamic adjustments of the capability properties exclusively
	 * for this specific individual gripper (independently of the other grippers), including the value range and default
	 * value.
	 * </p>
	 *
	 * This is only valid, if the speed capability has been registered (using the method
	 * {@link GripperCapabilities#registerSpeedCapability(double, double, double, double, Speed.Unit)}).
	 *
	 * @return The speed capability for this individual gripper
	 * @throws UnsupportedOperationException if the gripper has not registered the speed capability
	 */
	SpeedCapability getSpeedCapability();

	/**
	 * <p>
	 * Access the grip vacuum capability interface which allows for dynamic adjustments of the capability properties
	 * exclusively for this specific individual gripper (independently of the other grippers), including the value range
	 * and default value.
	 * </p>
	 *
	 * This is only valid, if the vacuum capability has been registered (using the method
	 * {@link GripperCapabilities#registerGrippingVacuumCapability(double, double, double, Pressure.Unit)}).
	 *
	 * @return The grip vacuum capability for this individual gripper
	 * @throws UnsupportedOperationException if the gripper has not registered the vacuum capability
	 */
	GripVacuumCapability getGripVacuumCapability();
}
