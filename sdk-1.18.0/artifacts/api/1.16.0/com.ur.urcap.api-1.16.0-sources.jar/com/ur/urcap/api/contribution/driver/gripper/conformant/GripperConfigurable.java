/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.conformant;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripperNodeConfig;

import org.osgi.annotation.versioning.ConsumerType;


/**
 * <p>
 * If an implementation of {@link ProgramNodeContribution} also implements this interface, it will enable that contribution
 * to be configured as a Gripper program node ({@link GripperNode} instance) from another program node contribution (could
 * be contributed by a different 3rd party URCap). This will allow the program node to be used for e.g. creating
 * template nodes. The program node contribution/service <b>must</b> be also be registered as conformant with a PolyScope
 * gripper device using {@link GripperRegistrationManager#registerAsGripper(Class)}.
 * </p>
 *
 * <b>Note:</b> This interface is not relevant for URCaps implementing the {@link GripperContribution} interface, since
 * such URCaps by default have insertable and configurable Gripper program nodes.
 *
 * @since 1.9.0
 */
@ConsumerType
public interface GripperConfigurable {

	/**
	 * This method is called when this program node is configured externally by another program node contribution. The
	 * provided gripper configuration must be applied, so convert the configuration parameters into something meaningful
	 * for the given program node contribution (and gripper), i.e. map the PolyScope representation of a gripper node
	 * configuration to your own representation.
	 *
	 * @param config the gripper configuration containing parameters for the gripper action to be applied
	 */
	void setConfig(GripperNodeConfig config);

	/**
	 * <p>
	 * This method is called when another program node contribution queries this program node for its current gripper
	 * configuration. A configuration reflecting (matching) the current configuration of the gripper stored in this
	 * program node must be created and returned using one of the provided configuration builders (i.e. convert your own
	 * configuration of the gripper to the PolyScope representation of gripper node configuration).
	 * </p>
	 *
	 * <b>Note:</b> It is not allowed to return your own implementation of the {@link GripperNodeConfig} interface; doing
	 * so will throw an exception. Instead the builders provided by the {@link GripperNodeConfigBuilders} interface
	 * <b>must</b> be used.
	 *
	 * @param gripperNodeConfigBuilders an interface providing means of creating the gripper configuration to be returned
	 * @return the current gripper configuration of this program node
	 */
	GripperNodeConfig getConfig(GripperNodeConfigBuilders gripperNodeConfigBuilders);
}
