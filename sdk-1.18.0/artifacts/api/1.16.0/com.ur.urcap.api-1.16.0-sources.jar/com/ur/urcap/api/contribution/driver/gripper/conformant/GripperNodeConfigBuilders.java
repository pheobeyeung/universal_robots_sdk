/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.conformant;

import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripActionConfigBuilder;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripperNodeConfig;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.ReleaseActionConfigBuilder;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides access to a set of builders which can be used to create gripper (node) configurations. Use
 * this interface to create the configuration to be returned by a program node contribution conformant with a PolyScope
 * gripper device, when the {@link GripperConfigurable#getConfig(GripperNodeConfigBuilders)} method is called.
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperNodeConfigBuilders {

	/**
	 * Creates a new {@link GripActionConfigBuilder} instance for building a single gripper (node) configuration for a
	 * grip action. Each configuration being built should ideally use a new {@link GripActionConfigBuilder} instance.
	 *
	 * @return a new builder for creating a single gripper (node) configuration for a grip action
	 */
	GripActionConfigBuilder createGripActionConfigBuilder();

	/**
	 * Creates a new {@link ReleaseActionConfigBuilder} instance for building a single gripper (node) configuration for a
	 * release action. Each configuration being built should ideally use a new {@link ReleaseActionConfigBuilder} instance.
	 *
	 * @return a new builder for creating a single gripper (node) configuration for a release action
	 */
	ReleaseActionConfigBuilder createReleaseActionConfigBuilder();

	/**
	 * Creates a gripper (node) configuration for when the gripper action is unselected (i.e. a grip or release action has
	 * not yet been selected by end user).
	 *
	 * @return a new undefined gripper configuration
	 */
	GripperNodeConfig createUndefinedConfig();
}
