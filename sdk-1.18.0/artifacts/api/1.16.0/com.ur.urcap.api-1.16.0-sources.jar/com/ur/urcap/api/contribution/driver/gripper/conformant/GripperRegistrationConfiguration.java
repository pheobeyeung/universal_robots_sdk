/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.conformant;

import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;

import com.ur.urcap.api.contribution.ProgramNodeConfiguration;
import com.ur.urcap.api.contribution.ProgramNodeServiceConfigurable;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;

import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface represents the registration of a conformant gripper device. It is returned when a program node
 * contribution is registered as a conformant gripper by calling {@link GripperRegistrationManager#registerAsGripper(Class)}.
 * </p>
 *
 * <p>
 * Through this interface, it is possible to register any additional capabilities supported by the gripper besides basic
 * simple grip and release actions, such as force gripping and support for multiple individual grippers. This will enable
 * other program node contributions (for example contributed by other 3rd party URCaps) to configure the parameters of
 * each of the registered capabilities when creating {@link GripperNode} configurations for the corresponding program node
 * contribution (which is registered as a conformant PolyScope gripper device).
 * </p>
 *
 * <b>Note:</b> All supported capabilities <b>must</b> be registered once upfront, and all registrations <b>must</b>
 * occur within the scope of the call to either
 * {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for Swing-based URCaps) or
 * {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for HTML-based URCaps).
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperRegistrationConfiguration {

	/**
	 * <p>
	 * Access an interface that can be used for registering various capabilities supported by the gripper, such as force
	 * gripping and support for multiple individual grippers.
	 * </p>
	 *
	 * <b>Note:</b> All capabilities must be registered once upfront, and these one-time registrations <b>must</b> all
	 * occur within the scope of the call to either
	 * {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for Swing-based URCaps) or
	 * {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for HTML-based URCaps).
	 *
	 * @return An interface for registering various capabilities of the gripper
	 *
	 * @since 1.11.0
	 */
	GripperCapabilities getGripperCapabilities();
}
