/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.conformant;

import com.ur.urcap.api.contribution.ProgramNodeConfiguration;
import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.contribution.ProgramNodeService;
import com.ur.urcap.api.contribution.ProgramNodeServiceConfigurable;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.CreationContext;
import com.ur.urcap.api.contribution.program.ProgramAPIProvider;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeView;

import com.ur.urcap.api.util.CalledOutsideMethodScope;

import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.device.DeviceAlreadyRegistered;
import com.ur.urcap.api.domain.device.DeviceRegistrationManager;
import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.device.gripper.GripperManager;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNodeFactory;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripperNodeConfig;

import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface is used for registering a program node contribution/service (i.e. implementations of the interfaces
 * {@link ProgramNodeContribution} and {@link SwingProgramNodeService} / {@link ProgramNodeService}) as conformant with
 * a PolyScope gripper device. This will allow a "regular" URCap to act as well as be treated and seen the same way
 * as a URCap implementing the {@link GripperContribution} interface.
 *
 * </p>
 *
 * <p>
 * <b>Note:</b> This interface is not relevant for URCaps implementing the {@link GripperContribution} interface, since
 * such URCaps are by default a PolyScope gripper device.
 * </p>
 *
 * <p>
 * Registering as a PolyScope gripper device will enable other program node contributions (could be contributed by a
 * different 3rd party URCap) to use and configure the conformant gripper program node contribution for e.g. creating a '
 * template node.
 * </p>
 *
 * <p>
 * The device registration will give the conformant gripper program node contribution the following abilities:
 * <ul>
 *     <li> It will be included as a device in the list of available PolyScope grippers returned by
 *          {@link GripperManager#getGrippers()} </li>
 *     <li> It can be inserted as a Gripper node in the program tree by another program node contribution using
 *          {@link GripperNodeFactory#createGripperNode(GripperDevice)} </li>
 *     <li> It can have the gripper action configured by another program node contribution using
 *          {@link GripperNode#setConfig(GripperNodeConfig)} </li>
 * </ul>
 *
 * <p>
 * In order for the program node to be insertable and configurable, the program node contribution <b>must</b> implement
 * the {@link GripperConfigurable} interface.
 * </p>
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperRegistrationManager extends DeviceRegistrationManager {

	/**
	 * <p>
	 * Register this program node contribution as a conformant PolyScope gripper device.
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> This is a one-time registration that must be performed within the scope of the call to either
	 * {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for Swing-based URCaps) or
	 * {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for HTML-based URCaps).
	 * <br>
	 * <b>Note:</b> The program node contribution <b>must</b> implement the {@link GripperConfigurable} interface.
	 *</p>
	 *
	 * @param <T> The class type for the program node contribution that should be registered as conformant with a
	 *            PolyScope gripper device, i.e. the class type of the instance returned when the
	 *            {@link SwingProgramNodeService#createNode(ProgramAPIProvider, SwingProgramNodeView, DataModel, CreationContext)}
	 * 	          or {@link ProgramNodeService#createNode(URCapAPI, DataModel)} method is called on the service. Besides
	 * 	          implementing the {@link ProgramNodeContribution} interface, the class type <b>must</b> also implement
	 * 	          the {@link GripperConfigurable} interface.
	 * @param gripperProgramNodeContributionClass The class of the program node contribution to be registered as a
	 *                                            conformant PolyScope gripper device, not {@code null}.
	 * @return A configuration instance for the gripper registration. This can be used for registering any additional
	 *         capabilities supported by the gripper (besides basic simple grip and release actions). Note that all
	 *         registrations must also occur within the scope of the call to either
	 *         {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for Swing-based URCaps)
	 *         or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for HTML-based
	 *         URCaps).
	 * @throws DeviceAlreadyRegistered if the specified program node contribution has already been registered as a
	 *                                 conformant gripper device.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time, i.e. outside the scope of the call to
	 *                                  either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)}
	 *                                  (for Swing-based URCaps) or
	 *                                  {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)}
	 *                                  (for HTML-based URCaps).
	 */
	<T extends ProgramNodeContribution & GripperConfigurable> GripperRegistrationConfiguration registerAsGripper(Class<T> gripperProgramNodeContributionClass);
}
