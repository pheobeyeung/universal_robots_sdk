/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver;

import com.ur.urcap.api.contribution.driver.general.tcp.TCPConfiguration;
import com.ur.urcap.api.contribution.driver.general.userinput.CustomUserInputConfiguration;
import com.ur.urcap.api.domain.resource.ControllableResourceModel;
import com.ur.urcap.api.domain.resource.ResourceModel;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;


/**
 * This interface provides access to functionality for configuring the robot system (separate from the screwdriver),
 * e.g. configuring the Tool I/O Interface settings.
 *
 * @since 1.9.0
 */
public interface SystemConfiguration {

	/**
	 * Access an interface that can be used for verifying that specific capabilities are available on the underlying
	 * robot/system. Verification of availability is required for all methods/interfaces annotated with
	 * {@link RequiredCapability}.
	 *
	 * @return the capability manager interface which can be used to query information about the availability of system
	 *         capabilities
	 */
	CapabilityManager getCapabilityManager();

	/**
	 * @return a resource model interface with read-only access to system resources, e.g. the Tool I/O interface.
	 */
	ResourceModel getResourceModel();

	/**
	 * <p>
	 * Access an interface for requesting exclusive control of system resources, e.g. the configuration of the Tool I/O
	 * Interface.
	 * </p>
	 *
	 * <b>NOTE:</b> Requesting control of a system resource must happen in the scope of the
	 * {@link ScrewdriverContribution#configureInstallation(CustomUserInputConfiguration, SystemConfiguration, TCPConfiguration, ScrewdriverAPIProvider)}
	 * method.
	 *
	 * @return a resource model interface for requesting exclusive control of system resources
	 */
	ControllableResourceModel getControllableResourceModel();
}
