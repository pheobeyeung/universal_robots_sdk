/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.screwdriver.ScrewdriverOperationType;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram.ScrewdriverProgram;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram.ScrewdriverProgramListProvider;
import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 * <p>
 * This interface provides parameters relevant for generating script code for the Program Selection capability
 * (registered using {@link ScrewdriverCapabilities#registerProgramSelectionCapability(ScrewdriverProgramListProvider, ScriptCodeGenerator)}).
 * </p>
 *
 * These parameters are passed when PolyScope calls the implementation of the {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)}
 * method responsible for the generating the script code.
 *
 * @since 1.9.0
 */
public interface ProgramSelectionParameters {

	/**
	 * @return The selected screwdriver program to use for the operation.
	 * @throws UnsupportedOperationException if the screwdriver has not registered this capability
	 */
	ScrewdriverProgram getScrewdriverProgram();

	/**
	 * @return The operation type selected by the end user.
	 * @throws UnsupportedOperationException if the screwdriver has not registered this capability
	 */
	ScrewdriverOperationType getScrewdriverOperationType();
}
