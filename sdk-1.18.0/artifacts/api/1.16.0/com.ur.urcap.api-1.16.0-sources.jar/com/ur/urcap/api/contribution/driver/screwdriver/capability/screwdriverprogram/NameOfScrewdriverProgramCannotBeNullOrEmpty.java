/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram;


/**
 * This exception is thrown when an attempt is made to add a screwdriver program (using the
 * {@link ScrewdriverProgramList} interface) without a proper display name, i.e. the provided name is {@code null} or an
 * empty string.
 *
 * @since 1.9.0
 */
public class NameOfScrewdriverProgramCannotBeNullOrEmpty extends RuntimeException {

	/**
	 * Constructs a new name of screwdriver program cannot be null or empty exception with the specified detail message.
	 * @param message the detail message.
	 */
	public NameOfScrewdriverProgramCannotBeNullOrEmpty(String message) {
		super(message);
	}
}
