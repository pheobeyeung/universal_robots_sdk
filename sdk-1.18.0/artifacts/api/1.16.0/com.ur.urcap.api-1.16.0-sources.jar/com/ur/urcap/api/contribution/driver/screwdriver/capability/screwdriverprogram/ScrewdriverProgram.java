/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram;


/**
 * This abstract class represents a screwdriver program, typically defined on an external control box for the screwdriver.
 *
 * @since 1.9.0
 */
public abstract class ScrewdriverProgram {

	/**
	 * <p>
	 * This method must return an identifier to uniquely identify this screwdriver program. The identifier will be used
	 * for persistence and resolving the correct screwdriver program. Therefore the identifier must remain constant over
	 * time and versions of the screwdriver URCap.
	 * </p>
	 *
	 * This method must be implemented.
	 *
	 * @return a unique identifier string which will remain constant over time and versions of the screwdriver URCap.
	 */
	public abstract String getId();

	/**
	 * <p>
	 * This method should return the name of the screwdriver program. The name will be displayed in the UI, e.g. in a
	 * combo box. The name returned is allowed to change over versions of the driver URCap as well as be different
	 * depending on the current language selected in PolyScope, in case translations are supported.
	 * </p>
	 *
	 * This method must be implemented.
	 *
	 * @return the name of the screwdriver program to display in the UI.
	 */
	public abstract String getDisplayName();
}
