/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram;


import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.ScrewdriverCapabilities;


/**
 * <p>
 * This interface must be implemented by the screwdriver URCap to register the program selection capability. The
 * implementation is responsible for providing PolyScope the list of programs (typically defined on an external control
 * box for the screwdriver).
 * </p>
 *
 * Pass the implementation of this interface to the method
 * {@link ScrewdriverCapabilities#registerProgramSelectionCapability(ScrewdriverProgramListProvider, ScriptCodeGenerator)}
 * when registering the program selection capability.
 *
 * @since 1.9.0
 */
public interface ScrewdriverProgramListProvider {

	/**
	 * <p>
	 * When this method is called (by PolyScope), the provided list must be populated with the current list of
	 * screwdriver programs (typically defined on an external control box for the screwdriver).
	 * </p>
	 *
	 * This method is called every time the list of screwdriver programs needs to be displayed in PolyScope. Thus
	 * the transfer of the list should be performant, so this function call is completed as fast as possible. With every
	 * method call, a new empty instance of the list is provided. This instance must be used to add the programs, so do
	 * not store a reference to the list.
	 *
	 * @param programList the list to add the screwdriver programs to. The list is initially empty.
	 */
	void populateList(ScrewdriverProgramList programList);
}
