/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.installation.swing;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.ViewAPIProvider;
import com.ur.urcap.api.contribution.installation.ContributionConfiguration;
import com.ur.urcap.api.contribution.installation.CreationContext;
import com.ur.urcap.api.contribution.installation.InstallationAPIProvider;
import com.ur.urcap.api.domain.data.DataModel;

import java.util.Locale;


/**
 * Defines an API required for defining and adding to PolyScope an installation node and corresponding screen where
 * the user interface is Swing-based.
 *
 * @param <C>  the (generic) type parameter for the interface representing the type of {@link InstallationNodeContribution}
 *             created by this SwingInstallationNodeService
 * @param <V>  the (generic) type parameter for the interface representing the type of the view used by the
 *             {@link InstallationNodeContribution} created by this service
 *
 * @since 1.3.0
 */
public interface SwingInstallationNodeService<C extends InstallationNodeContribution, V extends SwingInstallationNodeView<C>> {

	/**
	 * This method is called once after this service is registered. Modify the configuration parameter
	 * to configure your contribution. The configuration object will already have default values for its properties
	 * matching most use cases.
	 * <p>
	 * The values of the ContributionConfiguration object will be read once immediately after this method call. Changing
	 * values at a later stage will have no effect, so do not store a reference to the configuration object.
	 * </p>
	 * If the default values are appropriate, leave this method empty.
	 *
	 * @param configuration a modifiable ContributionConfiguration with default values
	 */
	void configureContribution(ContributionConfiguration configuration);

	/**
	 * @param locale the current locale of PolyScope. Can be used for supporting titles in several languages.
	 * @return The text displayed for this installation contribution in the left-hand side navigation of the Installation
	 *         Tab as well as the title of the corresponding installation node screen. Called once at start up.
	 */
	String getTitle(Locale locale);

	/**
	 * Creates a new View instance which implements the UI for your installation node screen. Called once when a new
	 * installation is loaded or created.
	 *
	 * @param apiProvider Provides access to functionality and services available from within PolyScope related to user
	 *                    interface and end user interaction
	 * @return the view
	 */
	V createView(ViewAPIProvider apiProvider);

	/**
	 * <p>
	 * Creates a new installation node instance.
	 * </p>
	 * <p>
	 * The returned node must use the supplied data model object to retrieve and store the data contained in it.
	 * All modifications to the supplied data model from the installation node constructor are ignored when an existing
	 * installation is loaded. The data model object is shared between all installation nodes contributed by the same
	 * URCap.
	 * </p>
	 *
	 * @param apiProvider Provides access to functionality and services available from within PolyScope relevant for the
	 *                    installation node
	 * @param view the View created by {@link #createView(ViewAPIProvider)}
	 * @param model object where all configuration data of the new installation node instance is to be stored in and
	 *              retrieved from
	 * @param context the context in which this node is created
	 * @return the newly constructed installation node contribution instance
	 */
	C createInstallationNode(InstallationAPIProvider apiProvider, V view, DataModel model, CreationContext context);
}
