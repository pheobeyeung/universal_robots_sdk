/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.installation.swing;

import com.ur.urcap.api.contribution.InstallationNodeContribution;

import javax.swing.JPanel;


/**
 * API for an installation node View which defines the UI for the corresponding {@link InstallationNodeContribution}
 *
 * @param <C>  the (generic) type parameter for the interface representing the type of the
 *             {@link InstallationNodeContribution} for which this view implements the UI
 *
 * @since 1.3.0
 */
public interface SwingInstallationNodeView<C extends InstallationNodeContribution> {

	/**
	 * Build the UI for the corresponding {@link InstallationNodeContribution} on the provided panel. Use the contribution
	 * for your logic and data model manipulations.
	 *
	 * @param panel the panel to build the UI on
	 * @param contribution the corresponding installation node contribution.
	 */
	void buildUI(JPanel panel, C contribution);
}
