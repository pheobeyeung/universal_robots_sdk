/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.program.configuration.debugging;

import com.ur.urcap.api.contribution.ProgramNodeConfiguration;
import com.ur.urcap.api.contribution.ProgramNodeServiceConfigurable;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface can be used to configure a URCap program node contribution's ability to be used in PolyScope's program
 * debugging functionality.
 * </p>
 *
 * <p>
 * <b>Note:</b> The program debugging functionality is not supported on CB3 robots and hence any configuration applied
 * using this interface will be ignored on CB3 robots.
 * </p>
 *
 * <b>Note:</b> The configuration values of the {@link ProgramDebuggingSupport} instance will be read once immediately
 * after the call to either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for
 * Swing-based URCaps) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
 * HTML-based URCaps) has ended. Changing values at a later stage will have no effect, so do not store a reference to the
 * {@link ProgramDebuggingSupport} object.
 *
 * <p>
 * Supported debugging functionality:
 * <ul>
 *     <li><i>Breakpoints &amp; Single Stepping:</i> When enabled, the robot programmer (end user) will be able to set a
 *         breakpoint on and single step the program node in the program tree.</li>
 *     <li><i>Starting from node selection:</i> When enabled, the robot programmer (end user) will be able to start the program
 *         directly from the program node when it is selected in the program tree.</li>
 * </ul>
 *
 * <p>
 * All functionality  can independently be configured for a URCap program node and all child nodes in the sub-tree under
 * it.
 * </p>
 *
 * <p>
 * <b>Note:</b> A parent URCap program node's settings take precedence over the settings of any child node in the sub-tree
 * under it. This means that if a parent URCap program node is configured to not allow breakpoints on its children, no
 * child node in its sub-tree will support breakpoints, regardless of whether or not the child node itself supports
 * breakpoints.
 * </p>
 *
 * <p>
 * Consider allowing breakpoints on the children of the URCap program node and cherry pick which of the children (only
 * applies to program nodes contributed by the URCap) should be configured to not allow breakpoints.
 *
 * This also applies to the settings for allowing to start from a program node.
 * </p>
 *
 * @since 1.9.0
*/
@ProviderType
public interface ProgramDebuggingSupport {

	/**
	 * <p>
	 * Configure whether or not the end user is allowed to set a breakpoint on or single step the URCap program node.
	 * </p>
	 *
	 * <p>
	 * The default value is {@code true}.
	 * </p>
	 *
	 * @param isBreakpointAllowed {@code true} if it should be allowed to set a breakpoint on or single step this URCap
	 *                            program node. If it should be disallowed, the value must be {@code false}.
	 */
	void setAllowBreakpointOnNode(boolean isBreakpointAllowed);

	/**
	 * <p>
	 * Configure whether or not the end user is allowed to set a breakpoint on or single step any of the child nodes in
	 * the sub-tree under the URCap program node. Note that it will only be possible to set a breakpoint on a child node
	 * if the child node itself supports breakpoints.
	 * </p>
	 *
	 * <p>
	 * The default value is {@code false}.
	 * </p>
	 *
	 * @param isBreakpointOnChildNodesAllowed {@code true} if it should be allowed to set a breakpoint on or single step
	 *                                        any of the child nodes in the sub-tree under this URCap program node. If it
	 *                                        should be disallowed, the value must be {@code false}.
	 */
	void setAllowBreakpointOnChildNodesInSubtree(boolean isBreakpointOnChildNodesAllowed);

	/**
	 * <p>
	 * Configure whether or not the end user can start the program from the URCap program node when it is selected in the
	 * program tree.
	 * </p>
	 *
	 * <p>
	 * The default value is {@code true}.
	 * </p>
	 *
	 * @param isStartFromNodeAllowed {@code true} if it should be allowed to start the program directly from this URCap
	 *                               program node. If it should be disallowed, the value must be {@code false}.
	 *
	 */
	void setAllowStartFromNode(boolean isStartFromNodeAllowed);

	/**
	 * <p>
	 * Configure whether or not the end user can start the program directly from any selected child node in the sub-tree
	 * under the URCap program node. Note that it will only be possible to start from a selected child node if the child
	 * node itself supports starting from the child node.
	 * </p>
	 *
	 * <p>
	 * The default value is {@code false}.
	 * </p>
	 *
	 * @param isStartFromChildNodesAllowed {@code true} if it should be allowed to start the program directly from any
	 *                                     child program node. If it should be disallowed, the value must be {@code false}..
	 */
	void setAllowStartFromChildNodesInSubtree(boolean isStartFromChildNodesAllowed);
}
