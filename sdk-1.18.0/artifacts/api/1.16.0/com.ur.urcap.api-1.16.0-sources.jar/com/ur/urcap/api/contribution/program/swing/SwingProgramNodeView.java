/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.program.swing;

import com.ur.urcap.api.contribution.ContributionProvider;
import com.ur.urcap.api.contribution.ProgramNodeContribution;

import javax.swing.JPanel;


/**
 * API for a program node View which defines the UI for the corresponding {@link ProgramNodeContribution}.
 * The instance of {@link SwingProgramNodeView} is a shared entity between several contributions.
 * 
 * @param <C>  the (generic) type parameter for the interface representing the type of the {@link ProgramNodeContribution}
 *             for which this view implements the UI
 *
 * @since 1.3.0
 */
public interface SwingProgramNodeView<C extends ProgramNodeContribution> {

	/**
	 * Build the UI for the corresponding {@link ProgramNodeContribution} on the provided panel. Use the contribution
	 * for your logic and data model manipulations.
	 *
	 * @param panel the panel to build the UI on
	 * @param provider the provider for corresponding program node contribution currently selected (in the program tree)
	 */
	void buildUI(JPanel panel, ContributionProvider<C> provider);
}
