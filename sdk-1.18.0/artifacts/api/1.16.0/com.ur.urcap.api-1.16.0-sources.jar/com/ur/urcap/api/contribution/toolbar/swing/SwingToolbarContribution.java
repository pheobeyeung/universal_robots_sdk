/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.toolbar.swing;

import javax.swing.JPanel;


/**
 *  <p>
 *  Defines an API required for specifying a PolyScope toolbar contribution. The contribution contains both the logic
 *  and UI of the toolbar.
 *  </p>
 *
 *  <b>Note:</b> Toolbar contributions are not supported on CB3 robots.
 *
 *  @since 1.3.0
 */
public interface SwingToolbarContribution {

	/**
	 * Build the UI for the toolbar on the provided panel. Called once at start up.
	 *
	 * @param jPanel the panel to build the UI on.
	 */
	void buildUI(JPanel jPanel);

	/**
	 * Called each time the user selects this URCap toolbar in PolyScope.
	 */
	void openView();

	/**
	 * Called each time the user exits this URCap toolbar in PolyScope.
	 */
	void closeView();
}
