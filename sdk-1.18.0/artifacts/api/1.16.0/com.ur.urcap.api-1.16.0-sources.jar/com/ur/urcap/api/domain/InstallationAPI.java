/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain;

import com.ur.urcap.api.domain.feature.FeatureContributionModel;
import com.ur.urcap.api.domain.function.FunctionModel;
import com.ur.urcap.api.domain.payload.PayloadContributionModel;
import com.ur.urcap.api.domain.resource.ControllableResourceModel;
import com.ur.urcap.api.domain.tcp.TCPContributionModel;
import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides access to functionality and services related to the installation. This includes what is available from
 * within PolyScope, as well as creating additional model elements to be used within PolyScope.
 *
 * @since 1.3.0
 */
@ProviderType
public interface InstallationAPI extends ApplicationAPI {

	/**
	 * @return An interface for adding script functions to PolyScope
	 */
	FunctionModel getFunctionModel();

	/**
	 * @return An interface for contributing TCPs to PolyScope
	 *
	 * @since 1.5.0
	 */
	TCPContributionModel getTCPContributionModel();

	/**
	 * @return An interface for contributing features to PolyScope
	 *
	 * @since 1.9.0
	 */
	FeatureContributionModel getFeatureContributionModel();

	/**
	 * <p>
	 * Gets an interface which provides functionality for contributing payloads to the PolyScope installation.
	 * </p>
	 *
	 * @return An interface for contributing payloads to PolyScope
	 *
	 * @since 1.13.0
	 */
	PayloadContributionModel getPayloadContributionModel();

	/**
	 * @return An interface for requesting exclusive control of system resources
	 *
	 * @since 1.7.0
	 */
	ControllableResourceModel getControllableResourceModel();

}
