/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain;

import com.ur.urcap.api.domain.robot.RobotModel;
import com.ur.urcap.api.domain.robot.RobotSimulation;
import com.ur.urcap.api.domain.system.SystemSettings;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;


/**
 * Provides access to system related functionality and services available from within PolyScope.
 *
 * @since 1.3.0
 */
public interface SystemAPI {

	/**
	 * @return An interface for obtaining version information about PolyScope.
	 */
	SoftwareVersion getSoftwareVersion();

	/**
	 * @return An interface for obtaining system settings (e.g. locale) for PolyScope.
	 */
	SystemSettings getSystemSettings();

	/**
	 * @return An interface providing information about the robot.
	 */
	RobotModel getRobotModel();

	/**
	 * @return An interface for obtaining information about robot simulation.
	 *
	 * @since 1.6.0
	 */
	RobotSimulation getRobotSimulation();

	/**
	 * @return An interface for obtaining information about capabilities available.
	 *
	 * @since 1.7.0
	 */
	CapabilityManager getCapabilityManager();
}
