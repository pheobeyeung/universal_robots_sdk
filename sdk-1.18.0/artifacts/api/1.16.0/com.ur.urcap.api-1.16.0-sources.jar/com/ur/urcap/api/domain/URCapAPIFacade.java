/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain;


/**
 * Provides access to system related functionality available from within PolyScope (the {@link SystemAPI}).
 *
 * @since 1.2.56
 */
public class URCapAPIFacade {

	private static URCapAPI api;

	private static SystemAPI systemAPI;

	/**
	 * These services allow access into what is available from within PolyScope, as well as creating additional model
	 * elements to be used within PolyScope.
	 *
	 * @deprecated Please use {@link URCapAPIFacade#getSystemAPI()} instead.
	 *
	 * @return An instance of the URCapAPI.
	 */
	@Deprecated
	public static URCapAPI getURCapAPI() {
		return api;
	}

	/**
	 * Provides access to system related functionality available from within PolyScope, such as the software version.
	 *
	 * @return An instance of the {@link SystemAPI}.
	 *
	 * @since 1.3.0
	 */
	public static SystemAPI getSystemAPI() {
		return systemAPI;
	}
}
