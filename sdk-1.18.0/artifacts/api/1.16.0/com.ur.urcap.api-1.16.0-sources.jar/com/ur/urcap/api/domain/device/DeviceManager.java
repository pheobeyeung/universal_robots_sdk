/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.device;


/**
 * <p>
 * Base interface for device managers.
 * </p>
 *
 * A device manager provides functionality for a specific type of device supported by PolyScope. The device manager can
 * provide functionality for, e.g. accessing all registered devices (of that type) and using a specific device in a
 * program.
 *
 * @since 1.9.0
 */
public interface DeviceManager {

}
