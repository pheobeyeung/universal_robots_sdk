/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.device.gripper;


import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.conformant.GripperRegistrationManager;

import com.ur.urcap.api.domain.device.DeviceManager;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNodeFactory;

import java.util.List;


/**
 * <p>
 * This interface provides functionality for gripper devices in PolyScope. The gripper manager can be for used
 * for e.g. getting all grippers available in PolyScope and accessing a factory for creating Gripper program nodes.
 * </p>
 *
 * Any URCap implementing the {@link GripperContribution} interface or registering a program node contribution/service
 * as a conformant PolyScope gripper device using the {@link GripperRegistrationManager#registerAsGripper(Class)} method,
 * will be included in the list of available grippers.
 *
 * @since 1.9.0
 */
public interface GripperManager extends DeviceManager {

	/**
	 * @return The list of grippers (gripper devices) available in PolyScope
	 */
	List<GripperDevice> getGrippers();

	/**
	 * @return A factory for creating Gripper program nodes
	 */
	GripperNodeFactory getGripperProgramNodeFactory();
}
