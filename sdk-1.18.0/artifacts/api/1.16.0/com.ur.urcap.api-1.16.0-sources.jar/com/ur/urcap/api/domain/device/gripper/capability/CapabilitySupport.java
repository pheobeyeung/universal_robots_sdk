/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.device.gripper.capability;

import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;


/**
 * <p>
 * Base/marker interface for the support for a capability in a gripper device (a {@link GripperDevice} instance).
 * Each of the specific types of capability support is represented by a derived interface (extending this base interface).
 * These provide information required for configuring the supported capability for a specific gripper device (the
 * information is not applicable for other gripper devices). This is used when creating a configuration for a Gripper
 * node (a {@link GripperNode} instance) which is using that specific device.
 * </p>
 *
 *
 * <p>
 * A gripper capability is an additional functionality that a gripper device can support besides basic simple grip and
 * release actions. Examples of capabilities include force gripping and support for multiple grippers.
 * </p>
 *
 * An instance of a capability support can be obtained by calling the {@link GripperDevice#getCapabilitySupport(Class)}
 * method with the class of one of the interfaces derived from this base interface as argument.
 *
 * @since 1.11.0
 */
public interface CapabilitySupport {

}
