/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.device.gripper.capability;

import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripActionConfigBuilder;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.ReleaseActionConfigBuilder;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;
import com.ur.urcap.api.util.Optional;

import org.osgi.annotation.versioning.ProviderType;
import java.util.List;


/**
 * <p>
 * This interface represents the support for multiple grippers provided by a multi-gripper device (a {@link GripperDevice}
 * instance), i.e. a gripper device supporting the multi-gripper capability.
 * </p>
 *
 * <p>
 * The interface provides information which can be used to configure the multi-gripper capability of a multi-gripper
 * device used by a {@link GripperNode}. This includes access to the set of individual grippers (available in the
 * multi-gripper device) which allows for selecting a specific gripper when creating a {@link GripperNode}
 * configuration.
 * </p>
 *
 * <p>
 * An instance of this interface can be acquired by calling the {@link GripperDevice#getCapabilitySupport(Class)} with
 * the class of the {@link MultiGripperSupport} interface as argument. The returned {@link MultiGripperSupport} instance
 * is wrapped in an {@link Optional}. Always use {@link Optional#isPresent()} to check if a specific gripper device is
 * a multi-gripper (i.e. supports the multi-gripper capability) before accessing it using {@link Optional#get()}.
 * </p>
 *
 * @since 1.11.0
 */
@ProviderType
public interface MultiGripperSupport extends CapabilitySupport {

	/**
	 * <p>
	 * Get the set of individual grippers available in the multi-gripper device. Note that this list of individual
	 * grippers is only applicable for a specific multi-gripper device.
	 * </p>
	 *
	 * <p>
	 * The returned list can be used to select a gripper when creating a configuration for a {@link GripperNode} with
	 * the {@link GripActionConfigBuilder} or {@link ReleaseActionConfigBuilder} interface.
	 * </p>
	 *
	 * Note that the content of the returned gripper list is not necessarily static, since the gripper device has the
	 * option of enabling and disabling the individual grippers dynamically. Therefore always get an updated list before
	 * using it to configure a {@link GripperNode}.
	 *
	 * @return A list of the individual grippers available in the multi-gripper device. Note that this list is only
	 * applicable for a specific multi-gripper device.
	 */
	List<SelectableGripper> getSelectableGrippers();
}
