/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.feature;

import com.ur.urcap.api.domain.value.Pose;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This base interface represents all types of features available in PolyScope
 *
 * @since 1.0.0
 */
@ProviderType
public interface Feature {

	/**
	 * Note: The feature can be renamed at any time
	 *
	 * @return The name of the feature
	 */
	String getName();

	/**
	 * Returns whether the position of the feature has been fully defined/specified.
	 *
	 * @return {@code true} if the feature is defined, {@code false} otherwise.
	 */
	boolean isDefined();

	/**
	 * Returns whether the feature can be used as a variable in the program.
	 *
	 * @return {@code true} if the feature is variable, {@code false} otherwise.
	 */
	boolean isVariable();


	boolean isJoggable();

	/**
	 * Returns the Cartesian location of the feature
	 *
	 * @return A pose representing the Cartesian location of the feature
	 *
	 * @since 1.6.0
	 */
	Pose getPose();

	/**
	 * <p>
	 * A feature cannot be guaranteed to be present in PolyScope. This method can be used to determine, if the feature 
	 * is present.
	 * </p>
	 *
	 * The feature will not be present, if the end user loads a different installation which does not contain the 
	 * feature, or if the feature is removed by the end user or the URCap that added the feature.
	 * 
	 * @return {@code true} if this feature is present in PolyScope, otherwise {@code false}.
	 *
	 * @since 1.9.0
	 */
	boolean isResolvable();
}
