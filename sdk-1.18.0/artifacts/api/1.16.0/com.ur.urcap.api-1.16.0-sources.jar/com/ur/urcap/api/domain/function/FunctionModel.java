/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.function;

import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.domain.util.Filter;

import java.util.Collection;


/**
 * <p>
 * This interface provides methods to add and remove script functions in the Expression Editor accessible from Assignment
 * and If program nodes among others.
 * </p>
 *
 * <p>
 * Added functions merely serve as an easy way for the end customer to use the contributed functions. The implementation
 * of a given script function must be added in the preamble of program through the use of
 * {@link com.ur.urcap.api.contribution.InstallationNodeContribution#generateScript(ScriptWriter)}.
 * </p>
 *
 * <p>
 * The full set of functions which can be contributed must be added in the preamble at all times, regardless of whether
 * they are added to the Expression Editor or not. Otherwise old programs that rely on a script function contribution
 * might stop working.
 *</p>
 *
 * See also {@link Function}.
 *
 * @since 1.1.0
 */
public interface FunctionModel {

	/**
	 * @param name Name of the function. Safe names must match regex [a-zA-Z][a-zA-Z0-9_]{0,24} for a total of 25
	 *             characters. A range of Universal Robots reserved names exists and cannot be used. In case of an
	 *             illegal or reserved name, an {@link FunctionException} will be thrown.
	 * @param argumentNames Is a list of hints (for the function arguments) to be shown comma separated inside angle
	 *                      brackets in the Expression Editor. No more than five arguments can be specified. The hints
	 *                      must also match the regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a total of 15 characters.
	 *                      Otherwise an {@link FunctionException} will be thrown.
	 * @return If the script function was successfully added, an object representing the Function will be returned.
	 *         Null otherwise (e.g. if a function with the same name was already added).
	 * @throws FunctionException if the name is illegal or more than five arguments are specified.
	 */
	Function addFunction(String name, String... argumentNames) throws FunctionException;

	/**
	 * @param function Function to be removed. Only functions added by this URCap can be removed.
	 * @return {@code true}, if the function was successfully removed.
	 *         {@code false} otherwise (e.g. if the function was not added by this URCap).
	 */
	boolean removeFunction(Function function);

	/**
	 * @param name The name of the function.
	 * @return The function if found, otherwise null.
	 */
	Function getFunction(String name);

	/**
	 * @param filter The filter being applied to the full list of added functions (by URCaps).
	 * @return A collection of added functions that meet the filter criteria.
	 */
	Collection<Function> getFunctions(Filter<Function> filter);
}
