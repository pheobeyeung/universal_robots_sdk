/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;


/**
 * This interface provides support for analog I/Os.
 *
 *	@since 1.0.0
 */
public interface AnalogIO extends IO {

	double getMinRangeValue();
	double getMaxRangeValue();

	boolean isCurrent();
	boolean isVoltage();

	/**
	 * Set analog I/O output signal. Notice the I/O must be an output I/O
	 *
	 * @param value The analog value to be set.
	 * @return {@code true} if the analog signal was set, {@code false} if the signal was not set, e.g. because the
	 * controller was not running.
	 */
	boolean setValue(double value);

	/**
	 *
	 * @return Returns the last reading of the I/O.
	 */
	double getValue();

	/**
	 * Some analog I/Os, such as the analog tool inputs, are in some situations not available for use. This method can
	 * be used to determine, if the I/O is available.
	 *
	 * @return {@code true}, if the analog signal is available.
	 *         {@code false} otherwise, e.g. because an analog tool input is used for Tool Communication Interface (TCI).
	 *
	 * @since 1.7.0
	 */
	boolean isResolvable();
}
