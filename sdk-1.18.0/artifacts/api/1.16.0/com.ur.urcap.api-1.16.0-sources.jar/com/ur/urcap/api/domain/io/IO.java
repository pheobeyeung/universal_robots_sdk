/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;

/**
 *
 * This is the base interface representing all types of I/Os available in PolyScope.
 *
 * @since 1.0.0
 */
public interface IO {

	enum IOType {
		DIGITAL,
		ANALOG,
		INTEGER,
		BOOLEAN,
		FLOAT
	}

	enum InterfaceType {
		UR_STANDARD,
		UR_TOOL,
		UR_CONFIGURABLE,
		UR_MODBUS,
		UR_GENERAL_PURPOSE,
		UR_EUROMAP
	}

	/**
	 *
	 * @return the user defined name of the IO in the currently selected installation.
	 */
	String getName();

	/**
	 *
	 * @return the robot default name of the I/O.
	 */
	String getDefaultName();

	/**
	 *
	 * @return the I/O type.
	 */
	IOType getType();

	/**
	 *
	 * @return the interface type this I/O belongs to.
	 */
	InterfaceType getInterfaceType();

	/**
	 *
	 * @return {@code true} if I/O supports reading of values and {@code false} otherwise.
	 */
	boolean isInput();

	/**
	 *
	 * @return get current reading of the I/O as a string.
	 */
	String getValueStr();

	/**
	 * Some I/Os, such as MODBUS I/Os and analog Tool inputs, are in some situations not present in PolyScope or available
	 * for use. This method can be used to determine if the I/O is available. <br>
	 *
	 * For more details about the specific situations where certain types of I/Os can be unresolved, see the relevant
	 * interfaces extending this base interface, e.g. {@link ModbusIO#isResolvable()}.
	 *
	 * @return {@code true}, if the I/O is available in PolyScope, otherwise {@code false}.
	 *
	 * @since 1.7.0
	 */
	boolean isResolvable();
}
