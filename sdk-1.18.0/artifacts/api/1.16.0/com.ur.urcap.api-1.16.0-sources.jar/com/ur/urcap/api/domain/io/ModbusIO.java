/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;

/**
 *
 * This interface provides support for MODBUS I/Os.
 *
 * @since 1.0.0
 */
public interface ModbusIO extends IO {

	/**
	 *
	 * @return Get the IP address for this MODBUS I/O.
	 */
	String getIpAddress();

	/**
	 *
	 * @return the signal address for this MODBUS I/O.
	 */
	String getSignalAddress();

	/**
	 *
	 * @param value Set MODBUS signal to an integer value. If the MODBUS signal is digital, then {@code false} is
	 * represented by 0 and {@code true} are represented by all numbers different from 0.
	 *
	 * @return {@code true} if the MODBUS signal was sent down to the controller, and {@code false} if the signal was
	 * not sent down, e.g. because the controller was not running. Notice that the MODBUS signal must support writes,
	 * consult the UR MODBUS protocol.
	 */
	boolean setValue(int value);

	/**
	 *
	 * @return the integer value of the MODBUS signal. If the MODBUS signal is
	 * digital then {@code false} is represented by 0 and {@code true} is represented by the value 1.
	 */
	int getValue();

	/**
	 * <p>
	 * A MODBUS I/O signal cannot be guaranteed to be present in PolyScope. This method can be used to determine, if the 
	 * MODBUS I/O is present.
	 * </p>
	 *
	 * <p>
	 * The MODBUS I/O signal will not be present, if the end user loads a different installation which does not contain
	 * the MODBUS I/O signal, or if the MODBUS I/O signal is deleted by the end user.
	 * </p>
	 *
	 * <b>NOTE</b>: This method cannot be used to check connection status.
	 *
	 * @return {@code true}, if the MODBUS I/O is present in PolyScope, otherwise {@code false}.
	 *
	 * @since 1.7.0
	 */
	boolean isResolvable();
}
