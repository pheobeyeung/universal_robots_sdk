/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.payload;

import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.robot.RobotLimits;
import com.ur.urcap.api.domain.robot.RobotModel;
import com.ur.urcap.api.domain.value.Position;
import com.ur.urcap.api.domain.value.PositionFactory;
import com.ur.urcap.api.domain.value.dynamics.InertiaMatrix;
import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.domain.value.simple.MomentOfInertia;
import com.ur.urcap.api.domain.value.simple.SimpleValueFactory;
import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This interface provides functionality for adding, updating and removing payloads in PolyScope.
 * </p>
 *
 * <b>Note: </b> This interface must only be used in an installation contribution.
 *
 * @since 1.13.0
 */
@ProviderType
public interface PayloadContributionModel {

	/**
	 * <p>
	 * Creates an inertia matrix to be used when adding a payload to the installation in PolyScope using the method
	 * {@link #addPayload(String, String, Mass, Position, InertiaMatrix)}, or updating an existing payload using
	 * {@link #updatePayload(String, Mass, Position, InertiaMatrix)}.
	 * </p>
	 *
	 * <p>
	 * The inertia matrix is defined in a coordinate system with center at the payload's center of gravity (CoG), also
	 * referred to as center of mass, and the axes aligned with the tool output flange coordinate system (axes).
	 * The center of gravity is defined as the offset between the center of the tool output flange and the center of
	 * gravity of the attached payload.
	 * </p>
	 *
	 * The inertia matrix is specified by the six component values for the moments of inertia (i.e. Ixx, Iyy, Izz) and
	 * products of inertia (i.e. Ixy, Ixz, Iyz).
	 *
	 * @param ixx The moment of inertia around the x-axis. Must be positive.
	 * @param iyy The moment of inertia around the y-axis. Must be positive.
	 * @param izz The moment of inertia around the z-axis. Must be positive.
	 * @param ixy The product of inertia around the x and y axes
	 * @param ixz The product of inertia around the x and z axes
	 * @param iyz The product of inertia around the y and z axes
	 * @param unit The unit for all the specified values
	 * @return A new inertia matrix
	 */
	InertiaMatrix createInertiaMatrix(double ixx, double iyy, double izz, double ixy, double ixz, double iyz, MomentOfInertia.Unit unit);

	/**
	 * <p>
	 * Add a payload to the current installation in PolyScope.
	 * </p>
	 *
	 * <p>
	 * This makes the payload selectable by the end user as well as available to other URCap contributions (through the
	 * {@link PayloadModel} interface). The payload is not modifiable by the end user or other URCaps.
	 * </p>
	 *
	 * <p>
	 * A default guess for the inertia matrix for the payload will be computed based on the specified payload mass and
	 * center of gravity. If data for the payload's inertia matrix is available, the method
	 * {@link #addPayload(String, String, Mass, Position, InertiaMatrix)} can used instead (this might give better
	 * performance of the robot arm).
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> The specified payload mass must be the total mass of the payload attached to the tool output flange
	 * of the robot.
	 * </p>
	 *
	 * The valid range for the payload mass and the coordinates of the center of gravity (CoG) are available through the
	 * {@link RobotLimits} interface which can be accessed with {@link RobotModel#getRobotLimits()} (an instance of the
	 * {@link RobotModel} interface can be retrieved through {@link SystemAPI#getRobotModel()}).
	 *
	 * @param idKey The key to identify this payload by, not {@code null} nor an empty string. The key is for this URCap
	 *              only, i.e. it only has to be unique for this URCap and not "globally" for other URCaps.
	 * @param suggestedName Suggested name for the payload, not {@code null} nor an empty string. Valid names must match
	 *                      regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a total of 15 characters. The final name can be retrieved
	 *                      from the returned payload instance.
	 * @param mass The total mass of the payload attached to the tool output flange of the robot, not {@code null}. Create
	 *             it using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity (CoG), also referred to as center of mass, for the payload. It is
	 *                        defined as the offset between the center of the tool output flange and the center of gravity
	 *                        of the attached payload. Cannot be {@code null}. Create it using the {@link PositionFactory}
	 *                        interface.
	 * @return The payload created and registered in PolyScope.
	 * @throws PayloadAlreadyAddedException If a payload has previously been added using the same {@code idKey} identifier.
	 *                                      Use {@link #getPayload(String)} to check if the payload has already been
	 *                                      added to the current installation.
	 *                                      Use {@link #updatePayload(String, Mass, Position)} or
	 *                                      {@link #updatePayload(String, Mass, Position, InertiaMatrix)} to update the
	 *                                      payload if the payload parameters have changed.
	 * @throws IllegalPayloadNameException If the suggested name does not match required regex.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *                                         the valid range as defined by PolyScope.
	 */
	Payload addPayload(String idKey, String suggestedName, Mass mass, Position centerOfGravity);

	/**
	 * <p>
	 * Add a payload to the current installation in PolyScope.
	 * </p>
	 *
	 * <p>
	 * This makes the payload selectable by the end user as well as available to other URCap contributions (through the
	 * {@link PayloadModel} interface). The payload is not modifiable by the end user or other URCaps.
	 * </p>
	 *
	 * Use the {@link #addPayload(String, String, Mass, Position, InertiaMatrix)} method instead if data for the
	 * payload's inertia matrix is not available.
	 *
	 * <p>
	 * <b>Note:</b> The specified payload mass must be the total mass of the payload attached to the tool output flange
	 * of the robot.
	 * </p>
	 *
	 * The valid range for the payload mass and the coordinates of the center of gravity (CoG) are available through the
	 * {@link RobotLimits} interface which can be accessed with {@link RobotModel#getRobotLimits()} (an instance of the
	 * {@link RobotModel} interface can be retrieved through {@link SystemAPI#getRobotModel()}).
	 *
	 * @param idKey The key to identify this payload by, not {@code null} nor an empty string. The key is for this URCap
	 *              only, i.e. it only has to be unique for this URCap and not "globally" for other URCaps.
	 * @param suggestedName Suggested name for the payload, not {@code null} nor an empty string. Valid names must match
	 *                      regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a total of 15 characters. The final name can be retrieved
	 *                      from the returned payload instance.
	 * @param mass The total mass of the payload attached to the tool output flange of the robot, not {@code null}. Create
	 *             it using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity (CoG), also referred to as center of mass, for the payload. It is
	 *                        defined as the offset between the center of the tool output flange and the center of gravity
	 *                        of the attached payload. Cannot be {@code null}. Create it using the {@link PositionFactory}
	 *                        interface.
	 * @param inertiaMatrix The inertia matrix of the payload, defined in a coordinate system with center at the payload's
	 *                      center of gravity and the axes aligned with the tool output flange coordinate system (axes).
	 *                      Cannot be {@code null}. Create it using
	 *                      {@link #createInertiaMatrix(double, double, double, double, double, double, MomentOfInertia.Unit)}.
	 * @return The payload created and registered in PolyScope.
	 * @throws PayloadAlreadyAddedException If a payload has previously been added using the same {@code idKey} identifier.
	 *                                  Use {@link #getPayload(String)} to check if the payload has already been added to
	 *                                  the current installation.
	 *                                  Use {@link #updatePayload(String, Mass, Position)} or
	 *                                  {@link #updatePayload(String, Mass, Position, InertiaMatrix)} to update
	 *                                  the payload if the payload parameters have changed.
	 * @throws IllegalPayloadNameException If the suggested name does not match required regex.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *                                         the valid range as defined by PolyScope.
	 * @throws IllegalInertiaMatrixException If any of the values of the specified inertia matrix are not inside the
	 *                                       valid range as defined by PolyScope.
	 */
	Payload addPayload(String idKey, String suggestedName, Mass mass, Position centerOfGravity, InertiaMatrix inertiaMatrix);

	/**
	 * Returns the payload previously added by this URCap using the same {@code idKey} identifier. Use this to verify if
	 * the payload is present in the current installation.
	 *
	 * @param idKey The key to identify this payload by, not {@code null} nor an empty string.
	 * @return The payload previously added by this URCap.
	 *         Returns {@code null} if no payload exists in current installation (with the specified {@code idKey}
	 *         identifier).
	 */
	Payload getPayload(String idKey);

	/**
	 * <p>
	 * Update the mass and center of gravity (CoG) of an existing payload added by this URCap.
	 * </p>
	 *
	 * <b>Note:</b> If an inertia matrix has been specified for the payload, calling this method will replace (overwrite)
	 * it with a computed default guess based the new specified payload mass and center of gravity. To avoid overwriting
	 * an existing inertia matrix (or to update an existing inertia matrix), instead use the method
	 *{@link #updatePayload(String, Mass, Position, InertiaMatrix)}.
	 *
	 * @param idKey The key to identify the payload, not {@code null} nor an empty string. A payload must have been
	 *              added using the same key prior to calling this method.
	 * @param mass The total mass of the payload attached to the tool output flange of the robot, not {@code null}. Create
	 *             it using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity of the payload, not {@code null}. Create it using the
	 *                        {@link PositionFactory} interface.
	 * @throws PayloadNotFoundException If no payload exists with the provided {@code idKey} identifier in the current
	 *                                  installation.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *                                         the valid range as defined by PolyScope.
	 */
	void updatePayload(String idKey, Mass mass, Position centerOfGravity);

	/**
	 * Update the mass, center of gravity (CoG) and inertia matrix of an existing payload added by this URCap.
	 *
	 * @param idKey The key to identify the payload, not {@code null} nor an empty string. A payload must have been
	 *              added using the same key prior to calling this method.
	 * @param mass The total mass of the payload attached to the tool output flange of the robot, not {@code null}. Create
	 *             it using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity of the payload, not {@code null}. Create it using the
	 *                        {@link PositionFactory} interface.
	 * @param inertiaMatrix The inertia matrix of the payload, not {@code null}. Create it using
	 *                      {@link #createInertiaMatrix(double, double, double, double, double, double, MomentOfInertia.Unit)}
	 * @throws PayloadNotFoundException If no payload exists with the provided {@code idKey} identifier in the current
	 *                                  installation.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *                                         the valid range as defined by PolyScope.
	 * @throws IllegalInertiaMatrixException If any of the values of the specified inertia matrix are not inside the
	 *                                       valid range as defined by PolyScope.
	 */
	void updatePayload(String idKey, Mass mass, Position centerOfGravity, InertiaMatrix inertiaMatrix);

	/**
	 * Remove a payload added by this URCap from PolyScope. Program nodes using the payload will be become undefined
	 * because the payload is no longer resolvable.
	 *
	 * @param idKey The identifier key used to add the payload with, not {@code null} nor an empty string.
	 * @throws PayloadNotFoundException If no payload exists with the provided {@code idKey} identifier in the current
	 *                                  installation.
	 */
	void removePayload(String idKey);
}
