/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.ProgramNodeFactory;
import com.ur.urcap.api.domain.program.structure.TreeNode;


/**
 * <h1>Summary</h1>
 * This interface makes it possible to modify sub-trees of URCaps.
 * The structure of trees is separated from the contents of the nodes.
 * The {@link TreeNode} interface is concerned with the structure of trees whereas
 * the {@link ProgramNode} interface deals with the concrete content of the nodes of the tree.
 *
 *
 *
 * <h1>Getting started with program modification</h1>
 * A ProgramModel contains a:
 * <ul>
 *     <li>getProgramNodeFactory() - that makes it possible to create new program nodes (both built-in PolyScope nodes
 *     and URCap program nodes). </li>
 *     <li>getRootTreeNode(ProgramNodeContribution root)} - returns the sub-tree of a given URCap ProgramNodeContribution</li>
 * </ul>
 *
 *
 * The TreeNode interface supports insertion and removal of nodes. With it you can retrieve the list of children of particular nodes.
 * Calling lockChildSequence on a tree node, locks the immediate children under the node. I.e. children can not be
 * rearranged, deleted or have other nodes inserted into the child sequence by the end user.
 *
 * <h1>Example code</h1>
 * <pre>
 * public class UpdateProgramExampleContribution implements ProgramNodeContribution {
 *      ProgramModel programModel;
 *
 *      public UpdateProgramExampleContribution(URCapAPI urCapAPI) {
 *          this.programModel = urCapAPI.getProgramModel();
 *      }
 *
 *      private void insertIntoProgramTree() {
 *          TreeNode treeNode = programModel.createRootTreeNode(this);
 *          try {
 *              treeNode.addChild(programModel.getProgramNodeFactory().createCommentNode());
 *          } catch (TreeStructureException e) {
 *              // Your handler code
 *          }
 *      }
 *
 *      //...
 *      //... rest of the implementation and a call to insertIntoProgramTree()
 *      //...
 * }
 * </pre>
 *
 * @since 1.1.0
 */
public interface ProgramModel {

	/**
	 * This method returns a {@link ProgramNodeFactory} to create program nodes.
	 *
	 * @return the factory to create program nodes.
	 */
	ProgramNodeFactory getProgramNodeFactory();

	/**
	 * Gets the {@link TreeNode} root from {@link ProgramNodeContribution}. From here, children can be added to form a
	 * sub-tree.
	 *
	 * @param root The URCap program node where a sub-tree is to be rooted.
	 * @return Returns a {@link TreeNode} root.
	 */
	TreeNode getRootTreeNode(ProgramNodeContribution root);
}
