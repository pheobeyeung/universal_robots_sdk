/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;
import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.value.expression.ExpressionBuilder;

/**
 * @since 1.1.0
 */
public interface IfNode extends ProgramNode {

	/**
	 * @deprecated Use {@link ExpressionBuilder} instead to build an {@link Expression} and set it using
	 * {@link #setExpression(Expression expression)}.
	 *
	 * @param expression The expression that will be evaluated in this If Node.
	 * @return The same If Node.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	@Deprecated
	IfNode setExpression(String expression);

	/**
	 * Sets the expression used by the node.
	 *
	 * @param expression The expression that will be evaluated in this If Node.
	 * @return The same If Node.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges} scope
	 * (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	IfNode setExpression(Expression expression);

	/**
	 * @deprecated Use {@link #getExpression2()} instead.
	 *
	 * @return the Expression to be evaluated in this If node.
	 */
	@Deprecated
	String getExpression();

	/**
	 * @return the Expression to be evaluated in this If node.
	 *
	 * @since 1.2.56
	 */
	Expression getExpression2();
}
