/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode.PayloadNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode.PayloadNodeConfigFactory;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;

/**
 * This interface represents the Set Payload program node which can be used for applying a payload. The Set Payload node
 * is a built-in program node provided by Universal robots.
 *
 * @since 1.13.0
 */
public interface SetPayloadNode extends ProgramNode {

	/**
	 * @return This method returns a factory for creating various configurations for this node.
	 */
	PayloadNodeConfigFactory getConfigFactory();

	/**
	 * Sets a configuration on this node.
	 *
	 * @param config The configuration to be applied.
	 * @return This node.
	 * @throws IllegalStateException If called from a Swing-based URCap outside of an {@link UndoableChanges} scope (see
	 *                               also {@link UndoRedoManager})
	 */
	SetPayloadNode setConfig(PayloadNodeConfig config);

	/**
	 * @return The current configuration for this node. See the {@link PayloadNodeConfig} interface.
	 */
	PayloadNodeConfig getConfig();
}
