/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.assignmentnode;

import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.variable.Variable;


/**
 * The AssignmentNodeConfigFactory can be used to construct configurations that can be set on a AssignmentNode.
 *
 * @since 1.2.56
 */
public interface AssignmentNodeConfigFactory {

	/**
	 * Create a expression assignment configuration.
	 *
	 * @param variable the variable that must be assigned an expression evaluation, not {@code null}.
	 * @param expression the expression to be evaluated, not {@code null}.
	 * @return the configuration.
	 */
	ExpressionAssignmentNodeConfig createExpressionConfig(Variable variable, Expression expression);
}
