/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.directionnode;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.Speed;


/**
 * This interface can be used to build a single configuration that can be applied to a Direction node. Each configuration
 * being built should ideally use a new {@link DirectionNodeConfigBuilder} instance.
 *
 * <p>
 * For any configuration parameter where a value is not specified (using the corresponding set method), a default value
 * will be used when the new configuration is built whereas the original value will be used when an existing configuration
 * was copied using the {@link #copyFrom(DirectionNodeConfig)} method.
 * </p>
 *
 * To build a configuration with non-default value for the feature selection and a direction along the positive X axis,
 * use the following code snippet:
 *
 * <pre>
 * {@code
 * DirectionNodeConfig newConfig = configBuilder.setFeature(feature)
 *                                              .setDirection(DirectionAxis.X_PLUS)
 *                                              .build();
 * }
 * </pre>
 *
 * To change the feature selection in the current configuration, use the following code snippet to build a new updated
 * configuration:
 *
 * <pre>
 * {@code
 *  configBuilder.copyFrom(currentConfig);
 *  DirectionNodeConfig updatedConfig = configBuilder.setFeature(feature)
 *                                                   .build();
 * }
 * </pre>
 *
 * @since 1.6.0
 */
public interface DirectionNodeConfigBuilder {

	/**
	 * Copy values from one configuration (source) to another (this) builder.
	 *
	 * @param source the original configuration to copy values from.
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder copyFrom(DirectionNodeConfig source);

	/**
	 * Sets shared tool motion parameters for a Direction node. The Direction node will inherit the tool motion parameters
	 * from the MoveL or MoveP parent.
	 *
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setSharedToolMotionParameters();

	/**
	 * Sets tool motion parameters for a Direction node.
	 *
	 * @param toolSpeed the tool speed to be achieved, not {@code null}.
	 * @param toolSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool speed value.
	 * @param toolAcceleration the tool acceleration to be used for the movement, not {@code null}.
	 * @param toolAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool acceleration value.
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setToolMotionParameters(Speed toolSpeed, ErrorHandler<Speed> toolSpeedErrorHandler,
	                                                   Acceleration toolAcceleration, ErrorHandler<Acceleration> toolAccelerationErrorHandler);


	/**
	 * Set feature for a Direction node.
	 *
	 * @param feature the feature for a direction node, not {@code null}.
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setFeature(Feature feature);


	/**
	 * Sets shared feature for a Direction node. The Direction node will inherit the feature selected in the MoveL or MoveP
	 * parent.
	 *
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setSharedFeature();


	/**
	 * Sets the direction for a Direction node.
	 *
	 * @param expression any expression that resolves to a vector (e.g. '[1.0, 0.0, 0.0]').
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setDirection(Expression expression);


	/**
	 * Sets the direction for a Direction node.
	 *
	 * @param axis linear axis to move along.
	 * @return this builder.
	 */
	DirectionNodeConfigBuilder setDirection(DirectionAxis.Axis axis);


	/**
	 * <p>
	 * Build the configuration for a Direction node.
	 * </p>
	 *
	 * A default configuration can be built by calling this method without invoking any of the set methods in this
	 * interface.
	 *
	 * @return the Direction node configuration.
	 */
	DirectionNodeConfig build();
}
