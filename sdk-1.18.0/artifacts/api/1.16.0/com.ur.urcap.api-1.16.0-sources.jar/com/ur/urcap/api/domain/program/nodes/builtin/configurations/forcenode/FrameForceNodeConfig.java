/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.forcenode;

import com.ur.urcap.api.domain.feature.Feature;

/**
 * @since 1.2.56
 */
public interface FrameForceNodeConfig extends ForceNodeConfig {

	/**
	 *
	 * @return The feature defining the coordinate system (axes) that will be used in force mode.
	 */
	Feature getFeature();

	/**
	 *
	 * @return The linear force/limit settings for the x-axis
	 */
	LinearAxisSettings getLinearAxisSettingsX();

	/**
	 *
	 * @return The linear force/limit settings for the y-axis
	 */
	LinearAxisSettings getLinearAxisSettingsY();

	/**
	 *
	 * @return The linear force/limit settings for the z-axis
	 */
	LinearAxisSettings getLinearAxisSettingsZ();

	/**
	 *
	 * @return The rotational torque/limit settings for the x-axis (Rx rotation).
	 */
	RotationalAxisSettings getRotationalAxisSettingsRX();

	/**
	 *
	 * @return The rotational torque/limit settings for the y-axis the (Ry rotation).
	 */
	RotationalAxisSettings getRotationalAxisSettingsRY();

	/**
	 *
	 * @return The rotational torque/limit settings for the z-axis (Rz rotation).
	 */
	RotationalAxisSettings getRotationalAxisSettingsRZ();
}
