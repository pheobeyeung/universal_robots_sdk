/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.program.nodes.builtin.MoveNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.builder.MoveNodeConfigBuilders;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.blend.Blend;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;
import com.ur.urcap.api.domain.value.simple.AngularSpeed;
import com.ur.urcap.api.domain.value.simple.Speed;


/**
 * This interface can be used to construct shared values configurations that can be set on a MoveNode.
 *
 * @deprecated Use the configuration builders available in {@link MoveNodeConfigBuilders} interface which is accessible
 * through {@link MoveNode#getConfigBuilders()}.
 *
 * @since 1.2.56
 */
@Deprecated
public interface MoveNodeConfigFactory {

	/**
	 * <p>
	 * Creates a shared motion parameters object for a MoveJ.
	 * </p>
	 *
	 * When used with a move node the parameters apply to the movement of the robot arm, from the previous position through
	 * the waypoints under the move node.
	 *
	 * @param jointSpeed the shared joint speed to be achieved, not {@code null}.
	 * @param jointSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid joint speed value.
	 * @param jointAcceleration the shared joint acceleration to be used, not {@code null}.
	 * @param jointAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid joint acceleration value.
	 * @return the motion parameters for MoveJ.
	 */
	MoveJMotionParameters createMoveJMotionParameters(AngularSpeed jointSpeed,
	                                                  ErrorHandler<AngularSpeed> jointSpeedErrorHandler,
	                                                  AngularAcceleration jointAcceleration,
	                                                  ErrorHandler<AngularAcceleration> jointAccelerationErrorHandler);
	/**
	 * <p>
	 * Creates a shared motion parameters object for a MoveL.
	 * </p>
	 *
	 * When used with a move node the parameters apply to the movement of the robot arm, from the previous position through
	 * the waypoints under the move node.
	 *
	 * @param toolSpeed the shared tool speed to be achieved, not {@code null}.
	 * @param toolSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool speed value.
	 * @param toolAcceleration the shared tool acceleration to be used, not {@code null}.
	 * @param toolAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool acceleration value.
	 * @return the motion parameters for MoveL.
	 */
	MoveLMotionParameters createMoveLMotionParameters(Speed toolSpeed,
	                                                  ErrorHandler<Speed> toolSpeedErrorHandler,
	                                                  Acceleration toolAcceleration,
	                                                  ErrorHandler<Acceleration> toolAccelerationErrorHandler);

	/**
	 * <p>
	 * Creates a shared motion parameters object for a MoveP.
	 * </p>
	 *
	 * When used with a move node the parameters apply to the movement of the robot arm, from the previous position through
	 * the waypoints under the move node.
	 *
	 * @param toolSpeed the shared tool speed to be achieved, not {@code null}.
	 * @param toolSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool speed value.
	 * @param toolAcceleration the shared tool acceleration to be used, not {@code null}.
	 * @param toolAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool acceleration value.
	 * @param blend the shared blend used with this motion, not {@code null}.
	 * @param blendErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid blend value.
	 * @return the motion parameters for MoveP.
	 */
	MovePMotionParameters createMovePMotionParameters(Speed toolSpeed,
	                                                  ErrorHandler<Speed> toolSpeedErrorHandler,
	                                                  Acceleration toolAcceleration,
	                                                  ErrorHandler<Acceleration> toolAccelerationErrorHandler,
	                                                  Blend blend,
	                                                  ErrorHandler<Blend> blendErrorHandler);

	/**
	 * <p>
	 * Creates a default MoveJ shared values configuration.
	 * </p>
	 *
	 * Note that the default values of this configuration may change between PolyScope versions.
	 *
	 * @return the configuration.
	 */
	MoveJMoveNodeConfig createMoveJConfig();

	/**
	 * Creates a MoveJ shared values configuration.
	 *
	 * @param moveJMotionParameters the shared parameters for this movement, not {@code null}.
	 * @return the configuration.
	 */
	MoveJMoveNodeConfig createMoveJConfig(MoveJMotionParameters moveJMotionParameters);

	/**
	 * <p>
	 * Creates a default MoveL shared values configuration.
	 * </p>
	 *
	 * Note that the default values of this configuration may change between PolyScope versions.
	 *
	 * @return the configuration.
	 */
	MoveLMoveNodeConfig createMoveLConfig();

	/**
	 * Creates a MoveL shared values configuration.
	 *
	 * @param moveLMotionParameters the shared parameters for this movement, not {@code null}.
	 * @param feature the shared feature for this movement, not {@code null}.
	 * @return the configuration.
	 */
	MoveLMoveNodeConfig createMoveLConfig(MoveLMotionParameters moveLMotionParameters, Feature feature);

	/**
	 * <p>
	 * Creates a default MoveP shared values configuration.
	 * </p>
	 *
	 * Note that the default values of this configuration may change between PolyScope versions.
	 *
	 * @return the configuration.
	 */
	MovePMoveNodeConfig createMovePConfig();

	/**
	 * Creates a MoveP shared values configuration.
	 *
	 * @param movePMotionParameters the shared parameters for this movement, not {@code null}.
	 * @param feature the shared feature for this movement, not {@code null}.
	 * @return the configuration.
	 */
	MovePMoveNodeConfig createMovePConfig(MovePMotionParameters movePMotionParameters, Feature feature);
}
