/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode;

import com.ur.urcap.api.domain.tcp.TCP;


/**
 * This interface supplies methods for creating TCP selections for a Move node configuration.
 *
 * @since 1.6.0
 */
public interface TCPSelectionFactory {

	/**
	 * Create a TCP selection for the motion which uses the active TCP, i.e. motions are adjusted to the currently active
	 * TCP. The value for the TCP is determined during runtime of the program.
	 *
	 * @return the TCP selection for using the active TCP.
	 */
	TCPSelection createActiveTCPSelection();

	/**
	 * Create a TCP selection for the motion which ignores the active TCP, i.e. no TCP is used and the motion will be with
	 * respect to the tool output flange.
	 *
	 * @return the TCP selection for ignoring the active TCP.
	 */
	TCPSelection createIgnoreActiveTCPSelection();

	/**
	 * Create a specific TCP selection for the motion.
	 *
	 * @param tcp the TCP to select.
	 * @return the TCP selection.
	 */
	MoveNodeTCP createTCPSelection(TCP tcp);
}
