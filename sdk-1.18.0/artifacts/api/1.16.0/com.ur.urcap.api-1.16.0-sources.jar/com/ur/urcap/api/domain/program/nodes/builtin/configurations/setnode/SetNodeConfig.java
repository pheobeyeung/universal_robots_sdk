/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setnode;

/**
 * @since 1.2.56
 */
public interface SetNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * No selection has been made. This type has no further information.
		 */
		NO_TYPE,

		/**
		 * No action has been selected. This type has no further information.
		 */
		NO_ACTION,

		/**
		 * <p>
		 * Digital output has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link DigitalOutputSetNodeConfig}.
		 */
		DIGITAL_OUTPUT,

		/**
		 * <p>
		 * Analog output configured for electric current or no output has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AnalogOutputCurrentSetNodeConfig}.
		 */
		ANALOG_OUTPUT_CURRENT,

		/**
		 * <p>
		 * Analog output configured for voltage has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AnalogOutputVoltageSetNodeConfig}.
		 */
		ANALOG_OUTPUT_VOLTAGE,

		/**
		 * <p>
		 * Register using float type values has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link FloatRegisterOutputSetNodeConfig}.
		 */
		FLOAT_REGISTER_OUTPUT,

		/**
		 * <p>
		 * Expression output has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link ExpressionOutputSetNodeConfig}.
		 */
		EXPRESSION_OUTPUT,

		/**
		 * <p>
		 * Single digital pulse output has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link SingleDigitalPulseSetNodeConfig}.
		 */
		SINGLE_DIGITAL_PULSE,

		/**
		 * <p>
		 * Increment variable has been selected. This type has no further information.
		 * </p>
		 *
		 * Setting this type of config will be ignored and will have no effect on the node.
		 */
		INCREMENT_VARIABLE
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return the type of this config.
	 */
	ConfigType getConfigType();
}
