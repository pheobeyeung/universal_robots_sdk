/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode;

import com.ur.urcap.api.domain.payload.Payload;
import com.ur.urcap.api.domain.value.simple.Time;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents a configuration of the Set Payload node where a payload (from the installation) has been
 * selected.
 *
 * @since 1.13.0
 */
@ProviderType
public interface SelectionPayloadNodeConfig extends PayloadNodeConfig {

	/**
	 * @return The payload selection for this Set Payload node
	 */
	Payload getPayload();

	/**
	 * @return The defined transition time for this Set Payload node. The Transition time is the time used to ramp the
	 * payload from the robot's current active payload to the selected payload.
	 *
	 * @since 1.14.0
	 */
	Time getTransitionTime();
}
