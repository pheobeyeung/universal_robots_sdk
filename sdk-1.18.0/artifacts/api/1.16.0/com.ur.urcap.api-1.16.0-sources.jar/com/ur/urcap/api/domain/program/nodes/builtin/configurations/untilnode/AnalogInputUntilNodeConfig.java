/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;

import com.ur.urcap.api.domain.io.AnalogIO;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.CompareOperator;
import com.ur.urcap.api.domain.value.simple.Current;
import com.ur.urcap.api.domain.value.simple.Voltage;

/**
 * @since 1.7.0
 */
public interface AnalogInputUntilNodeConfig extends IOInputUntilNodeConfig {

	/**
	 * The type of the electrical domain used by an analog input.
	 */
	enum InputDomainType {

		/**
		 * The selected electrical domain for the analog input is Current.
		 */
		CURRENT,

		/**
		 * The selected electrical domain for the analog input is Voltage.
		 */
		VOLTAGE
	}

	/**
	 *
	 * @return the electrical domain type for the analog input used by the Until node. This can change depending on what
	 * the end user has selected in PolyScope.
	 */
	InputDomainType getInputDomainType();

	/**
	 * <p>
	 * Retrieves the selected analog input used by the until condition.
	 * </p>
	 *
	 * <b>Note:</b> The selected analog input might no longer be available (e.g. because a selected analog Tool input is
	 * used for Tool Communication Interface). The presence of the selected analog input can be verified using
	 * {@link AnalogIO#isResolvable()}.
	 *
	 * @return the selected analog input
	 */
	AnalogIO getInput();

	/**
	 *
	 * @return the operator used when comparing the signal value/level of the selected analog input to the threshold value.
	 */
	CompareOperator getCompareOperator();

	/**
	 *
	 * @return the electric Current threshold value used by the until condition. Execution will proceed until the signal
	 * 	       value of the selected analog input goes past this threshold.
	 * @throws IllegalStateException if the selected analog input is using the Voltage electrical domain. Use
	 *         {@link #getInputDomainType()} to determine the electrical domain type used by the selected analog input.
	 */
	Current getCurrentThreshold();

	/**
	 *
	 * @return the electric Voltage threshold value used by the until condition. Execution will proceed until the signal
	 * 	       value of the selected analog input goes past this threshold.
	 * @throws IllegalStateException if the selected analog input is using the Current electrical domain. Use
	 *         {@link #getInputDomainType()} to determine the electrical domain type used by the selected analog input.
	 */
	Voltage getVoltageThreshold();
}
