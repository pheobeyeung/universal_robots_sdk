/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;

import com.ur.urcap.api.domain.io.IO;

/**
 * @since 1.7.0
 */
public interface DigitalInputUntilNodeConfig extends IOInputUntilNodeConfig {

	/**
	 * <p>
	 * Retrieves the selected digital input used by the until condition.
	 * </p>
	 *
	 * <b>Note:</b> The selected digital input might no longer be available (e.g. because a selected digital MODBUS input
	 * is not present in the installation in PolyScope). The presence of the selected digital input can be verified using
	 * {@link IO#isResolvable()}.
	 *
	 * @return the selected digital input.
	 */
	IO getInput();

	/**
	 * <p>
	 * The signal value for the selected digital input used by the until condition.
	 * </p>
	 *
	 * Depending on the type of digital input this is interpreted in different ways.
	 * For digital inputs and digital MODBUS inputs, {@code true} means to proceed until the input signal value becomes HIGH,
	 * {@code false} means to proceed until signal value is LOW.<br>
	 * For boolean input registers, the value is interpreted literally.
	 *
	 * @return the signal value used in the until condition
	 */
	boolean getValueToProceedUntil();
}
