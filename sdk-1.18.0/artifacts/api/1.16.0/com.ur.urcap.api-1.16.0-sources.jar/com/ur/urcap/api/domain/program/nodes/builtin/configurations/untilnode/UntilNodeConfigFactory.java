/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;

import com.ur.urcap.api.domain.io.AnalogIO;
import com.ur.urcap.api.domain.io.BooleanRegister;
import com.ur.urcap.api.domain.io.DigitalIO;
import com.ur.urcap.api.domain.io.FloatRegister;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.io.ModbusIO;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.CompareOperator;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.blend.Blend;
import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;
import com.ur.urcap.api.domain.value.simple.Current;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Voltage;


/**
 * This interface can be used to create configurations that can be applied to an Until program node.
 *
 * @since 1.6.0
 */
public interface UntilNodeConfigFactory {

	/**
	 * <p>
	 * Creates no blend parameters for an Until node. The robot arm will stop without performing a blend.
	 * </p>
	 *
	 * Can be used in a Distance configuration type.
	 *
	 * @return the blend parameters for the Until node.
	 */
	BlendParameters createNoBlendParameters();

	/**
	 * Creates blend parameters for an Until node. Can be used in a Distance configuration type.
	 *
	 * @param suggestedBlend This blend value may be (automatically) corrected depending on the value of the
	 *                       distance parameter the Distance configuration.
	 * @return the blend parameters for the Until node.
	 */
	BlendParameters createBlendParameters(Blend suggestedBlend);

	/**
	 * <p>
	 * Creates shared deceleration parameter for an Until node. The acceleration values from the parent Move node will be
	 * used as deceleration (absolute value).
	 * </p>
	 *
	 * Can be used in an Expression configuration type.
	 *
	 * @return the deceleration parameter for the Until node.
	 */
	DecelerationParameters createSharedDecelerationParameters();

	/**
	 * <p>
	 * Creates deceleration parameter for an Until node. Can be used in an Expression configuration type.
	 * </p>
	 *
	 * An angular deceleration is used when the type of the parent Move node is a MoveJ, whereas a Cartesian deceleration
	 * is used when the move type is a MoveL or MoveP.
	 *
	 * @param deceleration the angular deceleration (the value for the Cartesian deceleration will be the default value
	 *                     that PolyScope uses), not {@code null}.
	 * @param decelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 * 	                      this will clamp the value to the nearest valid angular deceleration value.
	 * @return the deceleration parameter for the Until node.
	 */
	CustomDecelerationParameters createDecelerationParameters(AngularAcceleration deceleration,
															  ErrorHandler<AngularAcceleration> decelerationErrorHandler);

	/**
	 * <p>
	 * Creates deceleration parameter for an Until node. Can be used in an Expression configuration type.
	 * </p>
	 *
	 * An angular deceleration is used when the type of the parent Move node is a MoveJ, whereas a Cartesian deceleration
	 * is used when the move type is a MoveL or MoveP.
	 *
	 * @param deceleration the Cartesian deceleration (the value for the angular deceleration will be the default value
	 *                     that PolyScope uses), not {@code null}.
	 * @param decelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 * 	                      this will clamp the value to the nearest valid cartesian deceleration value.
	 * @return the deceleration parameter for the Until node.
	 */
	CustomDecelerationParameters createDecelerationParameters(Acceleration deceleration,
															  ErrorHandler<Acceleration> decelerationErrorHandler);

	/**
	 * <p>
	 * Creates deceleration parameter for an Until node. Can be used in an Expression configuration type.
	 * </p>
	 *
	 * An angular deceleration is used when the type of the parent Move node is a MoveJ, whereas a Cartesian deceleration
	 * is used when the move type is a MoveL or MoveP.
	 *
	 * @param angularDeceleration the angular deceleration, not {@code null}.
	 * @param angularDecelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 * 	                      this will clamp the value to the nearest valid angular deceleration value.
	 * @param cartesianDeceleration the Cartesian deceleration, not {@code null}.
	 * @param cartesianDecelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 * 	                      this will clamp the value to the nearest valid cartesian deceleration value.
	 * @return the deceleration parameter for the Until node.
	 */
	CustomDecelerationParameters createDecelerationParameters(AngularAcceleration angularDeceleration,
															  ErrorHandler<AngularAcceleration> angularDecelerationErrorHandler,
															  Acceleration cartesianDeceleration,
															  ErrorHandler<Acceleration> cartesianDecelerationErrorHandler);

	/**
	 * <p>
	 * Creates an Expression configuration for an Until node with PolyScope default values. This default configuration
	 * corresponds to when the end user inserts a new Until Expression node in the program tree manually.
	 * </p>
	 *
	 * Note that these default values may change between PolyScope versions.
	 *
	 * @return the Until node configuration.
	 */
	ExpressionUntilNodeConfig createExpressionConfig();

	/**
	 * <p>
	 * Creates an Expression configuration for an Until node with an expression and default value for the deceleration
	 * parameter. The until condition for this configuration is true once the evaluation of the expression is true.
	 * </p>
	 *
	 * Note that this default value may change between PolyScope versions.
	 *
	 * @param expression the expression whose evaluation will determine whether the until condition is met.
	 * @return the Until node configuration.
	 */
	ExpressionUntilNodeConfig createExpressionConfig(Expression expression);

	/**
	 * Creates an Expression configuration for an Until node. The until condition for this configuration is true once
	 * the evaluation of the expression is true.
	 *
	 * @param expression the expression whose evaluation will determine whether the until condition is met.
	 * @param deceleration the rate of deceleration to stop at once the expression until condition is met.
	 * @return the Until node configuration.
	 */
	ExpressionUntilNodeConfig createExpressionConfig(Expression expression, DecelerationParameters deceleration);

	/**
	 * <p>
	 * Creates a Distance configuration for an Until node with PolyScope default values. This default configuration
	 * corresponds to when the end user inserts a new Until Distance node in the program tree manually.
	 * </p>
	 *
	 * Note that these default values may change between PolyScope versions.
	 *
	 * @return the Until node configuration.
	 */
	DistanceUntilNodeConfig createDistanceConfig();

	/**
	 * Creates a Distance configuration for an Until node. The until condition for this configuration is true once a
	 * given distance is reached.
	 *
	 * @param distance the distance for the robot arm to travel, not {@code null}.
	 * @param distanceErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 * 	                      this will clamp the value to the nearest valid distance value.
	 * @param blendParameters the blend to be applied when the distance is met.
	 * @return the Until node configuration.
	 */
	DistanceUntilNodeConfig createDistanceConfig(Length distance,
												 ErrorHandler<Length> distanceErrorHandler,
												 BlendParameters blendParameters);

	/**
	 * Creates a Reached Waypoint configuration for an Until node. The until condition for this configuration is true
	 * once its parent Waypoint is reached.
	 *
	 * @return the Until node configuration.
	 */
	ReachedWaypointUntilNodeConfig createReachedWaypointConfig();

	/**
	 * Creates an I/O Input configuration for an Until node with PolyScope default values, i.e. no I/O input is selected
	 * for the until condition. This default configuration corresponds to when the end user inserts a new Until I/O Input
	 * node in the program tree manually.
	 *
	 * @return the Until node configuration.
	 *
	 * @since 1.7.0
	 */
	IOInputUntilNodeConfig createIOInputConfig();

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * signal value of a given digital input goes HIGH or LOW.
	 *
	 * @param input the digital input whose signal value will determine whether the until condition is met, not {@code null}.
	 * @param valueToProceedUntil {@code true}, if the until condition is met when the input signal value goes HIGH,
	 *                            {@code false} otherwise (condition met when signal value is LOW).
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 *
	 * @since 1.7.0
	 */
	DigitalInputUntilNodeConfig createDigitalInputConfig(DigitalIO input, boolean valueToProceedUntil);

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * signal value of a given digital MODBUS input becomes HIGH/true or LOW/false.
	 *
	 * @param input the digital MODBUS input whose value will determine whether the until condition is met, not {@code null}.
	 * @param valueToProceedUntil {@code true}, if the until condition is met when the input signal value goes HIGH/true,
	 *                            {@code true} otherwise (condition met when signal value is LOW).
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values)
	 * or if {@code output} is not a digital output. See {@link IO#isInput()} and {@link IO#getType()}.
	 *
	 * @since 1.7.0
	 */
	DigitalInputUntilNodeConfig createDigitalInputConfig(ModbusIO input, boolean valueToProceedUntil);

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * value of a given boolean register becomes {@code true} or {@code false}.
	 *
	 * @param input the boolean input register whose value will determine whether the until condition is met, not {@code null}.
	 * @param valueToProceedUntil {@code true}, if the until condition is met when the register value becomes {@code true},
	 *                            {@code false} otherwise (condition met when register value is {@code false}).
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 *
	 * @since 1.7.0
	 */
	DigitalInputUntilNodeConfig createDigitalInputConfig(BooleanRegister input, boolean valueToProceedUntil);

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * the signal value of a given analog input goes past a specified electric Current threshold.
	 *
	 * @param input the analog input whose signal value will determine whether the until condition is met, not {@code null}.
	 * @param compareOperator the operator to use when comparing the signal value of the selected analog input to the
	 *                        threshold value, not {@code null}. Available options are "less than" ({@literal <}) or
	 *                        "greater than" ({@literal >}).
	 * @param currentThreshold the electric Current threshold for the signal value of the analog input. Execution will
	 *                         proceed until the signal value of the selected analog input goes past this threshold.
	 * @param errorHandler the error handler for validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid current value.
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 *
	 * @since 1.7.0
	 */
	AnalogInputUntilNodeConfig createAnalogInputConfig(AnalogIO input,
	                                                   CompareOperator compareOperator,
	                                                   Current currentThreshold,
	                                                   ErrorHandler<Current> errorHandler);

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * signal value of a given analog input goes past a specified electric Voltage threshold.
	 *
	 * @param input the analog input whose signal value will determine whether the until condition is met, not {@code null}.
	 * @param compareOperator the operator to use when comparing the signal value of the selected analog input to the
	 *                        threshold value, not {@code null}. Available options are "less than" ({@literal <}) or
	 *                        "greater than" ({@literal >}).
	 * @param voltageThreshold the electric Voltage threshold for the signal value of the analog input. Execution will
	 * 	                       proceed until the signal value of the selected analog input goes past this threshold.
	 * @param errorHandler the error handler for validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid voltage value.
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 *
	 * @since 1.7.0
	 */
	AnalogInputUntilNodeConfig createAnalogInputConfig(AnalogIO input,
	                                                   CompareOperator compareOperator,
	                                                   Voltage voltageThreshold,
	                                                   ErrorHandler<Voltage> errorHandler);

	/**
	 * Creates an I/O Input configuration for an Until node. The until condition for this configuration is true once the
	 * value of a float input register goes past a specified threshold.
	 *
	 * @param input the float input register whose value will determine whether the until condition is met, not {@code null}.
	 * @param compareOperator the operator to use when comparing the value of the selected input register to the threshold
	 * 	                      value, not {@code null}. Available options are "less than" ({@literal <}) or "greater than"
	 * 	                      ({@literal >}).
	 * @param threshold the threshold for the value of the float input register. Execution will proceed until the value
	 *                  of the selected float input register goes past this threshold.
	 * @return the Until node configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values).
	 * See {@link IO#isInput()}.
	 *
	 * @since 1.7.0
	 */
	FloatRegisterInputUntilNodeConfig createFloatRegisterInputConfig(FloatRegister input,
	                                                                 CompareOperator compareOperator,
	                                                                 float threshold);
}

