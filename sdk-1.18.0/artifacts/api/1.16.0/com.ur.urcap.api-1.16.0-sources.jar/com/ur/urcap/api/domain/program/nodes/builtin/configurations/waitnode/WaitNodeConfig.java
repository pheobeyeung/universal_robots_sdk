/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waitnode;

/**
 * @since 1.2.56
 */
public interface WaitNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * No selection has been made. This type has no further information.
		 */
		NO_TYPE,

		/**
		 * No wait has been selected. This type has no further information.
		 */
		NO_WAIT,

		/**
		 * <p>
		 * Time to wait has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link TimeWaitNodeConfig}.
		 */
		TIME,

		/**
		 * <p>
		 * Digital input has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link DigitalInputWaitNodeConfig}.
		 */
		DIGITAL_INPUT,

		/**
		 * <p>
		 * Analog input configured for electric current or no input has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AnalogInputCurrentWaitNodeConfig}.
		 */
		ANALOG_INPUT_CURRENT,

		/**
		 * <p>
		 * Analog input configured for voltage has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AnalogInputVoltageWaitNodeConfig}.
		 */
		ANALOG_INPUT_VOLTAGE,

		/**
		 * <p>
		 * Input register using float type values has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link FloatRegisterInputWaitNodeConfig}.
		 */
		FLOAT_REGISTER_INPUT,

		/**
		 * <p>
		 * Expression has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link ExpressionInputWaitNodeConfig}
		 */
		EXPRESSION_INPUT
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return the type of this config.
	 */
	ConfigType getConfigType();
}
