/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waitnode;

import com.ur.urcap.api.domain.io.AnalogIO;
import com.ur.urcap.api.domain.io.BooleanRegister;
import com.ur.urcap.api.domain.io.DigitalIO;
import com.ur.urcap.api.domain.io.FloatRegister;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.io.ModbusIO;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.CompareOperator;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.value.simple.Current;
import com.ur.urcap.api.domain.value.simple.Time;
import com.ur.urcap.api.domain.value.simple.Voltage;


/**
 * The WaitNodeConfigFactory can be used to construct configurations that can be set on a WaitNode.
 *
 * @since 1.2.56
 */
public interface WaitNodeConfigFactory {
	/**
	 * Creates a configuration for waiting a specified amount of time.
	 *
	 * @param time the time to wait, not {@code null}.
	 * @param errorHandler handler for validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                    this will clamp the value to the nearest valid time value.
	 * @return the configuration.
	 */
	TimeWaitNodeConfig createTimeConfig(Time time, ErrorHandler<Time> errorHandler);

	/**
	 * Creates a configuration for waiting for a digital input to go high or low.
	 *
	 * @param input the digital input on which to wait, not {@code null}.
	 * @param valueToWaitFor {@code true}, if waiting for the input signal value/level to go HIGH, {@code false}
	 *                       otherwise (waiting for LOW signal value/level).
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values).
	 *                                  See {@link IO#isInput()}.
	 */
	DigitalInputWaitNodeConfig createDigitalInputConfig(DigitalIO input, boolean valueToWaitFor);

	/**
	 * Creates a configuration for waiting for a digital MODBUS input to go high or low.
	 *
	 * @param input the digital MODBUS input on which to wait, not {@code null}.
	 * @param valueToWaitFor {@code true}, if waiting for the input signal value/level to go HIGH, {@code false}
	 *                       otherwise (waiting for LOW signal value/level).
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values)
	 * or if {@code output} is not a digital output. See {@link IO#isInput()} and {@link IO#getType()}.
	 */
	DigitalInputWaitNodeConfig createDigitalInputConfig(ModbusIO input, boolean valueToWaitFor);

	/**
	 * Creates a configuration for waiting for a boolean register to go {@code true} or {@code false}.
	 *
	 * @param input the boolean register input on which to wait, not {@code null}.
	 * @param valueToWaitFor {@code true}, if waiting for the register to be {@code true}, {@code false} otherwise.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 */
	DigitalInputWaitNodeConfig createDigitalInputConfig(BooleanRegister input, boolean valueToWaitFor);

	/**
	 * Creates a configuration for waiting for an analog input to go past an electric current threshold.
	 *
	 * @param input on which to wait, not {@code null}.
	 * @param compareOperator the operator to use when comparing input to value, not {@code null}. Available options are
	 *                        "less than" ({@literal <}) or "greater than" ({@literal >}).
	 * @param current the electric current threshold to wait for, not {@code null}.
	 * @param errorHandler the error handler for validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                    this will clamp the value to the nearest valid current value.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 */
	AnalogInputCurrentWaitNodeConfig createAnalogInputCurrentConfig(AnalogIO input,
	                                                                CompareOperator compareOperator,
	                                                                Current current,
	                                                                ErrorHandler<Current> errorHandler);

	/**
	 * Creates a configuration for waiting for an analog input to go past a voltage threshold.
	 *
	 * @param input on which to wait, not {@code null}.
	 * @param compareOperator the operator to use when comparing input to value, not {@code null}. Available options are
	 *                        "less than" ({@literal <}) or "greater than" ({@literal >}).
	 * @param voltage the voltage threshold to wait for, not {@code null}.
	 * @param errorHandler the error handler for validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                    this will clamp the value to the nearest valid voltage value.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 */
	AnalogInputVoltageWaitNodeConfig createAnalogInputVoltageConfig(AnalogIO input,
	                                                                CompareOperator compareOperator,
	                                                                Voltage voltage,
	                                                                ErrorHandler<Voltage> errorHandler);

	/**
	 * Creates a configuration for waiting for a register to go past a float threshold.
	 *
	 * @param input the float register input on which to wait, not {@code null}.
	 * @param compareOperator the operator to use when comparing register to value, not {@code null}. Available options
	 *                        are "less than" ({@literal <}) or "greater than" ({@literal >}).
	 * @param valueToWaitFor the float threshold to wait for.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code input} is an output (does not support reading of values). See {@link IO#isInput()}.
	 */
	FloatRegisterInputWaitNodeConfig createFloatRegisterInputConfig(FloatRegister input,
	                                                                CompareOperator compareOperator,
	                                                                float valueToWaitFor);

	/**
	 * Create a configuration for waiting for an expression to be evaluated to true.
	 *
	 * @param expression the expression to evaluate, not {@code null}.
	 * @return the configuration.
	 */
	ExpressionInputWaitNodeConfig createExpressionInputConfig(Expression expression);
}
