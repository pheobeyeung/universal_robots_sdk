/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waypointnode;

import com.ur.urcap.api.domain.value.blend.Blend;

/**
 * @since 1.2.56
 */
public interface WaypointBlendParameters extends BlendParameters {

	/**
	 * <p>
	 * Get the blend to be used for the movement.
	 * </p>
	 *
	 * Note that, if the configuration has not been applied to a waypoint node in the program tree,
	 * the blend value returned is a "suggested" value, since the blend may be (automatically) corrected depending on
	 * surrounding waypoints in the program tree (when it is applied to a waypoint node).
	 *
	 * @return the blend for the waypoint.
	 */
	Blend getBlend();
}
