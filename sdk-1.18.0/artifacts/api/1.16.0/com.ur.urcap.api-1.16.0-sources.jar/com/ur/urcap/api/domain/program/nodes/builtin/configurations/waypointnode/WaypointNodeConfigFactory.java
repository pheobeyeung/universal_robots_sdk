/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waypointnode;

import com.ur.urcap.api.domain.userinteraction.RobotPositionCallback2;
import com.ur.urcap.api.domain.userinteraction.UserInteraction;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.blend.Blend;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import com.ur.urcap.api.domain.value.robotposition.PositionParameters;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;
import com.ur.urcap.api.domain.value.simple.AngularSpeed;
import com.ur.urcap.api.domain.value.simple.Speed;
import com.ur.urcap.api.domain.value.simple.Time;
import com.ur.urcap.api.domain.variable.Variable;
import org.osgi.annotation.versioning.ProviderType;

/**
 * @since 1.2.56
 */
@ProviderType
public interface WaypointNodeConfigFactory {

	/**
	 * <p>
	 * Creates no blend parameters for a waypoint. The waypoint will not use blending.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveJ and a MoveL.
	 *
	 * @return the blend parameters for the waypoint.
	 */
	BlendParameters createNoBlendParameters();

	/**
	 * Creates shared blend parameters for a waypoint. The waypoint will use the blend defined by the parent MoveP node.
	 *
	 * @return the blend parameter for the waypoint.
	 */
	BlendParameters createSharedBlendParameters();

	/**
	 * <p>
	 * Creates blend parameters for a waypoint.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveJ, MoveL or MoveP.
	 *
	 * @param suggestedBlend This blend may be (automatically) corrected depending on surrounding waypoints in the
	 *                       program tree, not {@code null}.
	 * @return the blend parameters for the waypoint.
	 */
	WaypointBlendParameters createWaypointBlendParameter(Blend suggestedBlend);

	/**
	 * <p>
	 * Creates shared motion parameters for a waypoint.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveJ, MoveL or a MoveP.
	 *
	 * @return the motion parameters for the waypoint.
	 */
	WaypointMotionParameters createSharedMotionParameters();

	/**
	 * <p></p>
	 * Creates time motion parameters for a waypoint.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveJ or a MoveL.
	 *
	 * @param duration the time the movement should take, not {@code null}.
	 * @param errorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid time value.
	 * @return the time motion parameters for the waypoint.
	 */
	TimeMotionParameters createTimeMotionParameters(Time duration, ErrorHandler<Time> errorHandler);

	/**
	 * <p>
	 * Creates joint motion parameters for a waypoint.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveJ.
	 *
	 * @param jointSpeed the joint speed to be achieved, not {@code null}.
	 * @param jointSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid joint speed value.
	 * @param jointAcceleration the joint acceleration to be used for the movement, not {@code null}.
	 * @param jointAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid joint acceleration value.
	 * @return the joint motion parameters for the waypoint.
	 */
	JointMotionParameters createJointMotionParameters(AngularSpeed jointSpeed,
	                                                  ErrorHandler<AngularSpeed> jointSpeedErrorHandler,
	                                                  AngularAcceleration jointAcceleration,
	                                                  ErrorHandler<AngularAcceleration> jointAccelerationErrorHandler);

	/**
	 * <p>
	 * Creates tool motion parameters for a waypoint.
	 * </p>
	 *
	 * Can be used for waypoints under a MoveL or a MoveP.
	 *
	 * @param toolSpeed the tool speed to be achieved, not {@code null}.
	 * @param toolSpeedErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool speed value.
	 * @param toolAcceleration the tool acceleration to be used for the movement, not {@code null}.
	 * @param toolAccelerationErrorHandler error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid tool acceleration value.
	 * @return the tool motion parameters for the waypoint.
	 */
	ToolMotionParameters createToolMotionParameters(Speed toolSpeed,
	                                                ErrorHandler<Speed> toolSpeedErrorHandler,
	                                                Acceleration toolAcceleration,
	                                                ErrorHandler<Acceleration> toolAccelerationErrorHandler);

	/**
	 * <p>
	 * Creates a fixed position configuration with default values for a waypoint.
	 * </p>
	 *
	 * Note that these default values may change between PolyScope versions.
	 *
	 * @return the waypoint configuration.
	 */
	FixedPositionWaypointNodeConfig createFixedPositionConfig();

	/**
	 * Creates a fixed position configuration for a waypoint without a defined pose.
	 *
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 */
	FixedPositionWaypointNodeConfig createFixedPositionConfig(BlendParameters blendParameters,
	                                                          WaypointMotionParameters waypointMotionParameters);

	/**
	 * <p>
	 * Creates a fixed position configuration for a waypoint with a defined pose.
	 * </p>
	 *
	 * @deprecated Use the {@link #createFixedPositionConfig(Pose, JointPositions, Pose, BlendParameters, WaypointMotionParameters)}
	 *             instead.
	 *
	 * @param poseIncludingTcp the position and orientation for the waypoint, not {@code null}.
	 * @param qNear the joint positions that will be used for the inverse kinematics calculations as a robot configuration
	 *              near the waypoint pose, not {@code null}.
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 */
	@Deprecated
	FixedPositionDefinedWaypointNodeConfig createFixedPositionConfig(Pose poseIncludingTcp,
	                                                                 JointPositions qNear,
	                                                                 BlendParameters blendParameters,
	                                                                 WaypointMotionParameters waypointMotionParameters);

	/**
	 * <p>
	 * Creates a fixed position configuration for a waypoint with a defined pose.
	 * </p>
	 *
	 * @param poseIncludingTcp the position and orientation for the waypoint, not {@code null}.
	 * @param qNear the joint positions that will be used for the inverse kinematics calculations as a robot configuration
	 *              near the waypoint pose, not {@code null}.
	 * @param tcpOffset the TCP offset used for calculating the final robot configuration, not {@code null}.
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 *
	 * @since 1.11.0
	 */
	FixedPositionDefinedWaypointNodeConfig createFixedPositionConfig(Pose poseIncludingTcp,
	                                                                 JointPositions qNear,
	                                                                 Pose tcpOffset,
	                                                                 BlendParameters blendParameters,
	                                                                 WaypointMotionParameters waypointMotionParameters);

	/**
	 * Creates a fixed position configuration for a waypoint with a defined pose.
	 *
	 * @param positionParameters parameters defining the robot position retrieved from a {@link RobotPositionCallback2}
	 *        implementation (submitted to the {@link UserInteraction#getUserDefinedRobotPosition(RobotPositionCallback2)}
	 *        method), not {@code null}.
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 *
	 * @since 1.10.0
	 */
	FixedPositionDefinedWaypointNodeConfig createFixedPositionConfig(PositionParameters positionParameters,
	                                                                 BlendParameters blendParameters,
	                                                                 WaypointMotionParameters waypointMotionParameters);

	/**
	 * <p>
	 * Creates a variable position configuration with default values for a waypoint
	 * </p>
	 *
	 * Note that these default values may change between PolyScope versions.
	 *
	 * @return the waypoint configuration.
	 */
	VariablePositionWaypointNodeConfig createVariablePositionConfig();

	/**
	 * Creates a variable position configuration for a waypoint without a defined variable
	 *
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 */
	VariablePositionWaypointNodeConfig createVariablePositionConfig(BlendParameters blendParameters,
	                                                                WaypointMotionParameters waypointMotionParameters);

	/**
	 * Creates a variable position configuration for a waypoint with a defined variable
	 *
	 * @param variable the variable position and orientation for the waypoint, not {@code null}.
	 * @param blendParameters the blend parameters for the waypoint, not {@code null}.
	 * @param waypointMotionParameters the motion parameters for the waypoint, not {@code null}.
	 * @return the waypoint configuration.
	 */
	VariablePositionDefinedWaypointNodeConfig createVariablePositionConfig(Variable variable,
	                                                                       BlendParameters blendParameters,
	                                                                       WaypointMotionParameters waypointMotionParameters);
}
