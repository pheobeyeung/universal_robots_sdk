/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device;


/**
 * This exception is thrown when an attempt is made to apply a configuration that is not supported by the device used by
 * a program node. It can also be thrown when attempting to reapply an existing configuration taken from a program node,
 * which uses a device that is different from the device used by the new program node.
 *
 * @since 1.11.0
 */
public class UnsupportedConfig extends RuntimeException {

	public UnsupportedConfig(String message) {
		super(message);
	}
}
