/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper;

import com.ur.urcap.api.domain.device.UnresolvedDeviceException;
import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.program.structure.TreeNode;


/**
 * This interface can be used for creating Gripper program nodes (i.e. {@link GripperNode} instances) which can be used
 * for programming grip and release actions with a selected gripper device.
 *
 * @since 1.9.0
 */
public interface GripperNodeFactory {

	/**
	 * <p>
	 * This method creates a new Gripper program node. This node type can be used for programming grip and release
	 * actions with a selected gripper device.
	 * </p>
	 *
	 * The program node will be created with the same default configuration as if the end user added the node manually
	 * in PolyScope, i.e. an undefined configuration where the gripper action is unselected.
	 *
	 * @param gripperDevice the gripper device to create a Gripper node for, not {@code null}. The created Gripper node
	 *                      will program gripper actions for this device.
	 * @return a new Gripper program node (which can be inserted into the program tree using the {@link TreeNode} interface).
	 * @throws UnresolvedDeviceException when the specified {@code gripperDevice} device is unresolved. See
	 *                                   {@link GripperDevice#isResolvable()}.
	 */
	GripperNode createGripperNode(GripperDevice gripperDevice);
}
