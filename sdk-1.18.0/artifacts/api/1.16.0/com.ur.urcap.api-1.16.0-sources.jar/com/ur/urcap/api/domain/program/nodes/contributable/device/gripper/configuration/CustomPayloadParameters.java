/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration;

import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.util.Optional;


/**
 * This interface represents a configuration of the payload setting for a Gripper node where custom payload parameters
 * are used. The specified custom payload parameters can be accessed with this interface.
 *
 * @since 1.13.0
 */
public interface CustomPayloadParameters extends PayloadSetting {

	/**
	 * <p>
	 * This method returns the total payload mass (if any is specified) to be applied after the gripper action has
	 * finished executing.
	 * </p>
	 *
	 * The payload setting on the Gripper node can be enabled with no payload mass specified (the associated 'Set Total
	 * Payload' payload mass field is empty). Therefore the payload mass is wrapped in an {@link Optional}, whose
	 * {@link Optional#isPresent()} method must always be used to check if a payload mass has been specified before
	 * accessing it using {@link Optional#get()}.
	 *
	 * @return The total payload mass wrapped in an {@link Optional}. Use {@link Optional#isPresent()} to verify that a
	 *         payload mass value has been specified before using {@link Optional#get()} to retrieve it.
	 */
	Optional<Mass> getPayloadMass();
}
