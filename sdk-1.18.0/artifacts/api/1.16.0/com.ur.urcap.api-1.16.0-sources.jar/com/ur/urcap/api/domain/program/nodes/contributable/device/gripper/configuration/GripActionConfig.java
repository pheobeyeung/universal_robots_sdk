/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration;

import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import com.ur.urcap.api.util.Optional;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents a Gripper node configuration for a grip action.
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripActionConfig extends GripperNodeConfig {

	/**
	 * <p>
	 * Determine if this configuration is a multi-gripper configuration. This will be the case, if the config was created
	 * for, or retrieved from, a Gripper node that uses a multi-gripper device, i.e. a gripper device supporting the
	 * multi-gripper capability (see the {@link MultiGripperSupport} interface).
	 * </p>
	 *
	 * This method can used to determine if:
	 * <ul>
	 *     <li>
	 *         The configuration can be applied to a Gripper node which uses a single gripper device. Note that an
	 *         exception will be thrown, if a multi-gripper configuration is applied to a Gripper node using a single
	 *         gripper device.
	 *     </li>
	 *     <li>
	 *         The {@link #getGripperSelection()} method can be used to retrieve a (valid) gripper selection (which can be
	 *         empty). Note that, if calling the {@link Optional#isPresent()} method on the retrieved {@link Optional}
	 *         instance returns {@code false}, it can both indicate that the configuration is for a single gripper (not
	 *         supporting the multi-gripper capability) as well as indicate that no gripper has been selected (an empty
	 *         gripper selection).
	 *     </li>
	 * </ul>
	 *
	 * @return {@code true} if this configuration is a multi-gripper configuration, otherwise {@code false}
	 *
	 * @since 1.11.0
	 */
	boolean isForMultiGripper();

	/**
	 * <p>
	 * This method returns the individual gripper selected (if any is selected) in a Gripper node that uses a 
	 * multi-gripper device, i.e. a gripper device supporting the multi-gripper capability (see the 
	 * {@link MultiGripperSupport} interface).
	 * </p>
	 *
	 * <b>Note:</b> This method is <b>not</b> relevant for a Gripper node using a single gripper device. The
	 * {@link #isForMultiGripper()} method can be used to determine, if this configuration is for a multi-gripper device.
	 *
	 * @return The individual gripper selection wrapped in an {@link Optional}. Use {@link Optional#isPresent()} to check,
	 *         if a gripper has been selected. The gripper selection can be retrieved using {@link Optional#get()}. Note
	 *         that {@link Optional#isPresent()} will also return {@code false}, if this configuration was created for a
	 *         single gripper. {@link #isForMultiGripper()} can be used to check if this configuration is for a
	 *         multi-gripper device.
	 *
	 * @since 1.11.0
	 */
	Optional<SelectableGripper> getGripperSelection();

	/**
	 * <p>
	 * This method returns the configuration of the payload setting for a Gripper node.
	 * </p>
	 *
	 * It is not mandatory to configure the Gripper node to apply a payload after the grip action has finished
	 * executing and the payload setting can thus be disabled/enabled. The configuration of the payload setting will not 
	 * be available here if the payload setting is disabled in the Gripper node. Therefore the returned payload setting 
	 * is wrapped in an {@link Optional}, whose {@link Optional#isPresent()} method must always be used to check if the
	 * payload setting is enabled before accessing it using {@link Optional#get()}.
	 *
	 * @return The payload setting wrapped in an {@link Optional}. Use {@link Optional#isPresent()} to check, if the
	 *         payload setting is enabled (since this is an optional setting). The payload setting can then be retrieved
	 *         using {@link Optional#get()}.
	 *
	 * @since 1.13.0
	 */
	Optional<PayloadSetting> getPayloadSetting();
}
