/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration;

import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;

import org.osgi.annotation.versioning.ProviderType;


/**
 * This base interface represents a configuration of a Gripper program node (i.e. a {@link GripperNode} instance).
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * <p>
		 * A Gripper action (i.e. grip or release) has not been selected
		 * </p>
		 *
		 * The config instance can be cast to {@link UndefinedActionConfig}. This is only relevant if the Gripper node
		 * uses a multi-gripper device, i.e. a gripper device supporting the multi-gripper capability (see the
		 * {@link MultiGripperSupport} interface). The instance will provide access to the individual gripper selection.
		 */
		UNDEFINED,

		/**
		 * <p>
		 * The gripper is configured for a grip action
		 * </p>
		 *
		 * The config instance can be cast to {@link GripActionConfig}.
		 */
		GRIP_ACTION,

		/**
		 * <p>
		 * The gripper is configured for a release action
		 * </p>
		 *
		 * The config instance can be cast to {@link ReleaseActionConfig}.
		 */
		RELEASE_ACTION
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return The type of this config.
	 */
	ConfigType getConfigType();
}
