/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.structure;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.program.nodes.contributable.URCapProgramNode;


/**
 * <p>
 * This class is used in conjunction with the {@link TreeNode#traverse(ProgramNodeVisitor)} method to visit all nodes in
 * the sub-tree under the node on which {@link TreeNode#traverse(ProgramNodeVisitor)} is called.
 * </p>
 *
 * <p>
 * The (generic) type parameter must be an interface that a URCap ProgramNodeContribution also implements. The
 * {@link URCapProgramNodeInterfaceVisitor#visitURCapAs(Object, int, int)} method will be called when such a program node
 * is encountered.
 * </p>
 *
 * <p>
 * All the visit-methods in the {@link ProgramNodeVisitor} superclass can still be overridden and will be called as usual.
 * </p>
 *
 * See also {@link URCapProgramNode#getAs(Class)}.
 *
 * @param <URCAP_PROGRAM_NODE_INTERFACE> The interface a URCap ProgramNodeContribution also implements. Do not use
 *                                       {@link ProgramNodeContribution} (or an extension/implementation thereof) nor
 *                                       {@link Object}, otherwise an {@link IllegalArgumentException} is thrown when a
 *                                       URCap program node is encountered during traversal.
 *
 * @since 1.2.56
 */
public abstract class URCapProgramNodeInterfaceVisitor<URCAP_PROGRAM_NODE_INTERFACE> extends ProgramNodeVisitor {

	/**
	 * This method is called whenever a URCap program node implementing the interface specified is encountered.
	 *
	 * @param urCapProgramNode The URCap program node represented as the interface specified.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node is
	 *              at depth 0).
	 */
	public abstract void visitURCapAs(URCAP_PROGRAM_NODE_INTERFACE urCapProgramNode, int index, int depth);
}
