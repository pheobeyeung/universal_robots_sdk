/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource;

import com.ur.urcap.api.domain.InstallationAPI;
import com.ur.urcap.api.domain.resource.tooliointerface.ToolIOInterface;


/**
 * <p>
 * This interface provides access to query settings/state of system resources.
 * </p>
 *
 * To request the control of a resource, see the {@link ControllableResourceModel} interface which is accessible through
 * {@link InstallationAPI#getControllableResourceModel()}.
 *
 * @since 1.7.0
 */
public interface ResourceModel {

	/**
	 * @return An interface for querying the settings of the Tool I/O Interface.
	 */
	ToolIOInterface getToolIOInterface();
}
