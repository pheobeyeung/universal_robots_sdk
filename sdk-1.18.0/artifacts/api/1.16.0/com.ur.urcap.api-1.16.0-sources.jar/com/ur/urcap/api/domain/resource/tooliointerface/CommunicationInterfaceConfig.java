/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface;

import com.ur.urcap.api.domain.resource.tooliointerface.control.AnalogInputModeConfigFactory;
import com.ur.urcap.api.domain.resource.tooliointerface.control.ToolIOInterfaceControllable;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import static com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability.COMMUNICATION_INTERFACE_MODE;


/**
 * <p>
 * This interface represents the Tool Communication Interface (TCI) configuration for the two analog inputs in the Tool
 * I/O Interface.
 * </p>
 *
 * <p>
 * This configuration can be applied to enable communication with an external device via the tool's analog inputs hereby
 * avoiding external wiring. When this configuration is applied, all analog tool inputs will be unavailable.
 * </p>
 *
 * <p>
 * To create a new configuration, see the {@link AnalogInputModeConfigFactory} interface which is accessible through
 * {@link ToolIOInterfaceControllable#getAnalogInputModeConfigFactory()}. <br>
 *
 * To apply a configuration, see {@link ToolIOInterfaceControllable#setAnalogInputModeConfig(AnalogInputModeConfig)}.
 * </p>
 *
 * @since 1.7.0
 */
@RequiredCapability(COMMUNICATION_INTERFACE_MODE)
public interface CommunicationInterfaceConfig extends AnalogInputModeConfig {

	/**
	 * Available options for the baud rate used for communication
	 */
	enum BaudRate {
		BAUD_9600,
		BAUD_19200,
		BAUD_38400,
		BAUD_57600,
		BAUD_115200,
		BAUD_1M,
		BAUD_2M,
		BAUD_5M
	}

	/**
	 * Available options for the parity used for communication
	 */
	enum Parity {
		NONE,
		ODD,
		EVEN
	}

	/**
	 * Available options for the number of stop bits used for communication
	 */
	enum StopBits {
		ONE,
		TWO
	}

	/**
	 * @return the baud rate
	 */
	BaudRate getBaudRate();

	/**
	 * @return the parity
	 */
	Parity getParity();

	/**
	 * @return the number of stop bits
	 */
	StopBits getStopBits();

	/**
	 * Amount of chars the RX unit in the robot tool should wait before marking a message as over / sending it to the PC.
	 *
	 * @return the amount of RX idle chars
	 */
	double getRxIdleChars();

	/**
	 * Amount of chars the TX unit in the robot tool should wait before starting a new transmission since last activity on
	 * the communication bus
	 *
	 * @return the amount of TX idle chars
	 */
	double getTxIdleChars();
}
