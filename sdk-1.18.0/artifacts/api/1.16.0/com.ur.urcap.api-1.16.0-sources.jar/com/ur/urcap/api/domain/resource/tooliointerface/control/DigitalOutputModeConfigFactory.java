/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface.control;

import com.ur.urcap.api.domain.resource.tooliointerface.DigitalOutputModeConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.StandardDigitalOutputModeConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.StandardDigitalOutputModeConfig.OutputMode;
import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import static com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability.DIGITAL_OUTPUT_MODE;


/**
 * <p>
 * Factory for creating configurations of the digital output mode for the digital outputs in the connector in the robot
 * tool.
 * </p>
 *
 * Use {@link CapabilityManager#hasCapability(Capability)} with {@link ToolIOCapability#DIGITAL_OUTPUT_MODE} as argument
 * to verify the availability of this functionality on the system.
 *
 * @since 1.7.0
 */
@RequiredCapability(DIGITAL_OUTPUT_MODE)
public interface DigitalOutputModeConfigFactory {

	/**
	 * Create a Dual Pin Power mode configuration where both digital outputs in the connector in the robot tool are used
	 * as a source of power for the tool. This configuration disables the two digital tool outputs.
	 *
	 * @return a Dual Pin Power mode configuration for the digital tool outputs
	 */
	DigitalOutputModeConfig createDualPinPowerModeConfig();

	/**
	 * Create a configuration to set the digital output mode for each of the digital outputs in the connector in the
	 * robot tool.
	 *
	 * @param output0 the output mode for digital tool output 0
	 * @param output1 the output mode for digital tool output 1
	 * @return a digital output mode configuration for the digital tool outputs
	 */
	StandardDigitalOutputModeConfig createStandardDigitalOutputModeConfig(OutputMode output0, OutputMode output1);
}
