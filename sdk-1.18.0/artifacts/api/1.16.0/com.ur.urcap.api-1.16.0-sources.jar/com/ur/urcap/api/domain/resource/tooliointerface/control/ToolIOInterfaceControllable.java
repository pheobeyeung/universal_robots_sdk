/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface.control;

import com.ur.urcap.api.domain.resource.tooliointerface.AnalogInputModeConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.DigitalOutputModeConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.ToolIOInterface;
import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.CapabilityNotSupportedException;
import com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import static com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability.DIGITAL_OUTPUT_MODE;


/**
 * This is an interface for controlling/configuring the settings of the Tool I/O Interface
 *
 * @since 1.7.0
 */
public interface ToolIOInterfaceControllable extends ToolIOInterface {

	/**
	 * <p>
	 * This method can be used to verify, if this URCap controls the Tool I/O Interface resource (after the control has
	 * been granted the URCap).
	 * </p>
	 *
	 * The URCap will not control the resource, if the control is reassigned to a different URCap or manual control for
	 * the end user is selected. A callback will be generated when the control is revoked,
	 * see {@link ToolIOInterfaceController#onControlToBeRevoked(ToolIOInterfaceControlEvent)}.
	 *
	 * @return {@code true}, if this instance is in control. {@code false} otherwise (the control has been revoked).
	 */
	boolean hasControl();

	/**
	 * Sets the tool output voltage level for the power supply that delivers power to the connector in the robot tool.
	 *
	 * @param outputVoltage The tool output voltage level.
	 * @throws IllegalStateException If the caller does not have control (see {@link #hasControl()})
	 */
	void setOutputVoltage(OutputVoltage outputVoltage);

	/**
	 * @return A factory for creating configurations of the digital output mode for the digital outputs in the connector
	 *         in the robot tool
	 * @throws CapabilityNotSupportedException If the digital output mode capability is not available on the system.
	 *                                         Use {@link CapabilityManager#hasCapability(Capability)} with 
	 *                                         {@link ToolIOCapability#DIGITAL_OUTPUT_MODE} as argument to verify the 
	 *                                         availability.
	 */
	@RequiredCapability(DIGITAL_OUTPUT_MODE)
	DigitalOutputModeConfigFactory getDigitalOutputModeConfigFactory();

	/**
	 * <p>
	 * Configure the digital output mode for the digital outputs in the connector in the robot tool.
	 * </p>
	 *
	 * Use {@link #getDigitalOutputModeConfigFactory()} to access a factory for creating configurations.
	 *
	 * @param config The configuration of the digital output mode for the digital tool outputs
	 * @throws IllegalStateException If the caller does not have control (see {@link #hasControl()})
	 * @throws CapabilityNotSupportedException If the digital output mode capability is not available on the system.
	 *                                         Use {@link CapabilityManager#hasCapability(Capability)} with 
	 *                                         {@link ToolIOCapability#DIGITAL_OUTPUT_MODE} as argument to verify the 
	 *                                         availability.
	 */
	@RequiredCapability(DIGITAL_OUTPUT_MODE)
	void setDigitalOutputModeConfig(DigitalOutputModeConfig config);

	/**
	 * @return A factory for creating configurations of the analog input mode for the analog inputs in the connector in
	 * the robot tool.
	 */
	AnalogInputModeConfigFactory getAnalogInputModeConfigFactory();

	/**
	 * <p>
	 * Configure the analog input mode for the analog inputs in the connector in the robot tool.
	 * </p>
	 *
	 * Use {@link #getAnalogInputModeConfigFactory()} to access a factory for creating configurations.
	 *
	 * @param config The configuration of the analog input mode for the analog tool inputs
	 * @throws IllegalStateException If the caller does not have control (see {@link #hasControl()})
	 */
	void setAnalogInputModeConfig(AnalogInputModeConfig config);
}
