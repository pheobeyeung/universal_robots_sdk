/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.robot;

import org.osgi.annotation.versioning.ProviderType;


/**
 * With this interface you can determine the robot type/model and series as well as other properties of the underlying
 * Universal Robots robot.
 *
 * @since 1.0.0
 */
@ProviderType
public interface RobotModel {

	/**
	 * The different types/models of Universal Robots robots
	 */
	enum RobotType {
		UNKNOWN,
		UR3,
		UR5,
		UR7,
		UR10,
		UR12,
		UR16,
		UR20,
		UR30
	}

	/**
	 * The different robot series (generations) of Universal Robots robots
	 *
	 * @deprecated See {@link #getRobotSeries()}
	 *
	 * @since 1.6.0
	 */
	@Deprecated
	enum RobotSeries {
		UNKNOWN,
		CB3,
		E_SERIES
	}

	/**
	 *
	 * @return The type/model of the underlying Universal Robots robot
	 */
	RobotType getRobotType();

	/**
	 * @deprecated This method can only be used to determine, if a robot belongs to the CB3 robot series. The method will
	 * return the value {@link RobotSeries#CB3}, if the underlying robot is a CB3 robot, whereas the
	 * {@link RobotSeries#E_SERIES} value is returned for an e-Series robot. The {@link RobotSeries#UNKNOWN} value will be
	 * returned for all robots belonging to other robot series.
	 *
	 * @return The robot series (generation) of the underlying Universal Robots robot.
	 *
	 * @since 1.6.0
	 */
	@Deprecated
	RobotSeries getRobotSeries();

	/**
	 * <p>
	 * Each Universal Robots robot type/model has limits for various physical/hardware and software properties/parameters.
	 * This method can be used to obtain an interface which provides access to the valid range for each property/parameter
	 * supported by the underlying robot, such as the supported range for the mass of the payload attached to the robot's
	 * tool output flange.
	 * </p>
	 *
	 * These ranges (limits) can, for instance, be used for validation of input provided by the end user.
	 *
	 * @return An interface providing access to the limits for various properties/parameters of the underlying Universal
	 *         Robots robot.
	 *
	 * @since 1.13.0
	 */
	RobotLimits getRobotLimits();

	/**
	 *
	 * @return The serial number of the underlying Universal Robots robot
	 */
	String getSerialNumber();
}
