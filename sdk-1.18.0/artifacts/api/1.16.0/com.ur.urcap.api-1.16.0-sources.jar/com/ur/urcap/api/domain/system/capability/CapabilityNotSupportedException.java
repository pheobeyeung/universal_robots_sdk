/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.system.capability;


/**
 * <p>
 * This exception is thrown when trying to use a capability which is not supported by the underlying robot/system.
 * </p>
 *
 * Use {@link CapabilityManager#hasCapability(Capability)} to verify the presence of a given capability before using it.
 *
 * @since 1.7.0
 */
public class CapabilityNotSupportedException extends RuntimeException {

	public CapabilityNotSupportedException(String message) {
		super(message);
	}
}
