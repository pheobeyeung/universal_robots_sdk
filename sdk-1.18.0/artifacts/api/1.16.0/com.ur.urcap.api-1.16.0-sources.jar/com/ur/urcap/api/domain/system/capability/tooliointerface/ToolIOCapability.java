/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.system.capability.tooliointerface;

import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;


/**
 * <p>
 * This {@code enum} contains capabilities of the Tool I/O Interface that may or may not be available on the underlying
 * robot/system. Functionality related to the Tool I/O Interface is located in the package
 * {@link com.ur.urcap.api.domain.resource.tooliointerface}.
 * </p>
 *
 * <p>
 * Use a value of this {@code enum} as argument to {@link CapabilityManager#hasCapability(Capability)} to check if that
 * specific capability is present on the system.
 * </p>
 *
 * @since 1.7.0
 */
public enum ToolIOCapability implements Capability {

	/**
	 * <p>
	 * Capability to configure the analog inputs in the connector in the robot tool to be used as a Tool Communication
	 * Interface (TCI).
	 * </p>
	 *
	 * Note: This functionality is not available on CB3 robots
	 */
	COMMUNICATION_INTERFACE_MODE,

	/**
	 * <p>
	 * Capability to configure output mode of the digital outputs in the connector in the robot tool.
	 * </p>
	 *
	 * Note: This functionality is not available on CB3 robots
	 */
	DIGITAL_OUTPUT_MODE
}
