/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction;

import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;


/**
 * <p>
 * The robot position callback. Override this abstract class to execute custom code when the end user accepts or cancels
 * inputting a robot position.
 * </p>
 *
 * @deprecated Use {@link RobotPositionCallback2} instead.
 *
 * @since 1.2.56
 */
@Deprecated
public abstract class RobotPositionCallback {

	/**
	 * This method is called if the end user accepts the robot position. Overriding this method is mandatory.
	 *
	 * @param pose the pose of the robot.
	 * @param q the joint positions of the robot.
	 */
	public abstract void onOk(Pose pose, JointPositions q);

	/**
	 * This method is called if the end user cancels inputting the robot position. Overriding this method is optional.
	 */
	public void onCancel() {

	}
}
