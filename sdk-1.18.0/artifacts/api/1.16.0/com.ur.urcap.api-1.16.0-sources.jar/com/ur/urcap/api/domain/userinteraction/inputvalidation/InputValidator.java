/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.inputvalidation;


/**
 * <p>
 * Interface representing the input validators created by {@link InputValidationFactory}. This factory provides a set of
 * standard input validators that can be used for validating the input entered by the user using the virtual keyboard/keypad.
 * </p>
 *
 * If the standard validators available in the {@link InputValidationFactory} does not satisfy your needs, you are free
 * to implement your own custom validator.
 *
 * @param <T> the (generic) type parameter for the interface representing the type of input data being validated (e.g.
 *            Integer or Double).
 *
 * @since 1.3.0
 */
public interface InputValidator<T> {

	/**
	 * @param value to be validated.
	 * @return {@code true} if value is valid.
	 */
	boolean isValid(T value);

	/**
	 * Returns a meaningful message in case the value is not valid.
	 *
	 * @param value the invalid value. Can be included in the message if it makes sense.
	 * @return message.
	 */
	String getMessage(T value);
}
