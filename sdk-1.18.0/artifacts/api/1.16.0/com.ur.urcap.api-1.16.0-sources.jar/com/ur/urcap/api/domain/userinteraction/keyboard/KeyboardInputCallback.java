/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.keyboard;


/**
 * Callback used when the virtual keyboard/keypad is exited by the end user. Override this abstract class to execute
 * custom code when the end user accepts or cancels the input.
 *
 * @param <T> The (generic) type parameter for the interface representing the type of input data entered by the end
 *            user, e.g. {@link Integer} and {@link Double}.
 *
 * @since 1.3.0
 */
public abstract class KeyboardInputCallback<T> {

	/**
	 * This method is called if the end user accepts the keyboard/keypad input. Overriding this method is mandatory.
	 *
	 * @param value accepted value.
	 */
	public abstract void onOk(T value);

	/**
	 * This method is called if the end user cancels the input. Overriding this method is optional.
	 */
	public void onCancel() {

	}
}
