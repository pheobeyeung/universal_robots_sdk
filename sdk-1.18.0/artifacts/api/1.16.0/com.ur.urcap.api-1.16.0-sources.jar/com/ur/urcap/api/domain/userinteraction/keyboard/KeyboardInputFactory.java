/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.keyboard;


/**
 * <p>
 * Factory for creating keyboard inputs which are used to configure the virtual keyboard/keypad and to request it to be
 * displayed for a Swing GUI component. The typical Swing component most commonly used is a {@link javax.swing.JTextField}.
 * </p>
 *
 * NOTE: This functionality is only relevant for URCap nodes with a Swing-based user interface
 * (see {@link com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService},
 * {@link com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeService} and
 * {@link com.ur.urcap.api.contribution.toolbar.swing.SwingToolbarService}).
 *
 * @since 1.3.0
 */
public interface KeyboardInputFactory {

	/**
	 * <p>
	 * Creates a standard virtual keyboard input accepting string/text input
	 * </p>
	 *
	 * If no input validator is specified, all strings are accepted.
	 *
	 * @return new instance of KeyboardTextInput.
	 */
	KeyboardTextInput createStringKeyboardInput();

	/**
	 * <p>
	 * Creates a standard virtual keyboard input accepting password string/text input. When the end user types, asterisks
	 * are shown instead of the original characters.
	 * </p>
	 *
	 * If no input validator is specified, all strings are accepted.
	 *
	 * @return new instance of KeyboardTextInput.
	 */
	KeyboardTextInput createPasswordKeyboardInput();

	/**
	 * Creates a virtual keyboard input accepting IPv4 addresses. The keyboards accepts any IPv4 address (ensuring the
	 * correct format) and returns it as a string.
	 *
	 * @return new instance of {@code KeyboardTextInput}.
	 */
	KeyboardTextInput createIPAddressKeyboardInput();

	/**
	 * <p>
	 * Creates a virtual numeric keypad input accepting doubles
	 * </p>
	 *
	 * If no input validator is specified, all double values are accepted.
	 *
	 * @return new instance of {@code KeyboardNumberInput<Double>}.
	 */
	KeyboardNumberInput<Double> createDoubleKeypadInput();

	/**
	 * <p>
	 * Creates a virtual numeric keypad input accepting positive doubles. The minus ('-') button on the keypad will
	 * be disabled.
	 * </p>
	 *
	 * If no input validator is specified, all positive double values are accepted.
	 *
	 * @return new instance of {@code KeyboardNumberInput<Double>}.
	 */
	KeyboardNumberInput<Double> createPositiveDoubleKeypadInput();

	/**
	 * <p>
	 * Creates a virtual numeric keypad input accepting integers. The dot ('.') button on the keypad will
	 * be disabled.
	 * </p>
	 *
	 * If no input validator is specified, all integer values are accepted.
	 *
	 * @return new instance of {@code KeyboardNumberInput<Integer>}.
	 */
	KeyboardNumberInput<Integer> createIntegerKeypadInput();

	/**
	 * <p>
	 * Creates a virtual numeric keypad input accepting positive integers. The minus ('-') and the dot ('.') buttons on
	 * the keypad will be disabled.
	 * </p>
	 *
	 * If no input validator is specified, all positive integer values are accepted.
	 *
	 * @return new instance of {@code KeyboardNumberInput<Integer>}.
	 */
	KeyboardNumberInput<Integer> createPositiveIntegerKeypadInput();
}
