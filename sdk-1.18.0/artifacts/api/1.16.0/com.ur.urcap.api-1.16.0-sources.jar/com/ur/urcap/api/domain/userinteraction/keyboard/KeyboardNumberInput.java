/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.keyboard;

import com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;


/**
 * Interface representing the virtual numeric keypad used for configuring it and requesting it to be displayed in
 * PolyScope.
 *
 * @param <T> The (generic) type parameter for the interface representing the type of input data entered by the end
 *            user via the virtual keypad. Relevant types are e.g. {@link Integer} and {@link Double}.
 *
 * @since 1.3.0
 */
public interface KeyboardNumberInput<T>{

	/**
	 * <p>
	 * Sets an input validator for the virtual numeric keypad. This validator will be used to validate the input entered
	 * by the end user. Some standard validators are available in
	 * {@link com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidationFactory}.
	 * </p>
	 *
	 * <p>
	 * Specifying an input validator is recommended, but optional.
	 * </p>
	 *
	 * In case {@link InputValidator#isValid(Object)} returns {@code false}, the accept button on the virtual keypad will
	 * be disabled and the error message from {@link InputValidator#getMessage(Object)} will be shown.
	 *
	 * @param validator the validator to be used to validate keypad user input.
	 * @return this KeyboardNumberInput object.
	 * @throws NullPointerException in case the validator is {@code null}.
	 */
	KeyboardNumberInput<T> setErrorValidator(InputValidator<T> validator);

	/**
	 * Sets the initial value which will be displayed when the virtual numeric keypad is shown.
	 *
	 * @param initialValue the initial value for the virtual keypad.
	 * @return this KeyboardNumberInput object.
	 */
	KeyboardNumberInput<T> setInitialValue(T initialValue);

	/**
	 * This method requests the virtual numeric keypad to be shown.
	 *
	 * @param component the JTextField that will be used to define the screen position of the virtual keypad.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the end user exits the keypad by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JTextField component, KeyboardInputCallback<T> callback);

	/**
	 * This method requests the virtual numeric keypad to be shown.
	 *
	 * @param component the JLabel that will be used to define the screen position of the virtual keypad.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the end user exits the keypad by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JLabel component, KeyboardInputCallback<T> callback);

	/**
	 * This method requests the virtual keypad to be shown.
	 *
	 * @param component the JButton that will be used to define the screen position of the virtual keypad.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the end user exits the keypad by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JButton component, KeyboardInputCallback<T> callback);
}

