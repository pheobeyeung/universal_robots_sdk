/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.robot.movement;


/**
 * This interface holds information relevant to the onError event that occurs when an error was encountered in a request
 * to move the robot.
 *
 * @since 1.5.0
 */
public interface MovementErrorEvent {

	enum ErrorType {

		UNKNOWN,

		/**
		 * The specified target pose is not reachable from the current robot position or not reachable for this robot
		 * type (i.e. inverse kinematics failed to find a solution).
		 */
		UNREACHABLE_POSE,

		/**
		 * The specified target joint positions are out of range for the robot type.
		 */
		INVALID_JOINT_POSITIONS
	}

	/**
	 * Use this method to determine the type of error that occurred in a robot movement request.
	 *
	 * @return The type of error.
	 */
	ErrorType getErrorType();
}
