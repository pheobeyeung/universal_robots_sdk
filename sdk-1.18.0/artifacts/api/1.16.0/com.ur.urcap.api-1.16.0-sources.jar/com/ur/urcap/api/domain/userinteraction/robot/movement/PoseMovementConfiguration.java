/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.robot.movement;

import com.ur.urcap.api.domain.value.simple.Speed;
import org.osgi.annotation.versioning.ProviderType;

/**
 * This interface represents an object for requesting the user to move the robot to a certain position at an optional speed.
 *
 * @since 1.15.0
 */
@ProviderType
public interface PoseMovementConfiguration {

	/**
	 * <p>
	 * Set an optional speed that the robot should move at.
	 * The requested speed must be higher than 0.0.
	 * If the speed is not set or higher than the upper limit, the robot will move at the default speed.
	 * </p>
	 *
	 * @param speed The speed that the robot should move at during auto move.
	 *
	 * @since 1.15.0
	 */
	void setSpeed(Speed speed);
}
