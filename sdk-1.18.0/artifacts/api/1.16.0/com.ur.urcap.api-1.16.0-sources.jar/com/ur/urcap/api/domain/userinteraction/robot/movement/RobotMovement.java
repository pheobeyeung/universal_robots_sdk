/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.robot.movement;

import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides functionality for requesting the end user to move the robot.
 *
 * @since 1.5.0
 */
@ProviderType
public interface RobotMovement {

	/**
	 * <p>
	 * Transition to the Automove screen to allow/request the end user to move the robot (either automatically or manually)
	 * to a desired target position specified by joint positions.
	 * </p>
	 *
	 * <p>
	 * The Automove function will move the robot to the target joint positions linearly in joint space.
	 * </p>
	 *
	 * <b>NOTE:</b> This method does not take the currently active TCP offset into account, i.e. the Automove function
	 * will have the specified joint positions as target.
	 *
	 * @param q The target joint positions to move to.
	 * @param callback The instance which callbacks will be made to.
	 * @throws IllegalStateException If the URCap screen is not active (visible).
	 */
	void requestUserToMoveRobot(JointPositions q, RobotMovementCallback callback);

	/**
	 * <p>
	 * Transition to the Automove screen to allow/request the end user to move the robot (either automatically or manually)
	 * to a desired target position specified by a pose.
	 * </p>
	 *
	 * <p>
	 * The Automove function will move the robot TCP to the target position linearly in Cartesian space. If this it not
	 * possible, the robot will move to the target linearly in joint space.
	 * </p>
	 *
	 * The current joint positions of the robot will be used as starting point for inverse kinematics to calculate a
	 * target joint vector corresponding to desired pose, taking the currently active TCP offset into account.
	 *
	 * @param pose The target pose the robot TCP will move to.
	 * @param callback The instance which callbacks will be made to.
	 * @throws IllegalStateException If the URCap screen is not active (visible).
	 */
	void requestUserToMoveRobot(Pose pose, RobotMovementCallback callback);

	/**
	 * <p>
	 * Transition to the Automove screen to allow/request the end user to move the robot (either automatically or manually)
	 * to a desired target position specified by a pose at the desired speed specified.
	 * </p>
	 *
	 * <p>
	 * The Automove function will move the robot TCP to the target position linearly in Cartesian space. If this it not
	 * possible, the robot will move to the target linearly in joint space.
	 * </p>
	 *
	 * The current joint positions of the robot will be used as starting point for inverse kinematics to calculate a
	 * target joint vector corresponding to desired pose, taking the currently active TCP offset into account.
	 *
	 * @param poseMovementConfiguration A configuration object containing the target pose the robot TCP will move to and the speed it will move at.
	 * @param callback The instance which callbacks will be made to.
	 * @throws IllegalStateException If the URCap screen is not active (visible).
	 *
	 * @since 1.15.0
	 */
	void requestUserToMoveRobot(PoseMovementConfiguration poseMovementConfiguration, RobotMovementCallback callback);

	/**
	 * <p>
	 * Create a robot movement configuration object to be used for robot movement.
	 * This object will hold the pose that the robot is moved to and the speed it will move at.
	 * </p>
	 *
	 * @param pose The target pose the robot TCP will move to.
	 * @return a robot movement configuration object to be used for robot movement.
	 *
	 * @since 1.15.0
	 */
	PoseMovementConfiguration createPoseMovementConfiguration(Pose pose);
}
