/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.robot.movement;


/**
 * <p>
 * The robot movement callback.
 * </p>
 *
 * Extend this abstract class to execute custom code when the end user accepts/cancels the request to move the robot or
 * when errors occur.
 *
 * @since 1.5.0
 */
public abstract class RobotMovementCallback {

	/**
	 * <p>
	 * This method is called when the robot has been moved to the desired target position by the end user.
	 * </p>
	 *
	 * This method must be overridden.
	 *
	 * @param event This object holds information related to the onComplete event.
	 */
	public abstract void onComplete(MovementCompleteEvent event);

	/**
	 * <p>
	 * This method is called if the end user cancels the move request (before reaching the target position).
	 * </p>
	 *
	 * Overriding this method is optional.
	 *
	 * @param event This object holds information related to the onCancel event.
	 */
	public void onCancel(MovementCancelEvent event) {

	}

	/**
	 * <p>
	 * This method is called when an error occurs in the move request.
	 * </p>
	 *
	 * Overriding this method is optional.
	 *
	 * @param event This object holds information related to the onError event.
	 */
	public void onError(MovementErrorEvent event) {

	}
}
