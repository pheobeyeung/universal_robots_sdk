/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.validation;

/**
 * @since 1.2.56
 */
public interface ErrorHandler<V> {

	/**
	 * <p>
	 * Handler to automatically correct a value used for configuring a node when the value is not valid.
	 * </p>
	 *
	 * Valid values depend on the constraints of the specific field. In most cases AUTO_CORRECT will use the nearest
	 * valid value.
	 */
	ErrorHandler AUTO_CORRECT = null;

	/**
	 * Callback in case of a validation error.
	 *
	 * @param invalidValue Value that violated a constraint.
	 * @param nearestValidValue Acceptable value for field.
	 * @param errorMessage Message describing the validation error.
	 * @return new value to use instead of invalidValue.
	 */
	V onError(V invalidValue, V nearestValidValue, String errorMessage);
}
