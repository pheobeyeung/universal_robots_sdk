/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Angle;
import com.ur.urcap.api.domain.value.simple.Length;


/**
 * <p>
 * This interface represents a pose in Cartesian space (relative to a reference coordinate system).
 * </p>
 *
 * A pose can, fe.g. describe the position of the robot tool (e.g. w.r.t. to robot base) or the TCP offset (relative to
 * the center of the tool output flange).
 *
 * @since 1.0.0
 */
public interface Pose {

	/**
	 * @return The Cartesian position part of the pose.
	 */
	Position getPosition();

	/**
	 * @return The Cartesian rotation part (orientation) of the pose.
	 */
	Rotation getRotation();

	/**
	 * Provides an array containing the X, Y, Z coordinates of the position part and the Rx, Ry, Rz parameters of the
	 * rotation part.
	 *
	 * @deprecated Use {@link #toArray(Length.Unit, Angle.Unit)} instead.
	 *
	 * @return A new array with the X, Y, Z coordinates in meters (position part) and Rx, Ry, Rz parameters in radians
	 *         (rotation part).
	 */
	@Deprecated
	double[] toArray();

	/**
	 * Provides an array containing the X, Y, Z coordinates of the position part and the Rx, Ry, Rz parameters of the
	 * rotation part in specified units.
	 *
	 * @param lengthUnit The length unit for which to return the X, Y, Z coordinates.
	 * @param angleUnit  The angular unit for which to return the Rx, Ry, Rz orientation parameters.
	 * @return A new array with the values of the X, Y, Z coordinates (position part) and Rx, Ry, Rz parameters
	 *         (rotation part) in specified units.
	 */
	double[] toArray(Length.Unit lengthUnit, Angle.Unit angleUnit);

	/**
	 * @return The hash code of this object.
	 */
	int hashCode();

	/**
	 * Indicates whether some other {@code Pose} object is "equal to" this object.
	 *
	 * @param obj Another {@code Pose} object.
	 * @return {@code true} if the Cartesian position and rotation values of this {@code Pose} instance and the
	 *         {@code obj} argument are exactly the same; otherwise {@code false}.
	 */
	boolean equals(Object obj);

	/**
	 * Indicates whether some other {@code Pose} object is "approximately equal" to this object.
	 *
	 * @deprecated Use {@link #epsilonEquals(Pose, double, Length.Unit, double, Angle.Unit)} instead.
	 *
	 * @param other Another {@code pose} object.
	 * @param epsilon A tolerance value (in SI units) used for comparing the X, Y, Z coordinate values and Rx, Ry, Rz
	 *                orientation parameters.
	 * @return {@code true} if the values of this object are "approximately equal" to the values of the {@code other}
	 *          argument; {@code false} otherwise.
	 */
	@Deprecated
	boolean epsilonEquals(Pose other, double epsilon);

	/**
	 * <p>
	 * Indicates whether some other {@code Pose} is "approximately equal" to this one.
	 * </p>
	 *
	 * Two poses are considered "approximately equal", if all the absolute differences between corresponding values of
	 * the two poses (i.e. the position coordinates and rotation parameters) are less than or equal to the specified
	 * tolerances. The distance metric used is the L-infinite metric (also called the maximum metric) with the equality
	 * criterion defined in the form of:<br>
	 * MAX( abs(X1-x2), abs(y1-y2), abs(z1-z2) ) <= positionEpsilon AND
	 * MAX( abs(rx1-rx2), abs(ry1-ry2), abs(rz1-rz2) ) <= rotationEpsilon
	 *
	 * @param other         Another {@code Pose} object.
	 * @param positionEpsilon The tolerance value to be used for the comparison of X, Y, Z coordinates in specified units.
	 * @param lengthUnit    The length unit for the specified {@code positionEpsilon} tolerance.
	 * @param rotationEpsilon  The tolerance value to be used for the comparison of Rx, Ry, Rz orientation parameters in
	 *                      specified units.
	 * @param angleUnit     The angular unit for the specified {@code rotationEpsilon} tolerance.
	 * @return {@code true} if the values of this object are "approximately equal" to the values of the {@code other}
	 *         argument; {@code false} otherwise.
	 *
	 * @since 1.2.56
	 */
	boolean epsilonEquals(Pose other,
	                      double positionEpsilon, Length.Unit lengthUnit,
	                      double rotationEpsilon, Angle.Unit angleUnit);

	/**
	 * @return A string representation of the pose.
	 */
	String toString();
}
