/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Angle;
import com.ur.urcap.api.domain.value.simple.Length;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface provides methods for creating poses in Cartesian space (relative to a reference coordinate system).
 * </p>
 *
 * A pose can, e.g. describe the position of the robot tool (e.g. w.r.t. to robot base) or the TCP offset
 * (relative to the center of the tool output flange).
 *
 * @since 1.2.56
 */
@ProviderType
public interface PoseFactory {

	/**
	 * <p>
	 * Creates an object representing a pose with the specified Cartesian position and orientation (rotation).
	 * </p>
	 *
	 * Use {@link PositionFactory#createPosition(double, double, double, Length.Unit)} and
	 * {@link RotationFactory#createRotation(double, double, double, Angle.Unit)} to create the position and rotation 
	 * parameters, respectively.
	 *
	 * @param position The Cartesian position of the pose. 
	 * @param rotation The rotation vector specifying the Cartesian orientation of the pose
	 * @return A new pose.
	 *
	 * @since 1.13.0
	 */
	Pose createPose(Position position, Rotation rotation);

	/**
	 * Creates an object representing a pose with the specified Cartesian position and orientation (rotation)
	 *
	 * @param x X coordinate of the Cartesian position.
	 * @param y Y coordinate of the Cartesian position.
	 * @param z Z coordinate of the Cartesian position.
	 * @param rx Rx parameter of the rotation vector specifying the Cartesian orientation.
	 * @param ry Ry parameter of the rotation vector specifying the Cartesian orientation.
	 * @param rz Rz parameter of the rotation vector specifying the Cartesian orientation.
	 * @param lengthUnit The length unit for the specified coordinates of the Cartesian position.
	 * @param angleUnit The angular unit for the specified parameters of the Cartesian rotation.
	 * @return A new pose.
	 */
	Pose createPose(double x, double y, double z, double rx, double ry, double rz, Length.Unit lengthUnit, Angle.Unit angleUnit);
}
