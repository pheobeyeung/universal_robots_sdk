/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Mass;


/**
 * <p>
 * This interface represents (describes) an inclusive range (or "interval") of numeric values of the same type defined by
 * a minimum and maximum value. The value type for the range can, for instance, be a simple value type, such as
 * {@link Length} and {@link Mass}.
 * </p>
 *
 * <p>
 * A range is defined to contain all the values between the minimum value (see {@link #getLowerBound()}) and the maximum
 * value (see {@link #getUpperBound()}), where the minimum/maximum value (or lower bound/upper bound) are included in the
 * range.
 * </p>
 *
 * The range can be used to describe/define the limits or requirements for a parameter, e.g. "lengths must be between
 * 0.0 mm and 5000.0 mm inclusive" (i.e., 0.0 mm <= l <= 5000.0 mm).
 *
 * @param <T> The type of value for this range, e.g. a simple value type, like {@link Length}.
 *
 * @since 1.13.0
 */
public interface Range<T> {

	/**
	 * @return The minimum value (lower endpoint) for this range
	 */
	T getLowerBound();

	/**
	 * @return The maximum value (upper endpoint) for this range
	 */
	T getUpperBound();

	/**
	 * <p>
	 * This method will evaluate if the specified value is within the bounds of the range, bounds inclusive.
	 * </p>
	 *
	 * A value is considered to be within the range, if {@code minimum <= value <= maximum}, where {@code minimum} and
	 * {@code maximum} are the lower endpoint and the upper endpoint of the range, respectively.
	 *
	 * @param value The value to evaluate
	 * @return {@code true}, if the value is within the range (bounds inclusive), {@code false} otherwise.
	 */
	boolean isWithinRange(T value);
}
