/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Angle;


/**
 * This interface represents a rotation vector specifying a Cartesian orientation.
 *
 * @since 1.0.0
 */
public interface Rotation {

	/**
	 * @deprecated Use {@link #getRX(Angle.Unit)} instead.
	 *
	 * @return Rx parameter value in radians.
	 */
	@Deprecated
	double getRX();

	/**
	 * @deprecated Use {@link #getRY(Angle.Unit)} instead.
	 *
	 * @return Ry parameter value in radians.
	 */
	@Deprecated
	double getRY();

	/**
	 * @deprecated Use {@link #getRZ(Angle.Unit)} instead.
	 *
	 * @return Rz parameter value in radians.
	 */
	@Deprecated
	double getRZ();

	/**
	 * Provides the value of the Rx parameter in specified units.
	 *
	 * @param unit The angular unit for which to return the Rx parameter
	 * @return The value of the Rx in specified units.
	 *
	 * @since 1.2.56
	 */
	double getRX(Angle.Unit unit);

	/**
	 * Provides the Ry parameter value in specified units.
	 *
	 * @param unit The angular unit for which to return the Ry parameter
	 * @return The value of the Ry in specified units.
	 *
	 * @since 1.2.56
	 */
	double getRY(Angle.Unit unit);

	/**
	 * Provides the Rz parameter value in specified units.
	 *
	 * @param unit The angular unit for which to return the Rz parameter
	 * @return The value of the Rz in specified units.
	 *
	 * @since 1.2.56
	 */
	double getRZ(Angle.Unit unit);

	/**
	 * <p>
	 * Indicates whether some other {@code Rotation} object is "approximately equal" to this one.
	 * </p>
	 *
	 * Two rotations are considered "approximately equal", if all the absolute differences between corresponding
	 * parameter values of the two rotations are less than or equal to the specified tolerance. The distance metric used
	 * is the L-infinite metric (also called the maximum metric) with the equality criterion defined in the form of:
	 * MAX( abs(rx1-rx2), abs(ry1-ry2), abs(rz1-rz2) ) <= epsilon.
	 *
	 * @param other   Another {@code Rotation} object.
	 * @param epsilon The tolerance value to be used for the comparison of rotation parameters (i.e. Rx, Ry, Rz) in
	 *                specified units
	 * @param unit    The angular unit for the specified {@code epsilon} tolerance.
	 * @return {@code true} if the values of this object is "approximately equal" to the values of the {@code other}
	 *         argument; {@code false} otherwise.
	 *
	 * @since 1.2.56
	 */
	boolean epsilonEquals(Rotation other, double epsilon, Angle.Unit unit);

	/**
	 * Indicates whether some other {@code Rotation} object is "equal to" this one.
	 *
	 * @param obj Another {@code Rotation} object.
	 * @return {@code true} if the values of this {@code Rotation} instance and the {@code obj} argument are exactly the
	 *         same; otherwise {@code false}.
	 */
	boolean equals(Object obj);

	/**
	 * @return A hash code value for this object.
	 *
	 * @since 1.2.56
	 */
	int hashCode();

	/**
	 * @return A string representation of the rotation.
	 *
	 * @since 1.2.56
	 */
	String toString();
}
