/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode.CustomParametersPayloadNodeConfig;
import com.ur.urcap.api.domain.value.blend.BlendFactory;
import com.ur.urcap.api.domain.value.expression.ExpressionBuilder;
import com.ur.urcap.api.domain.value.jointposition.JointPositionFactory;
import com.ur.urcap.api.domain.value.simple.SimpleValueFactory;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides a set of factories for creating immutable value objects.
 *
 * @since 1.2.56
 */
@ProviderType
public interface ValueFactoryProvider {

	/**
	 * This method returns a {@link SimpleValueFactory} instance for creating simple value objects
	 *
	 * @return the factory to create simple value objects.
	 */
	SimpleValueFactory getSimpleValueFactory();

	/**
	 * This method instantiates a new {@link ExpressionBuilder} instance to create a single valid expression.
	 *
	 * @return the builder to build a single expression.
	 */
	ExpressionBuilder createExpressionBuilder();

	/**
	 * This method returns a {@link BlendFactory} instance for creating blends.
	 *
	 * @return the factory to create blends.
	 */
	BlendFactory getBlendFactory();

	/**
	 * This method returns a {@link JointPositionFactory} instance for creating joint positions.
	 *
	 * @return the factory to create joint positions.
	 */
	JointPositionFactory getJointPositionFactory();

	/**
	 * This method returns a {@link PositionFactory} instance for creating positions to be used when
	 * creating a {@link Pose} or a {@link CustomParametersPayloadNodeConfig}.
	 *
	 * @return the factory to create positions.
	 *
	 * @since 1.13.0
	 */
	PositionFactory getPositionFactory();

	/**
	 * This method returns a {@link RotationFactory} instance for creating rotations to be used when
	 * creating a {@link Pose}.
	 *
	 * @return the factory to create rotations.
	 *
	 * @since 1.13.0
	 */
	RotationFactory getRotationFactory();

	/**
	 * This method returns a {@link PoseFactory} instance for creating poses.
	 *
	 * @return the factory to create poses.
	 */
	PoseFactory getPoseFactory();
}
