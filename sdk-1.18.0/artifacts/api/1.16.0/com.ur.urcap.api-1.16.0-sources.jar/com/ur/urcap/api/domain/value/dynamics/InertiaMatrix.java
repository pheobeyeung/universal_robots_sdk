/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.dynamics;

import com.ur.urcap.api.domain.value.simple.MomentOfInertia;


/**
 * <p>
 * This interface represents the inertia matrix for an object, e.g. a payload. The inertia matrix is sometimes referred
 * to as the inertia tensor.
 * </p>
 *
 * <p>
 * For a payload, the inertia matrix is defined in a coordinate system with center at the payload's center of gravity
 * (CoG), also referred to as center of mass, and the axes aligned with the tool output flange coordinate system (axes).
 * The center of gravity is defined as the offset between the center of the tool output flange and the center
 * of gravity of the attached payload.
 * </p>
 *
 * The inertia matrix is formally a 3x3 symmetric matrix containing the moments of inertia and products of inertia
 * around all three Cartesian axes for an object:
 * <pre>
 *  Ixx  Ixy  Ixz
 *  Ixy  Iyy  Iyz
 *  Ixz  Iyz  Izz
 * </pre>
 *
 * Since the inertia matrix is symmetric, it is only represented by six component values, i.e. the three moments of
 * inertia (Ixx, Iyy, Izz) and the three products of inertia (Ixy, Ixz, Iyz).
 *
 * @since 1.13.0
 */
public interface InertiaMatrix {

	/**
	 * Provides the Ixx component of the inertia matrix, i.e. the moment of inertia around the x-axis.
	 *
	 * @param unit The unit for which to return the moment of inertia value
	 * @return The moment of inertia around the x-axis in specified units
	 */
	double getIxxComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the Iyy component of the inertia matrix, i.e. the moment of inertia around the y-axis.
	 *
	 * @param unit The unit for which to return the moment of inertia value
	 * @return The moment of inertia value around the y-axis in specified units
	 */
	double getIyyComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the Izz component of the inertia matrix, i.e. the moment of inertia around the z-axis
	 *
	 * @param unit The unit for which to return the moment of inertia value
	 * @return the moment of inertia value around the z-axis in specified units
	 */
	double getIzzComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the Ixy component of the inertia matrix, i.e. the product of inertia around the x and y axes
	 *
	 * @param unit The unit for which to return the product of inertia value
	 * @return The product of inertia value around the x and y axes in specified units
	 */
	double getIxyComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the Ixz component of the inertia matrix, i.e. the product of inertia around the x and z axes
	 * 
	 * @param unit The unit for which to return the product of inertia value
	 * @return The product of inertia value for around x and z axes in specified units
	 */
	double getIxzComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the Iyz component of the inertia matrix, i.e. the product of inertia around the y and z axes
	 * 
	 * @param unit The unit for which to return the product of inertia value
	 * @return The product of inertia value for around y and z axes in specified units
	 */
	double getIyzComponent(MomentOfInertia.Unit unit);

	/**
	 * Provides the six unique components of the inertia matrix, i.e. the three values for the moments of inertia and the 
	 * three values for the products of inertia. The six components are returned as an array with elements in the 
	 * following order: Ixx, Iyy, Izz, Ixy, Ixz, Iyz.
	 * 
	 * @param unit The unit for which to return the values for the moments of inertia and products of inertia
	 * @return A {@code double} array with the moments of inertia and products of inertia values in the specified units
	 */
	double[] getComponents(MomentOfInertia.Unit unit);

	/**
	 * @return A hash code value for this object.
	 */
	int hashCode();

	/**
	 * Indicates whether some other {@code InertiaMatrix} object is "equal to" this one.
	 *
	 * @param obj Another {@code InertiaMatrix} object.
	 * @return {@code true} if the values of this {@code InertiaMatrix} instance and the {@code obj} argument are exactly
	 *         the same; otherwise {@code false}.
	 */
	boolean equals(Object obj);

	/**
	 * <p>
	 * Indicates whether some other {@code InertiaMatrix} object is "approximately equal" to this one.
	 * </p>
	 *
	 * Two inertia matrices are considered "approximately equal", if all the absolute differences between corresponding
	 * component values of the two matrices are less than or equal to the specified tolerance. The distance metric used
	 * is the L-infinite metric (also called the maximum metric) with the equality criterion defined in the form of
	 * {@code
	 * MAX( abs(Ixx1-Ixx2), abs(Iyy1-Iyy2), abs(Izz1-Izz2), abs(Ixy1-Ixy2), abs(Ixz1-Ixz2), abs(Iyz1-Iyz2) ) <= epsilon.
	 *  }
	 *
	 * @param other   Another {@code InertiaMatrix} object.
	 * @param epsilon The tolerance value to be used for the comparison of inertia matrix components (i.e. Ixx, Iyy, ...) 
	 *                in specified units
	 * @param unit    The unit for the specified {@code epsilon} tolerance.
	 * @return {@code true} if the values of this object is "approximately equal" to the values of the {@code other}
	 *          argument; {@code false} otherwise.
	 */
	boolean epsilonEquals(InertiaMatrix other, double epsilon, MomentOfInertia.Unit unit);

	/**
	 * @return A string representation of the inertia matrix, i.e. the Ixx, Iyy, Izz, Ixy, Ixz and Iyz components.
	 */
	String toString();
}
