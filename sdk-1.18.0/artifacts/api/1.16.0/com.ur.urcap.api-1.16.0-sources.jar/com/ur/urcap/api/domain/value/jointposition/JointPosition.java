/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.jointposition;


import com.ur.urcap.api.domain.value.simple.Angle;


/**
 * This interface represents the position of a single joint of the robot arm.
 *
 * @since 1.2.56
 */
public interface JointPosition {

	/**
	 * <p>
	 * Provides the value of the joint position including all revolutions in the specified unit.
	 * </p>
	 *
	 * Alternatively, the number of revolutions and the corresponding angle offset can be retrieved with
	 * {@link #getAngle(Angle.Unit)} and {@link #getRevolutions()}, respectively.
	 *
	 * @param unit The angular unit for which to return the joint position.
	 * @return The joint position value in specified units.
	 */
	double getPosition(Angle.Unit unit);

	/**
	 * Provides the number of whole revolutions.
	 *
	 * @return Number of revolutions.
	 */
	long getRevolutions();

	/**
	 * Provides the angle offset in the range [0:2pi[ (RAD) or [0:360[ (DEG).
	 *
	 * @param unit The angular unit for which to return the angle offset value.
	 * @return The angle offset value in specified units.
	 */
	double getAngle(Angle.Unit unit);


	/**
	 * <p>
	 * Indicates whether some other {@code JointPosition} object is "approximately equal" to this one.
	 * </p>
	 *
	 * Two joint positions are considered "approximately equal", if the absolute differences between the two joint
	 * position values are less than or equal to the specified tolerance (i.e. the equality criterion is: 
	 * abs(p1-p2) <= epsilon).
	 *
	 * @param other   Another {@code JointPosition} object.
	 * @param epsilon The tolerance value to be used for the comparison of joint position values in specified units.
	 * @param unit    The angular unit for the specified {@code epsilon} tolerance.
	 * @return {@code true} if the joint position value of this object is "approximately equal" to the joint position
	 *         value of the {@code other} argument; {@code false} otherwise.
	 */
	boolean epsilonEquals(JointPosition other, double epsilon, Angle.Unit unit);


	/**
	 * Indicates whether some other {@code JointPosition} object is "equal to" this one.
	 *
	 * @param obj Another {@code JointPosition} object.
	 * @return {@code true} if the joint position value of this object is exactly the same as the joint position value 
	 *         of the {@code obj} argument; {@code false} otherwise.
	*/
	boolean equals(Object obj);

	/**
	 * @return A hash code value for this object.
	 */
	int hashCode();

	/**
	* @return A string representation of the joints positions.
	*/
	String toString();
}

