/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.jointposition;

import com.ur.urcap.api.domain.value.simple.Angle;


/**
 * This interface supplies methods for creating an object containing the positions of each of the robot arm's joints.
 * This is also referred to as a joint configuration.
 *
 * @since 1.2.56
 */
public interface JointPositionFactory {
	/**
	 * Creates a {@link JointPositions} object with six revolute joints using the provided angles and unit type.
	 *
	 * @param base Base joint position.
	 * @param shoulder Shoulder joint position.
	 * @param elbow Elbow joint position.
	 * @param wrist1 Wrist1 joint position.
	 * @param wrist2 Wrist2 joint position.
	 * @param wrist3 Wrist3 joint position.
	 * @param unit the unit type for all the joint position arguments.
	 * @return a new {@code JointPositions} object.
	 */
	JointPositions createJointPositions(double base,
	                                    double shoulder,
	                                    double elbow,
	                                    double wrist1,
	                                    double wrist2,
	                                    double wrist3,
	                                    Angle.Unit unit);
}