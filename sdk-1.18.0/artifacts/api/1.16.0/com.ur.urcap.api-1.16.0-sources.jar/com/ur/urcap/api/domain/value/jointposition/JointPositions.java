/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.jointposition;

import com.ur.urcap.api.domain.value.simple.Angle;


/**
 * <p>
 * This interface represents the positions of all of the joints in the robot arm.
 * </p>
 *
 * A {@code JointPositions} object can be built using the {@link JointPositionFactory} interface.
 *
 * @since 1.2.56
 */
public interface JointPositions {

	/**
	 * Provides an array containing all the positions of the joints in the robot arm.
	 *
	 * @return The individual joint position values.
	 */
	JointPosition[] getAllJointPositions();

	/**
	 * <p>
	 * Indicates whether each element of some other {@code JointPositions} object is "approximately equal" to this one.
	 * </p>
	 *
	 * Two joint positions objects are considered "approximately equal", if all the absolute differences between 
	 * corresponding joint position values of the two joint positions instances are less than or equal to the specified 
	 * tolerance. The distance metric used is the L-infinite metric (also called the maximum metric) with the equality 
	 * criterion defined in the form of: <br>
	 * MAX( abs(p1_1-p1_2), abs(p2_1-p2_2), abs(p3_1-p3_2), abs(p4_1-p4_2), abs(p5_1-p5_2), abs(p6_1-p6_2) ) <= epsilon.
	 *
	 * @param other   Another {@code JointPositions} object.
	 * @param epsilon The tolerance value to be used for the comparison of joint position values in specified units.
	 * @param unit    The angular unit for the specified {@code epsilon} tolerance.
	 * @return {@code true} if the values of this object are "approximately equal" to the values of the {@code other}
	 *         argument; {@code false} otherwise.
	 */
	boolean epsilonEquals(JointPositions other, double epsilon, Angle.Unit unit);


	/**
	 * Indicates whether some other {@code JointPositions} object is "equal to" this one.
	 *
	 * @param obj Another {@code JointPositions} object.
	 * @return {@code true}, if the values of this object are exactly the same as the values of the {@code obj} argument;
	 *         {@code false} otherwise.
	 */
	boolean equals(Object obj);

	/**
	 * @return A hash code value for this object.
	 */
	int hashCode();

	/**
	 * @return A string representation of the joints positions.
	 */
	String toString();
}

