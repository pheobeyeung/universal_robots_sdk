/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.simple;


import org.osgi.annotation.versioning.ProviderType;

/**
 * This interface supplies methods to create different types of simple value objects.
 *
 * @since 1.2.56
 */
@ProviderType
public interface SimpleValueFactory {

	/**
	 * Creates an object representing a length value.
	 *
	 * @param value length value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Length} object.
	 */
	Length createLength(double value, Length.Unit unit);

	/**
	 * Creates an object representing a speed value.
	 *
	 * @param value speed value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Speed} object.
	 */
	Speed createSpeed(double value, Speed.Unit unit);

	/**
	 * Creates an object representing an acceleration value.
	 *
	 * @param value acceleration value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Acceleration} object.
	 */
	Acceleration createAcceleration(double value, Acceleration.Unit unit);

	/**
	 * Creates an object representing an angle value.
	 *
	 * @param value angle value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Angle} object.
	 */
	Angle createAngle(double value, Angle.Unit unit);

	/**
	 * Creates an object representing an angular speed value.
	 *
	 * @param value angular speed value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code AngularSpeed} object.
	 */
	AngularSpeed createAngularSpeed(double value, AngularSpeed.Unit unit);

	/**
	 * Creates an object representing an angular acceleration value.
	 *
	 * @param value angular acceleration value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code AngularAcceleration} object.
	 */
	AngularAcceleration createAngularAcceleration(double value, AngularAcceleration.Unit unit);

	/**
	 * Creates an object representing a force value.
	 *
	 * @param value force value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Force} object.
	 */
	Force createForce(double value, Force.Unit unit);

	/**
	 * Creates an object representing a torque value.
	 *
	 * @param value torque value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Torque} object.
	 */
	Torque createTorque(double value, Torque.Unit unit);

	/**
	 * Creates an object representing a pressure value.
	 *
	 * @param value pressure value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Pressure} object.
	 *
	 * @since 1.6.0
	 */
	Pressure createPressure(double value, Pressure.Unit unit);

	/**
	 * Creates an object representing a mass.
	 *
	 * @param value mass value in specified unit.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Mass} object.
	 *
	 * @since 1.12.0
	 */
	Mass createMass(double value, Mass.Unit unit);

	/**
	 * Creates an object representing a time value.
	 *
	 * @param value time value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Time} object.
	 */
	Time createTime(double value, Time.Unit unit);

	/**
	 * Creates an object representing an electrical current value.
	 *
	 * @param value electrical current value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Current} object.
	 */
	Current createCurrent(double value, Current.Unit unit);

	/**
	 * Creates an object representing an electrical voltage value.
	 *
	 * @param value electrical voltage  value in specified units.
	 * @param unit type of unit for the {@code value} argument.
	 * @return a new {@code Voltage} object.
	 */
	Voltage createVoltage(double value, Voltage.Unit unit);
}
