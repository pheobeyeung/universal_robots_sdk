/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.variable;


/**
 * This interface represents variables stored with the installation. These variables are defined in the installation and
 * will exist even when a robot is turned off and on.
 *
 * @since 1.2.56
 */
public interface PersistedVariable extends GlobalVariable {

	/**
	 * <p>
	 * A persisted variable can not be guaranteed to be present. This method can be used to determine, if the variable
	 * is present.
	 * </p>
	 *
	 * <p>
	 * The persisted variable will not be present, if the end user loads a different installation which does not contain 
	 * the variable, or if the variable is deleted by the end user.
	 * </p>
	 *
	 * A program node storing a {@code PersistedVariable} instance in its Data Model will be undefined if the variable
	 * cannot be resolved (i.e. the variable is not present).
	 *
	 * @return {@code true} if this persisted variable is present in the PolyScope installation, otherwise {@code false}.
	 */
	boolean isResolvable();
}