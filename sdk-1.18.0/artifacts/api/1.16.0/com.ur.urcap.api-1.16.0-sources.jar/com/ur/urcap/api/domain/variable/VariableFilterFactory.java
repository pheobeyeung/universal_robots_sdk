/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.variable;

import com.ur.urcap.api.domain.util.Filter;


/**
 * This interface provides predefined filters that can be used when searching for particular types of variables.
 *
 * @since 1.2.56
 */
public class VariableFilterFactory {

	/**
	 *
	 * @return a filter for Feature variables that are registered in the installation.
	 */
	public static Filter<Variable> featureVariablesFilter() {
		return new Filter<Variable>() {
			@Override
			public boolean accept(Variable element) {
				return Variable.Type.FEATURE.equals(element.getType());
			}
		};
	}

	/**
	 *
	 * @return a filter for value variables that are registered in the installation.
	 */
	public static Filter<Variable> valuePersistedVariablesFilter() {
		return new Filter<Variable>() {
			@Override
			public boolean accept(Variable element) {
				return Variable.Type.VALUE_PERSISTED.equals(element.getType());
			}
		};
	}

	/**
	 *
	 * @return a filter for variables that are global, registered and defined in a program
	 */
	public static Filter<Variable> globalVariablesFilter() {
		return new Filter<Variable>() {
			@Override
			public boolean accept(Variable element) {
				return Variable.Type.GLOBAL.equals(element.getType());
			}
		};
	}
}