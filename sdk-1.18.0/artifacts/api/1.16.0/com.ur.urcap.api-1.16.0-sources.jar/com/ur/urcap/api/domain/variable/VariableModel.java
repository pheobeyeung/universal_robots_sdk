/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.variable;

import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.util.Filter;

import java.util.Collection;


/**
 * Provides methods that returns the variables that currently are registered in the system. A variable is registered if
 * it has been stored in a {@link DataModel} instance or used for the configuration of a built-in PolyScope program node.
 *
 * @since 1.2.56
 */
public interface VariableModel {

	/**
	 *
	 * @return the collection of all variables that currently are registered in the system.
	 */
	Collection<Variable> getAll();

	/**
	 * Get a subset of all the variables registered in the system using a filter.
	 *
	 * @param filter see {@link VariableFilterFactory} for examples.
	 * @return the collection of Variables that are accepted by the filter.
	 */
	Collection<Variable> get(Filter<Variable> filter);

	/**
	 * @return a {@link VariableFactory} to create variable objects.
	 */
	VariableFactory getVariableFactory();

	/**
	 * Get the feature variable for a {@link Feature}.
	 *
	 * @param feature the feature with a variable.
	 * @return the variable for the feature.
	 * @throws IllegalArgumentException If feature not is present in the installation or feature has no variable,
	 * see {@link Feature#isVariable()}.
	 */
	FeatureVariable getFeatureVariable(Feature feature);
}
