/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.ui.component;

import java.util.List;


/**
 * <p>
 * Represents a select list (drop down style) UI component.
 * </p>
 *
 * <p>
 * The implementation of the drop-down list have special rules and rendering for
 * {@link com.ur.urcap.api.domain.variable.Variable} objects. Unregistered variables are not visible nor selectable
 * (until they become registered).
 * </p>
 *
 * <b>Note:</b> For unresolved PolyScope entities, like Features, Variables and TCPs, that are selected in the
 * drop-down list, the item will be highlighted with a yellow border.
 *
 * @since 1.0.0
 */
public interface SelectDropDownList extends HTMLComponent {

	/**
	 *
	 * @param items clear the current items and set the list of items to {@code items}.
	 */
	void setItems(List<?> items);

	/**
	 *
	 * @param item add a new item to the drop down.
	 */
	void addItem(Object item);

	/**
	 * Remove all items.
	 *
	 */
	void removeAllItems();

	/**
	 *
	 * @return the number of items in the drop down.
	 */
	int getItemCount();

	/**
	 *
	 * @return the currently selected item.
	 */
	Object getSelectedItem();

	/**
	 *
	 * @return the index of the currently selected item where 0 specifies the first item in the list; or -1 if no item
	 * is selected or if the currently selected item is not in the list.
	 */
	int getSelectedIndex();

	/**
	 *
	 * @param item Select the item.
	 */
	void selectItem(Object item);

	/**
	 *
	 * @param index Select the item at index {@code index} where 0 specifies the first item.
	 */
	void selectItemAtIndex(int index);
}
