/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.ui.component;

import java.util.List;


/**
 * <p>
 * Represents a selection list UI component.
 * </p>
 *
 * <p>
 * The implementation of the list have special rules and rendering for {@link com.ur.urcap.api.domain.variable.Variable}
 * objects. Unregistered variables are not visible nor selectable (until they become registered).
 * </p>
 *
 * <b>Note:</b> For unresolved PolyScope entities, like Features, Variables and TCPs, that are selected in the
 * list, the item will be highlighted with a yellow border.
 *
 * @since 1.0.0
 */
public interface SelectList extends HTMLComponent {

	/**
	 *
	 * @param items clear the current items and set the list of items to {@code items}.
	 */
	void setItems(List<?> items);

	/**
	 *
	 * @param item add a new item to the drop down.
	 */
	void addItem(Object item);

	/**
	 *
	 * @param items add the list of {@code items}.
	 */
	void addAllItems(List<?> items);

	/**
	 *
	 * @param item remove item.
	 */
	void removeItem(Object item);

	/**
	 * Remove all items.
	 *
	 */
	void removeAllItems();

	/**
	 * unselect currently selected item(s).
	 *
	 */
	void clearSelection();

	/**
	 *
	 * @param item select the items.
	 */
	void selectItems(Object...item);

	/**
	 *
	 * @param indices select the items at indices. The first element is at index 0.
	 */
	void selectItemsAtIndices(int...indices);

	/**
	 *
	 * @return the number of items in the list.
	 */
	int getItemCount();

	/**
	 *
	 * @return list of selected items.
	 */
	Object[] getSelectedItems();

	/**
	 *
	 * @return Returns the value for the smallest selected cell index;
	 * <i>the selected value</i> when only a single item is selected in the
	 * list. When multiple items are selected, it is simply the value for the
	 * smallest selected index. Returns {@code null} if there is no selection.
	 */
	Object getSelectedItem();

	/**
	 *
	 * @return Returns the smallest selected cell index; <i>the selection</i> when only
	 * a single item is selected in the list. When multiple items are selected,
	 * it is simply the smallest selected index. Returns {@code -1} if there is
	 * no selection.
	 */
	int getSelectedIndex();

	/**
	 *
	 * @return all of the selected indices, in increasing order,
	 *         or an empty array if nothing is selected.
	 */
	int[] getSelectedIndices();

	/**
	 *
	 * @return the objects in the list.
	 */
	Object[] getItems();

	/**
	 * Update the rendering of the list element.
	 *
	 */
	void refresh();
}
