/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.ui.component;


/**
 * <p>
 * Support for touch events from UI component.
 * </p>
 *
 * NOTE: When also subscribing to {@link InputEvent}, the ordering of events is not guaranteed.
 *
 * @since 1.2.56
 */

public interface TouchEvent {

	/**
	 * ON_PRESSED -  an event of this type is issued on mouse/touchscreen pressed. <br>
	 * ON_RELEASE -  an event of this type is issued when the mouse/touchscreen is released.
	 *
	 */
	enum EventType {
		ON_PRESSED,
		ON_RELEASED
	}

	/**
	 *
	 * @return Get the type of event.
	 */
	EventType getEventType();

	/**
	 *
	 * @return An integer indicating horizontal position in pixels relative to the issuing component.
	 */
	int getRelativePosX();

	/**
	 *
	 * @return An integer indicating vertical position in pixels relative to the issuing component.
	 */
	int getRelativePosY();

	/**
	 *
	 * @return The component that issued the event.
	 */
	HTMLComponent getComponent();
}
