/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.ui.component;

import java.util.List;
import java.util.Locale;


/**
 * <p>
 * To have drop down list items translatable, the items must implement this interface.
 * </p>
 *
 * See also {@link SelectDropDownList#addItem(Object) addItem} and {@link SelectDropDownList#setItems(List) setItems}.
 *
 * @since 1.0.0
 */
public interface Translatable {

	/**
	 * This method is called by the list cell renderer for each item in the list.
	 *
	 * @param locale the current locale of PolyScope.
	 * @return Must return the text for the item in the given locale.
	 */
	String getTranslatedText(Locale locale); 
}
