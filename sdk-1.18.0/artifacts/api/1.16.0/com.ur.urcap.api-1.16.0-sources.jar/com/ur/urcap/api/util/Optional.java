/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2024 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.util;

import java.util.NoSuchElementException;


/**
 * <p>
 * A container which may or may not contain a value. It is used for wrapping the return value of getter methods, where
 * the return value might not be available.
 * </p>
 *
 * If a value is present (available), the {@link #isPresent()} method will return {@code true} and the value can be
 * retrieved using the {@link #get()} method.
 *
 * @param <T> The type of the value contained in this {@code Optional}
 *
 * @since 1.11.0
 */
public interface Optional<T> {

	/**
	 * Checks if a value is present in this {@code Optional}. Always use this method to determine, if the {@code Optional}
	 * holds a value, before accessing it using the {@link #get()} method.
	 *
	 * @return {@code true} if there is a value present, otherwise {@code false}
	 */
	boolean isPresent();

	/**
	 * Gets the value held by this {@code Optional}, if a value is present. Always call the {@link #isPresent()} method
	 * to verify, that a value is available, before calling this method.
	 *
	 * @return The value (of type {@code T}) held by this {@code Optional}
	 * @throws NoSuchElementException if there is no value present in this {@code Optional}
	 */
	T get();
}
