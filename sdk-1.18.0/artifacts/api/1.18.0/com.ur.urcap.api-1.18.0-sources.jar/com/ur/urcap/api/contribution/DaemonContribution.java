/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import java.net.URL;


/**
 *
 * <p>
 * Defines an API definition that gives control of a daemon that belongs to a URCap.
 * </p>
 *
 * @since 1.0.0
 */
public interface DaemonContribution {
	/**
	 *
	 * The run state of the daemon
	 */
	enum State {
		/**
		 * The daemon is running
		 */
		RUNNING,

		/**
		 * The daemon is stopped
		 */
		STOPPED,

		/**
		 * The daemon should be running but it is not
		 */
		ERROR
	}

	/**
	 *
	 * This method installs the resource folder/file specified by an {@code url}.
	 *
	 * @param url - Path as a URL to the resource folder/file containing the daemon/daemon folder structure
	 */
	void installResource(URL url);

	/**
	 *
	 * Starts the daemon. Will be ignored if daemon is in ERROR state.<br>
	 *
	 * When issuing multiple start and/or stop commands within a short time frame only the latest
	 * will be effectuated. If called when the daemon is in the initializing state, it will be invoked when the daemon
	 * is ready (unless it enters the ERROR state)
	 */
	void start();

	/**
	 *
	 * Stops the daemon. Will be ignored if daemon is in ERROR state.<br>
	 *
	 * When issuing multiple start and/or stop commands within a short time frame only the latest
	 * will be effectuated. If called when the daemon is in the initializing state, it will be invoked when the daemon
	 * is ready (unless it enters the ERROR state).
	 */
	void stop();

	/**
	 *
	 * @return current run state of the daemon.
	 */
	State getState();
}
