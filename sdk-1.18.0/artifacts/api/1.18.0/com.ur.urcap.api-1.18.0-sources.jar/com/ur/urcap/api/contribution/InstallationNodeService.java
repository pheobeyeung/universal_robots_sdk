/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;

import java.io.InputStream;


/**
 * Defines an API required for definition of an installation node and screen of a URCap.
 *
 * @since 1.0.0
 */
public interface InstallationNodeService {

	/**
	 *
	 * @return The text displayed for this URCap in the Installation Tab.
	 */
	String getTitle();

	/**
	 *
	 * @return Return an input stream with the HTML contents of the node.
	 */
	InputStream getHTML();


	/**
	 * <p>
	 * Creates a new installation node instance.
	 * </p>
	 *
	 * The returned node must use the supplied data model object to retrieve and store the data contained in it.
	 * All modifications to the supplied data model from the installation node constructor are ignored when an existing
	 * installation is loaded. The data model object is shared between all installation nodes contributed by the same
	 * URCap.
	 *
	 * @param api object with access to PolyScope functionality.
	 * @param model object where all configuration data of the new installation node.
	 * instance is to be stored in and retrieved from.
	 * @return the newly constructed installation node contribution instance.
	 */
	InstallationNodeContribution createInstallationNode(URCapAPI api, DataModel model);
}
