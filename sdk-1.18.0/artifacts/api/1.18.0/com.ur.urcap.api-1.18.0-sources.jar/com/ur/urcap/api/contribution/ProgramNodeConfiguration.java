/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution;

import com.ur.urcap.api.contribution.program.configuration.debugging.ProgramDebuggingSupport;
import com.ur.urcap.api.domain.device.DeviceRegistrationManager;
import org.osgi.annotation.versioning.ProviderType;


/**
 * Provides access to configure additional properties of a program node contribution with a HTML-based user interface.
 *
 * @since 1.5.0
 */
@ProviderType
public interface ProgramNodeConfiguration {

	/**
	 * Set the display order id for this type of program node contribution. This makes it possible to specify how
	 * all the program node contributions from a URCap should be ordered/sorted in PolyScope.
	 *
	 * <p>
	 * All program node contributions from a URCap will be grouped together and sorted (in ascending order) according to
	 * their display order id.
	 * </p>
	 *
	 * <p>
	 * The default value is 0.0. If the display order id for all program node contributions in a URCap have the default
	 * value, the standard built-in sorting in PolyScope will be used.
	 * </p>
	 *
	 * @param displayOrderId Determines the display order of the URCap program node type.
	 */
	void setDisplayOrderId(double displayOrderId);

	/**
	 * <p>
	 * Configure PolyScope program debugging support for this URCap program node and all child nodes in its
	 * sub-tree.
	 * </p>
	 *
	 * <b>Note:</b> The configuration values of the {@link ProgramDebuggingSupport} instance will be read once immediately
	 * after the call to the {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} method
	 * has ended. Changing values at a later stage will have no effect, so do not store a reference to the
	 * {@link ProgramDebuggingSupport} object.
	 *
	 * @return an interface for configuring program debugging support for this program node
	 *
	 * @since 1.9.0
	 */
	ProgramDebuggingSupport getProgramDebuggingSupport();

	/**
	 * This method can be used to obtain an interface for registering this program node contribution/service as conformant
	 * with a specific device type supported by PolyScope.
	 *
	 * @param registrationManagerClass the class of the device registration manager to return, not {@code null}.
	 * @param <T> the type of the device registration manager
	 * @return a device registration manager for registering a program node contribution/service as a specific device
	 *
	 * @since 1.9.0
	 */
	<T extends DeviceRegistrationManager> T getDeviceRegistrationManager(Class<T> registrationManagerClass);
}
