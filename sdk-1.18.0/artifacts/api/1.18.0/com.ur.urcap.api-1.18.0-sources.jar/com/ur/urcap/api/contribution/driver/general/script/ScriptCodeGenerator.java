/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.script;

import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 * <p>
 * Implement this interface to provide script code for a (regular or feedback) capability.
 * </p>
 *
 * Pass the implementation of this interface when registering a capability for a device driver.
 *
 * @param <P> the (generic) type parameter for the interface representing parameters which can be used as input to the
 *            script code generation. Use them if applicable.
 *
 * @since 1.9.0
 */
public interface ScriptCodeGenerator<P> {

	/**
	 * <p>
	 * When this method is called (by PolyScope), the needed script code for the capability must be generated.
	 * </p>
	 *
	 * Use the provided parameters (configured by the user) as input to the script code generation if necessary in the
	 * given context.
	 *
	 * @param scriptWriter use this script writer instance to generate the script code for the capability
	 * @param parameters the user-defined parameters
	 */
	void generateScript(ScriptWriter scriptWriter, P parameters);
}
