/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput;


/**
 * <p>
 * This exception is thrown when an attempt is made to access a user input, e.g. reading the value using
 * {@link UserInput#getValue()}, after the user input has been deprecated (using the
 * {@link CustomUserInputConfiguration#deprecateUserInput(UserInput)} method).
 * </p>
 *
 * To access the value of a deprecated user input, the return value of the
 * {@link CustomUserInputConfiguration#deprecateUserInput(UserInput)} method must be used instead.
 *
 * @since 1.8.0
 */
public class CannotAccessDeprecatedUserInput extends RuntimeException {

	public CannotAccessDeprecatedUserInput(String message) {
		super(message);
	}
}
