/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput;

import javax.swing.Icon;


/**
 * This interface represents a text UI element for displaying information to the end user.
 *
 * @since 1.8.0
 */
public interface TextComponent {

	/**
	 * <p>
	 * Updates the icon to be displayed to the end user.
	 * </p>
	 *
	 * Supports 24x24 pixels icons for CB3 robots and 30x30 pixel icons for e-Series robots. The provided icon will be
	 * scaled automatically, if necessary.
	 *
	 * @param icon The icon to be displayed. Passing {@code null} is allowed and will clear the icon.
	 *
	 */
	void setIcon(Icon icon);

	/**
	 * Updates the text to be displayed to the end user.
	 *
	 * @param text The text to be displayed, not {@code null}.
	 */
	void setText(String text);
}
