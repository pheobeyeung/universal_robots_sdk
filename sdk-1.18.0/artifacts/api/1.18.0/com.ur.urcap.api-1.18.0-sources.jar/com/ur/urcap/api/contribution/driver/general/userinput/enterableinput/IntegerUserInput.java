/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput.enterableinput;

import com.ur.urcap.api.contribution.driver.general.userinput.UserInput;
import com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidator;


/**
 * This interface provides access to the integer value entered by the end user with the option of adding special
 * error input validation.
 *
 * @since 1.8.0
 */
public interface IntegerUserInput extends UserInput<Integer> {

	/**
	 * <p>
	 * Set a custom input validator for detecting errors for the user input.
	 * </p>
	 *
	 * <b>Note:</b> By default, a range validator verifying that the input value is between the specified minimum and
	 * maximum value is always attached to the user input.
	 *
	 * @param validator the custom error input validator
	 */
	void setErrorValidator(InputValidator<Integer> validator);
}
