/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.general.userinput.selectableinput;

/**
 * <p>
 * This exception is thrown when an attempt is made to register a combo box user input with an initial selection that is
 * not in the list of elements (selectable in the combo box).
 * </p>
 *
 * This will occur when the resolved identifier returned by the custom element resolver (see {@link ElementResolver})
 * provided to the register method does not match the resolved identifier of any of the elements in the element list.
 *
 * @since 1.8.0
 */
public class InvalidSelection extends RuntimeException {

	public InvalidSelection(String message) {
		super(message);
	}
}
