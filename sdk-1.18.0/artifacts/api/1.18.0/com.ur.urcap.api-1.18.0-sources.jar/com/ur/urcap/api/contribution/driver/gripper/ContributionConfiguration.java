/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper;

import javax.swing.Icon;


/**
 * Provides access to configure optional PolyScope properties of a gripper contribution.
 *
 * @since 1.8.0
 */
public interface ContributionConfiguration {

	/**
	 * Provide a custom logo that will be displayed in PolyScope in:
	 *
	 * <ul>
	 * 	 <li>The program node screen for this gripper contribution.</li>
	 * 	 <li>The installation node screen for this gripper contribution.</li>
	 * 	 <li>The toolbar contribution for this gripper. Note: The toolbar contribution is not available on CB3 robots.</li>
	 * </ul>
	 *
	 * <p>
	 * The provided logo will be scaled automatically, if necessary.
	 * </p>
	 *
	 * If no custom logo is provided, a default logo will be displayed instead.
	 *
	 * @param logo The logo to be shown in PolyScope
	 */
	void setLogo(Icon logo);
}
