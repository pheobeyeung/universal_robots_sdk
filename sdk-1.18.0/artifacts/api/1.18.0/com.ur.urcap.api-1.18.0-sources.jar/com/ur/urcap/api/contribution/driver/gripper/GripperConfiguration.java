/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper;

import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperFeedbackCapabilities;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides access to register or setup various properties and capabilities of a gripper. It is optional
 * to register these capabilities and properties.
 *
 * @since 1.8.0
 */
@ProviderType
public interface GripperConfiguration {

	/**
	 * @return An interface for registering various capabilities of the gripper
	 */
	GripperCapabilities getGripperCapabilities();

	/**
	 * @return An interface for registering various feedback capabilities of the gripper
	 *
	 * @since 1.9.0
	 */
	GripperFeedbackCapabilities getGripperFeedbackCapabilities();
}
