/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper;

import com.ur.urcap.api.contribution.driver.general.tcp.TCPConfiguration;
import com.ur.urcap.api.contribution.driver.general.userinput.CustomUserInputConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.MultiGripperCapability;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.GripperListProvider;

import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;
import com.ur.urcap.api.domain.resource.ControllableResourceModel;
import com.ur.urcap.api.domain.resource.ResourceModel;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides access to functionality for configuring the robot system,
 * e.g. configuring the Tool I/O interface settings.
 *
 * @since 1.8.0
 */
@ProviderType
public interface SystemConfiguration {

	/**
	 * Access an interface that can be used for verifying that specific capabilities are available on the underlying
	 * robot/system. Verification of availability is required for all methods/interfaces annotated with
	 * {@link RequiredCapability}.
	 *
	 * @return The capability manager interface which can be used to query information about the availability of system
	 *         capabilities
	 */
	CapabilityManager getCapabilityManager();

	/**
	 * @return A resource model interface with read-only access to system resources, e.g. the Tool I/O interface.
	 */
	ResourceModel getResourceModel();

	/**
	 * <p>
	 * Access an interface for requesting exclusive control of system resources, e.g. the configuration of the Tool I/O
	 * interface.
	 * </p>
	 *
	 * <b>NOTE:</b> Requesting control of a system resource <b>must</b> happen within the scope of the
	 * {@link GripperContribution#configureInstallation(CustomUserInputConfiguration, SystemConfiguration, TCPConfiguration, GripperAPIProvider)}
	 * method.
	 *
	 * @return A resource model interface for requesting exclusive control of system resources
	 */
	ControllableResourceModel getControllableResourceModel();

	/**
	 * <p>
	 * Get the {@link TCPConfiguration} interface for managing the (optional) TCP associated with the specified
	 * {@link SelectableGripper} gripper/zone. The returned interface can be used to add an TCP for the specified 
	 * individual gripper/zone to PolyScope as well as update the TCP's offset and remove the TCP again.
	 * </p>
	 * 
	 * <b>Note:</b> This method is only relevant if the multi-gripper capability has been registered (see
	 * {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}). For grippers not supporting the
	 * multi-gripper capability, a single TCP can be added using the {@code tcpConfiguration} parameter passed when the
	 * {@link GripperContribution#configureInstallation(CustomUserInputConfiguration, SystemConfiguration, TCPConfiguration, GripperAPIProvider)}
	 * 	method is called. <br>
	 * <b>Note:</b> The TCP associated with the individual gripper will be not be available (nor visible) in PolyScope
	 * to the end user when the gripper has been disabled (using
	 * {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}).
	 * 
	 * @param gripper The individual gripper/zone for which to get the TCP configuration interface for, not {@code null}
	 * @return An interface for adding, updating and removing a TCP for the specified {@code gripper}
	 * @throws IllegalArgumentException if this contribution is not the owner of the individual gripper/zone, i.e. the
	 * specified gripper was not added by this URCap.
	 *
	 * @since 1.11.0
	 */
	TCPConfiguration getTCPConfiguration(SelectableGripper gripper);
}
