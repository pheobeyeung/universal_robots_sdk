/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.domain.value.simple.Force;


/**
 * <p>
 * This interface represents a registered force capability for a gripper which supports gripping using a user configurable
 * force.
 * </p>
 *
 * Through this interface, it is possible to adjust the range and default value for the force after the capability has
 * been registered. This is typically not applicable for most grippers, but can be relevant when the range depends on
 * another custom gripper setting (which can be configured by the user).
 *
 * @since 1.8.0
 */
public interface GripForceCapability {

	/**
	 * <p>
	 * Update the range and default value for the force supported by the gripper.
	 * </p>
	 *
	 * Updating the range could result in an already entered value in the configuration of a gripper program node being
	 * outside the range. This will make the given program node undefined, and force the end user to adjust the value to
	 * be valid again.
	 *
	 * @param minForce minimum force supported by the gripper
	 * @param maxForce maximum force supported by the gripper
	 * @param defaultGripForce default value for the force for a grip action. This value is used for, e.g. performing a
	 * 	                      "default" grip action using the toolbar
	 * @param unit the unit for all specified values, {@code null}
	 * @throws InvalidCapabilityRange if {@code minForce} > {@code maxForce} or {@code defaultGripForce} is outside the
	 * range defined by {@code minForce} and {@code maxForce}
	 */
	void updateCapability(double minForce, double maxForce, double defaultGripForce, Force.Unit unit);
}
