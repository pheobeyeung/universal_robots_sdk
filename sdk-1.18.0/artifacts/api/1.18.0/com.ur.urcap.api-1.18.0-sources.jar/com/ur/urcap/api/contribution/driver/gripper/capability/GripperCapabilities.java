/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability;

import com.ur.urcap.api.contribution.ProgramNodeConfiguration;
import com.ur.urcap.api.contribution.ProgramNodeServiceConfigurable;
import com.ur.urcap.api.contribution.driver.general.tcp.TCPConfiguration;
import com.ur.urcap.api.contribution.driver.general.userinput.CustomUserInputConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.CalledOutsideGripperConfigurationPhase;
import com.ur.urcap.api.contribution.driver.gripper.GripperAPIProvider;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.SystemConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.GripperListProvider;
import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.GripperListBuilder;

import com.ur.urcap.api.contribution.driver.gripper.capability.multigripper.LessThanTwoGrippers;
import com.ur.urcap.api.contribution.driver.gripper.conformant.GripperRegistrationManager;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;
import com.ur.urcap.api.domain.value.simple.Force;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Pressure;
import com.ur.urcap.api.domain.value.simple.Speed;

import com.ur.urcap.api.util.CalledOutsideMethodScope;

import org.osgi.annotation.versioning.ProviderType;
import java.util.Locale;


/**
 * Register the physical capabilities of the gripper using this interface.
 *
 * @since 1.8.0
 */
@ProviderType
public interface GripperCapabilities {

	/**
	 * Register a width/position capability for a gripper that supports moving to a user configurable position (open/close
	 * to a configurable width).
	 *
	 * @param minWidth The minimum width supported by the gripper
	 * @param maxWidth The maximum width supported by the gripper
	 * @param defaultGripWidth default value for the width for a grip action. This value is used for, e.g. performing a
	 *                         "default" grip action using the toolbar
	 * @param defaultReleaseWidth default value for the width for a release action. This value is used for, e.g. performing
	 *                            a "default" release action using the toolbar
	 * @param unit the unit for all specified values, not {@code null}
	 * @return a width capability allowing for dynamic adjustments of the capability properties including the value range
	 *         and default values
	 * @throws InvalidCapabilityRange if {@code minWidth} > {@code maxWidth}
	 * @throws InvalidCapabilityRange if {@code defaultGripWidth} or {@code defaultReleaseWidth} is outside the range
	 *                                defined by {@code minWidth} and {@code maxWidth}.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time by a URCap implementing
	 *         the {@link GripperContribution} interface, i.e. called outside the scope of the configuration of the
	 *         gripper.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time by a (regular) URCap which has
	 *         registered its program node contribution/service as conformant with a PolyScope gripper (using
	 *         {@link GripperRegistrationManager#registerAsGripper(Class)}), i.e. called outside the scope of the call to
	 *         either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for a Swing-based
	 *         URCap) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
	 *         a HTML-based URCap).
	 */
	WidthCapability registerWidthCapability(double minWidth, double maxWidth, double defaultGripWidth, double defaultReleaseWidth, Length.Unit unit);

	/**
	 * Register a force capability for a gripper that supports gripping using a user configurable force.
	 *
	 * @param minForce minimum force supported by the gripper
	 * @param maxForce maximum force supported by the gripper
	 * @param defaultGripForce default value for the force for a grip action. This value is used for, e.g. performing a
	 * 	                       "default" grip action using the toolbar
	 * @param unit the unit for all specified values, {@code null}
	 * @return a force capability allowing for dynamic adjustments of the capability properties including the value range
	 *         and default value
	 * @throws InvalidCapabilityRange if {@code minForce} > {@code maxForce} or {@code defaultGripForce} is outside the
	 * 	                              range defined by {@code minForce} and {@code maxForce}.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time by a URCap implementing
	 *         the {@link GripperContribution} interface, i.e. called outside the scope of the configuration of the
	 *         gripper.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time by a (regular) URCap which has
	 *         registered its program node contribution/service as conformant with a PolyScope gripper (using
	 *         {@link GripperRegistrationManager#registerAsGripper(Class)}), i.e. called outside the scope of the call to
	 *         either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for a Swing-based
	 *         URCap) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
	 *         a HTML-based URCap).
	 */
	GripForceCapability registerGrippingForceCapability(double minForce, double maxForce, double defaultGripForce, Force.Unit unit);

	/**
	 * Register a speed capability for a gripper that supports operating using a user configurable speed.
	 *
	 * @param minSpeed minimum speed supported by the gripper
	 * @param maxSpeed maximum speed supported by the gripper
	 * @param defaultGripSpeed default value for the speed for a grip action. This value is used for, e.g. performing a
	 * 	                      "default" grip action using the toolbar
	 * @param defaultReleaseSpeed default value for the speed for a grip action. This value is used for, e.g. performing a
	 * 	                         "default" release action using the toolbar
	 * @param unit the unit for all specified values, not {@code null}
	 * @return a speed capability allowing for dynamic adjustments of the capability properties including the value range
	 *         and default values
	 * @throws InvalidCapabilityRange if {@code minSpeed} > {@code maxSpeed}
	 * @throws InvalidCapabilityRange if {@code defaultGripSpeed} or {@code defaultReleaseSpeed} is outside the range
	 *                                defined by {@code minSpeed} and {@code maxSpeed}.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time by a URCap implementing
	 *         the {@link GripperContribution} interface, i.e. called outside the scope of the configuration of the
	 *         gripper.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time by a (regular) URCap which has
	 *         registered its program node contribution/service as conformant with a PolyScope gripper (using
	 *         {@link GripperRegistrationManager#registerAsGripper(Class)}), i.e. called outside the scope of the call to
	 *         either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for a Swing-based
	 *         URCap) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
	 *         a HTML-based URCap).
	 */
	SpeedCapability registerSpeedCapability(double minSpeed, double maxSpeed, double defaultGripSpeed, double defaultReleaseSpeed, Speed.Unit unit);

	/**
	 * <p>
	 * Register a vacuum capability for a gripper that supports gripping using a user configurable vacuum level.
	 * </p>
	 *
	 * If the gripper works with absolute pressure, specify a positive range for the supported vacuum level.
	 * If the gripper works with relative pressure (vacuum), specify a negative range for the supported vacuum level.
	 *
	 * @param minVacuum minimum vacuum level supported by the gripper
	 * @param maxVacuum maximum vacuum level supported by the gripper
	 * @param defaultGripVacuum default value for the vacuum level for a grip action. This value is used for, e.g.
	 *                          performing a "default" grip action using the toolbar
	 * @param unit the unit for all specified values, not {@code null}
	 * @return a vacuum capability allowing for dynamic adjustments of the capability properties including the value range
	 *         and default value
	 * @throws InvalidCapabilityRange if {@code minVacuum} > {@code maxVacuum} or {@code defaultGripVacuum} is outside the
	 *                                range defined by {@code minVacuum} and {@code maxVacuum}.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time by a URCap implementing
	 *         the {@link GripperContribution} interface, i.e. called outside the scope of the configuration of the
	 *         gripper.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time by a (regular) URCap which has
	 *         registered its program node contribution/service as conformant with a PolyScope gripper (using
	 *         {@link GripperRegistrationManager#registerAsGripper(Class)}), i.e. called outside the scope of the call to
	 *         either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for a Swing-based
	 *         URCap) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
	 *         a HTML-based URCap).
	 */
	GripVacuumCapability registerGrippingVacuumCapability(double minVacuum, double maxVacuum, double defaultGripVacuum, Pressure.Unit unit);

	/**
	 * <p>
	 * Register a multi-gripper capability for a gripper that supports a set of multiple individual grippers/zones (from
	 * which the end user can select an individual gripper/zone to operate).
	 *
	 * </p>
	 * When this capability is registered, it is possible to support two use cases:
	 * <ul>
	 *     <li>
	 *         A gripping device physically constructed in a way where it is logically partitioned in multiple
	 *         zones/grippers ("built into" the device).
	 *     </li>
	 *     <li>
	 *         A gripper URCap with the option of supporting a number of separate, identical grippers which can be
	 *         mounted on the robot at the same time (for instance using a special mounting bracket). Typically the end
	 *         user has the choice of using either a setup with a single gripper or one with multiple grippers.
	 *     </li>
	 * </ul>
	 * </p>
	 * <p>
	 *
	 * <p>
	 * Each of the individual grippers will have to support any other capability (e.g. the width capability) that has
	 * been registered with this interface, i.e. all the grippers will have the exact same set of capabilities. Note
	 * that it is a requirement for registering this capability that the grippers are identical in terms of their
	 * capabilities. <br>
	 *
	 * It possible to dynamically adjust properties (including the value range and default values) of each registered
	 * capability exclusively for each individual gripper (independently of the other grippers). This is typically not
	 * applicable for most grippers, but can be relevant when the range depends on another custom gripper setting (which
	 * can be configured by the user).<br>
	 *
	 * If an update of the properties of a capability needs to apply for all individual grippers, it is more convenient
	 * to perform the adjustment simultaneously for all grippers using the capability instance (e.g. {@link WidthCapability})
	 * returned when the capability was registered (with this interface).
	 * </p>
	 *
	 * <p>
	 * When this capability is registered, all potentially supported grippers <b>must</b> be added upfront, but can be
	 * created in an initial disabled state, and the full list of grippers <b>must</b> contain at least two grippers.
	 * Adding additional grippers at a later time is not possible. <br>
	 *
	 * It is, however, possible to enable and disable each gripper dynamically using
	 * {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}. This is useful, if the gripper URCap is
	 * meant to support both a use case with only a single gripper as well as supporting the option of mounting several
	 * separate, identical grippers on the robot at the same time. In this case, the secondary gripper(s) can be created
	 * in an initial disabled state, and then enabled when the end user is using a multi-gripper setup.
	 * </p>
	 *
	 * <p>
	 * Other contributions (for example contributed by other 3rd party URCaps) will be able to select a specific
	 * individual gripper when creating a configuration for a {@link GripperNode} which is using this multi-gripper
	 * device.
	 * </p>
	 *
	 * The following is only relevant for URCaps implementing the {@link GripperContribution} interface:
	 * <ul>
	 *     <li>
	 *         After registration of this capability, each (enabled) individual gripper will be selectable by the end
	 *         user in the Gripper toolbar and program node (for this gripper device). This enables the end user to
	 *         select which individual gripper or zone to operate.
	 *     </li>
	 *     <li>
	 *         After each gripper has been created, it is possible to add an individual TCP for the gripper using the
	 *         {@link SystemConfiguration#getTCPConfiguration(SelectableGripper)} method (accessible through the
	 * 	       {@code systemConfiguration} parameter when
	 * 	       {@link GripperContribution#configureInstallation(CustomUserInputConfiguration, SystemConfiguration, TCPConfiguration, GripperAPIProvider)}
	 * 	       is called)
	 *     </li>
	 * </ul>
	 *
	 * @param gripperListProvider Provider of the list of all supported individual grippers/zones, not {@code null}. The
	 *                            implementation of {@link GripperListProvider#getGripperList(GripperListBuilder, Locale)}
	 *                            will be called once (by PolyScope) to retrieve the list.
	 * @return A multi-gripper capability instance providing access to functionality, such as, enabling/disabling individual
	 *         grippers, access to all registered capabilities (e.g. the width capability) allowing for dynamic adjustment
	 *         of their parameters exclusively for this specific gripper (independently of the other grippers), and access
	 *         to the list of added grippers.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws LessThanTwoGrippers if {@code null} is returned (instead of a list) when PolyScope calls the implementation
	 *         of {@link GripperListProvider#getGripperList(GripperListBuilder, Locale)}.
	 * @throws CalledOutsideGripperConfigurationPhase if this method is called at the wrong time by a URCap implementing
	 *         the {@link GripperContribution} interface, i.e. called outside the scope of the configuration of the
	 *         gripper.
	 * @throws CalledOutsideMethodScope if this method is called at the wrong time by a (regular) URCap which has
	 *         registered its program node contribution/service as conformant with a PolyScope gripper (using
	 *         {@link GripperRegistrationManager#registerAsGripper(Class)}), i.e. called outside the scope of the call to
	 *         either {@link SwingProgramNodeService#configureContribution(ContributionConfiguration)} (for a Swing-based
	 *         URCap) or {@link ProgramNodeServiceConfigurable#configureContribution(ProgramNodeConfiguration)} (for
	 *         a HTML-based URCap).
	 *
	 * @since 1.11.0
	 */
	MultiGripperCapability registerMultiGripperCapability(GripperListProvider gripperListProvider);
}
