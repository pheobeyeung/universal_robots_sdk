/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.gripper.capability.multigripper;

import com.ur.urcap.api.contribution.driver.general.tcp.TCPConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.GripActionParameters;
import com.ur.urcap.api.contribution.driver.gripper.GripperContribution;
import com.ur.urcap.api.contribution.driver.gripper.ReleaseActionParameters;
import com.ur.urcap.api.contribution.driver.gripper.SystemConfiguration;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripDetectedParameters;
import com.ur.urcap.api.contribution.driver.gripper.capability.GripperCapabilities;
import com.ur.urcap.api.contribution.driver.gripper.capability.MultiGripperCapability;
import com.ur.urcap.api.contribution.driver.gripper.capability.ReleaseDetectedParameters;

import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.SelectableGripper;

import java.util.Locale;


/**
 * <p>
 * This interface is used for creating the list of individual grippers/zones available in a multi-gripper device, i.e. a 
 * gripper which has registered the multi-gripper capability (using the method
 * {@link GripperCapabilities#registerMultiGripperCapability(GripperListProvider)}). It must be used to create and add
 * all supported grippers/zones, and build the final list to be returned from
 * {@link GripperListProvider#getGripperList(GripperListBuilder, Locale)}.
 * </p>
 *
 * <p>
 * At least two grippers/zones <b>must</b> be created, and all added grippers/zones must have a unique identifier and 
 * name. Note that the identifier of all the grippers must be constant over time and versions of the URCap as this is 
 * used for persistence of the gripper as well as, it can be used by other contributions (for example contributed by 
 * other 3rd party URCaps) to identify the gripper.
 * </p>
 *
 *
 * For each of the created grippers, it is possible individually to:
 * <ul>
 *     <li>
 *         Disable/enable the gripper using {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}
 *     </li>
 *     <li>
 *         Add a TCP for the gripper with the {@link TCPConfiguration} instance returned by
 *         {@link SystemConfiguration#getTCPConfiguration(SelectableGripper)}
 *     </li>
 * </ul>
 *
 * @since 1.11.0
 */
public interface GripperListBuilder {

	/**
	 * <p>
	 * Creates an individual gripper/zone and adds it to the list of gripper (which will be returned when the method
	 * {@link #buildList()} is called).
	 * </p>
	 *
	 * <p>
	 * The returned {@link SelectableGripper} instance can be used to disable/enable the gripper using
	 * {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}. It can also be used to add a TCP for the
	 * gripper with the {@link TCPConfiguration} instance returned by
	 * {@link SystemConfiguration#getTCPConfiguration(SelectableGripper)}. A reference to this gripper instance can be
	 * stored in the contribution class for easy access.
	 * </p>
	 *
	 * <p>
	 * For a URCap implementing the {@link GripperContribution} interface, a {@link SelectableGripper} instance will be 
	 * provided as input to script generation for grip and release actions (see the {@link GripActionParameters} and 
	 * {@link ReleaseActionParameters} interfaces). The provided gripper instance should be used to identify which gripper 
	 * to generate script code for. A {@link SelectableGripper} instance will also be provided as input for script code
	 * generation for feedback capabilities (see the {@link GripDetectedParameters} and {@link ReleaseDetectedParameters}
	 * interfaces).
	 * </p>
	 *
	 * <p>
	 * Each created {@link SelectableGripper} instance will also be included in the list returned by
	 * {@link MultiGripperSupport#getSelectableGrippers()}. This list is used by other contributions (for example
	 * contributed by other 3rd party URCaps) to select a specific gripper when creating a configuration for a
	 * {@link GripperNode} which is using a multi-gripper device. Note that only enabled grippers will be included in
	 * this list.
	 * </p>
	 * 
	 * @param id The unique identifier for the gripper/zone, not {@code null} nor an empty string. <b>Must</b> be unique 
	 *           and constant over time and versions of the URCap as this is used for persistence of the gripper as well 
	 *           as, it can be used by other contributions (for example contributed by other 3rd party URCaps) to 
	 *           identify the gripper.
	 * @param displayName The name of the griper/zone to be shown in the PolyScope user interface, not {@code null} nor 
	 *                    an empty string. For instance, for UCRaps implementing the {@link GripperContribution} interface,
	 *                    it will be displayed in the Gripper toolbar and program node. The name will also be used as a
	 *                    prefix in the program tree title of the Gripper node, except for when only one gripper is 
	 *                    enabled, in which case the prefix will be the title of the gripper contribution (returned by
	 *                    {@link GripperContribution#getTitle(Locale)}).
	 * @param initialEnabledState The initial enablement state of the new gripper/zone. If {@code true}, the gripper will
	 *                            initially by enabled, otherwise the gripper will initially be disabled and not available
	 *                            in PolyScope. After creation of the gripper, it can be disabled/enabled using
	 *                            {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}.
	 * @return The new individual gripper/zone. The gripper can be disabled/enabled using
	 * {@link MultiGripperCapability#setEnabled(SelectableGripper, boolean)}. It can also be used to add a TCP for the
	 * gripper with {@link SystemConfiguration#getTCPConfiguration(SelectableGripper)}. A reference to this gripper
	 * instance can be stored in the contribution class for easy access.
	 * @throws DuplicateGripperID if a gripper/zone with the same identifier (as specified by {@code id}) has already 
	 *                            been added
	 * @throws DuplicateGripperName if a gripper/zone with the same name (as specified by {@code displayName}) has 
	 *                              already been added
	 */
	SelectableGripper createGripper(String id, String displayName, boolean initialEnabledState);

	/**
	 * Build the final list with all created grippers/zones. At least two grippers/zones <b>must</b> have been added with 
	 * the {@link #createGripper(String, String, boolean)} method before calling this method.
	 *
	 * @return The unmodifiable list containing all the added grippers/zones
	 * @throws LessThanTwoGrippers if less than two grippers/zones have been added with 
	 *                             {@link #createGripper(String, String, boolean)}
	 */
	GripperList buildList();
}
