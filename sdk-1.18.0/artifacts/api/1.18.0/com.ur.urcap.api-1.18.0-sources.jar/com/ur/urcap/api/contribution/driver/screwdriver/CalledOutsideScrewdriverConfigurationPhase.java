/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver;


/**
 * This exception is thrown if an attempt is made to register a capability outside the scope of the Screwdriver Configuration
 * phase, i.e. outside the scope of the {@link ScrewdriverContribution#configureScrewdriver(ScrewdriverConfiguration, ScrewdriverAPIProvider)}
 * method.
 *
 * @since 1.9.0
 */
public class CalledOutsideScrewdriverConfigurationPhase extends RuntimeException {

	/**
	 * Constructs a new called outside screwdriver configuration phase exception with the specified detail message.
	 * @param message the detail message.
	 */
	public CalledOutsideScrewdriverConfigurationPhase(String message) {
		super(message);
	}
}
