/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver;

import com.ur.urcap.api.contribution.driver.general.tcp.TCPConfiguration;
import com.ur.urcap.api.contribution.driver.general.userinput.CustomUserInputConfiguration;
import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.domain.value.PoseFactory;

import java.util.Locale;


/**
 * <p>
 * This interface defines an API for adding functionality for screwdrivers to PolyScope.
 * </p>
 *
 * <p>
 * Implementing this interface will "integrate" (hook) this screwdriving contribution into the builtin (native) PolyScope
 * Screwdriving program node and Screwdriving installation screen. This will expose the screwdriving functionality
 * supported by the screwdriver to the end user.
 * </p>
 *
 * <p>
 * <b>Note:</b> Both the builtin (native) PolyScope Screwdriving program node and Screwdriver contributions are
 * not supported on CB3 robots. If a URCap registers a Screwdriver contribution on a CB3 robot, the URCap will fail to
 * be activated.
 * </p>
 *
 * <p>
 * The Screwdriving program node allows the end user to program screwdriving operations. The configuration options
 * available to the end user are based on the properties and capabilities supported by the screwdriver. As a minimum,
 * all screwdrivers must support "default" screw (start screwdriver) and stop (stop screwdriver) operations. All other
 * capabilities are optional to support and can be registered when the method
 * {@link ScrewdriverContribution#configureScrewdriver(ScrewdriverConfiguration, ScrewdriverAPIProvider)} is called.
 * </p>
 *
 * <p>
 * The integration in the Screwdriving installation screen allows the user to select the screwdriver for programming
 * screwing operations (using the Screwdriving program node). It also offers the possibility to define any custom inputs
 * from the end user that are required to setup the screwdriver, e.g. specifying an IP address. This functionality is
 * optional, since such configuration properties are specific for each screwdriver device. The corresponding generated
 * custom UI will be accessible in the screen when the screwdriver is selected (by the end user) and replace the default
 * Screwdriving installation UI. Access to create a custom configuration based on user inputs is provided when the method
 * {@link ScrewdriverContribution#configureInstallation(CustomUserInputConfiguration, SystemConfiguration, TCPConfiguration, ScrewdriverAPIProvider)}
 * is called.
 * </p>
 *
 * @since 1.9.0
 */
public interface ScrewdriverContribution {

	/**
	 * This method must return the title of the screwdriver contribution. The title is displayed in:
	 * <ul>
	 *     <li>The builtin (native) PolyScope Screwdriving installation screen at the top where the screwdriver
	 *         is selected
	 *     </li>
	 *     <li>The screen for the builtin (native) PolyScope Screwdriving program node (if this screwdriver
	 * 	       has been selected in the Screwdriving installation screen)
	 * 	   </li>
	 * </ul>
	 *
	 * This method is called once upon startup.
	 *
	 * @param locale the current locale of PolyScope. Can be used for supporting titles in several languages.
	 * @return the title of this screw driver contribution, not {@code null} nor an empty string.
	 */
	String getTitle(Locale locale);

	/**
	 * <p>
	 * When this method is called, optional PolyScope properties for this screwdriver contribution can be configured. The
	 * method is called once after this screwdriver contribution is registered.
	 * </p>
	 *
	 * <p>
	 * Modify the configuration parameter to configure your contribution. The configuration object will already have default
	 * values for its properties.
	 * </p>
	 *
	 * <p>
	 * The values of the contribution configuration object will be read once immediately after this method call. Changing
	 * values at a later stage will have no effect, so do not store a reference to the configuration object.
	 * </p>
	 *
	 * If the default values are appropriate, leave the implementation of this method empty.
	 *
	 * @param configuration a modifiable configuration instance with default values that can be used for configuring
	 *                      the PolyScope properties of this contribution
	 */
	void configureContribution(ContributionConfiguration configuration);

	/**
	 * <p>
	 * When this method is called, use the configuration parameter to register or setup optional properties and capabilities
	 * of the screwdriver.
	 * </p>
	 *
	 * <p>
	 * The method is called in the Screwdriver Configuration phase after this contribution has been registered when a new
	 * installation is loaded or created.
	 * </p>
	 *
	 * <b>Note:</b> If the screwdriver only supports basic "default" screw (see
	 * {@link #generateStartScrewdriverScript(ScriptWriter, ScrewdriverParameters)}) and stop (see
	 * {@link #generateStopScrewdriverScript(ScriptWriter, ScrewdriverParameters)}) operations, leave the implementation
	 * of this method empty.
	 *
	 * @param screwdriverConfiguration a configuration instance that can be used for registering or setting up the
	 *                                 properties and capabilities of the screwdriver.
	 * @param apiProvider provides access to functionality and services available from within PolyScope which can be
	 *                    relevant for setting up the screwdriver capabilities (e.g. the {@link SystemAPI} interface
	 *                    with functionality for querying information about the robot).
	 */
	void configureScrewdriver(ScrewdriverConfiguration screwdriverConfiguration, ScrewdriverAPIProvider apiProvider);

	/**
	 * <p>
	 * When this method is called, required configuration related to the setup of the screwdriver can be defined/performed,
	 * e.g. defining custom user inputs, adding a TCP contribution for the screwdriver and configuring the settings of the
	 * Tool I/O Interface.
	 * </p>
	 *
	 * <p>
	 * The method is called in the Installation Configuration phase after this contribution has been registered when a
	 * new installation is loaded or created.
	 * </p>
	 *
	 * If no configuration is needed, leave the implementation of this method empty.
	 *
	 * @param customConfiguration use this instance to register custom user inputs for setting up the screwdriver. The
	 *                            corresponding generated UI will be accessible in the builtin (native) PolyScope
	 *                            Screwdriving installation screen when this screwdriver is selected (by the end user).
	 * @param systemConfiguration use this instance to configure the robot system for this screwdriver, e.g. configure the
	 *                            Tool I/O interface settings
	 * @param tcpConfiguration use this instance to add a TCP for this screwdriver to PolyScope as well as update the TCP's
	 *                         offset and remove the TCP again. A screwdriver contribution can only contribute one TCP to PolyScope.
	 * @param apiProvider Provides access to functionality and services available from within PolyScope which can be
	 * 	                  relevant for defining the installation of the screwdriver (e.g. the {@link PoseFactory}
	 * 	                  interface which is needed for creating TCPs)
	 */
	void configureInstallation(CustomUserInputConfiguration customConfiguration, SystemConfiguration systemConfiguration,
							   TCPConfiguration tcpConfiguration, ScrewdriverAPIProvider apiProvider);

	/**
	 * <p>
	 * Generate script code that must be executed before any screwdriver operations can be performed (such as required
	 * initialization) when this method is called. The script code is added to the beginning (preamble) of the
	 * script code executed when a robot program is run.
	 * </p>
	 *
	 * <b>Note:</b> Generating preamble script code is optional. Leave the implementation of this method empty, if
	 * execution of initialization script code is not needed.
	 *
	 * @param scriptWriter use this script writer instance to generate the script code that must be executed before
	 *                     screwdriver operations can be performed
	 */
	void generatePreambleScript(ScriptWriter scriptWriter);

	/**
	 * <p>
	 * When this method is called, the script code for driving the screw must be generated.
	 * </p>
	 *
	 * The relevant parameters for the registered optional screwdriver capabilities/requirements defined/configured by
	 * the end user are provided as input to the script code generation.
	 *
	 * @param scriptWriter use this script writer instance to generate the script code for driving the screw
	 * @param parameters the parameters for the screwdriving operation defined/configured by the end user
	 */
	void generateStartScrewdriverScript(ScriptWriter scriptWriter, ScrewdriverParameters parameters);

	/**
	 * <p>
	 * When this method is called, the script code for stopping the screw driver must be generated (i.e. the screwdriver
	 * must stop the current screwdriving operation).
	 * </p>
	 *
	 * The relevant parameters for the registered optional screwdriver capabilities/requirements defined/configured by
	 * the end user are provided as input to the script code generation.
	 *
	 * @param scriptWriter use this script writer instance to generate the script code for stopping the screwdriver
	 * @param parameters the parameters for the screwdriving operation defined/configured by the end user
	 */
	void generateStopScrewdriverScript(ScriptWriter scriptWriter, ScrewdriverParameters parameters);
}
