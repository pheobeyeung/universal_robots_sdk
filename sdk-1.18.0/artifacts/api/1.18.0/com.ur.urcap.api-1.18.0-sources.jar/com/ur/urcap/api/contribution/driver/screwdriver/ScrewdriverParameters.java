/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.ScrewdriverCapabilities;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram.ScrewdriverProgram;
import com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram.ScrewdriverProgramListProvider;


/**
 * This interface represents parameters for a screwdriver operation defined/configured by the end user.
 *
 * @since 1.9.0
 */
public interface ScrewdriverParameters {

	/**
	 * <p>
	 * Get the selected screwdriver program to be used for the screwdriver operation.
	 * </p>
	 *
	 * This is only valid, if the program selection capability has been registered (using the method
	 * {@link ScrewdriverCapabilities#registerProgramSelectionCapability(ScrewdriverProgramListProvider, ScriptCodeGenerator)}).
	 *
	 * @return The selected screwdriver program to use for the operation.
	 * @throws UnsupportedOperationException if the screwdriver has not registered the program selection capability
	 */
	ScrewdriverProgram getScrewdriverProgram();

	/**
	 * <p>
	 * Get the selected screwdriver operation type.
	 * </p>
	 *
	 * This is only valid, if the operation type capability has been registered (using the method
	 * {@link ScrewdriverCapabilities#registerOperationTypeCapability()}).
	 *
	 * @return The operation type selected by the user.
	 * @throws UnsupportedOperationException if the screwdriver has not registered the operation type capability
	 */
	ScrewdriverOperationType getScrewdriverOperationType();
}
