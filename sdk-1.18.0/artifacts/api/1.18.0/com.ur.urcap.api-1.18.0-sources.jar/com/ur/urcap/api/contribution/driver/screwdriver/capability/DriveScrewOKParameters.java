/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 * <p>
 * This interface provides parameters relevant for generating script code for the Drive Screw OK feedback capability
 * (registered using {@link ScrewdriverFeedbackCapabilities#registerDriveScrewOKCapability(ScriptCodeGenerator)}).
 * </p>
 *
 * <p>
 * These parameters are passed when PolyScope calls the implementation of the {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)}
 * method responsible for the generating the script code.
 * </p>
 *
 * The interface is intentionally empty, but could have parameters in future releases.
 *
 * @since 1.9.0
 */
public interface DriveScrewOKParameters {

}
