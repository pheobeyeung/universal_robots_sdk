/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability;

import com.ur.urcap.api.contribution.driver.general.script.ScriptCodeGenerator;
import com.ur.urcap.api.contribution.driver.screwdriver.CalledOutsideScrewdriverConfigurationPhase;
import com.ur.urcap.api.contribution.driver.screwdriver.ScrewdriverAPIProvider;
import com.ur.urcap.api.contribution.driver.screwdriver.ScrewdriverConfiguration;
import com.ur.urcap.api.contribution.driver.screwdriver.ScrewdriverContribution;
import com.ur.urcap.api.domain.script.ScriptWriter;


/**
 * <p>
 * Register the feedback capabilities of the screwdriver using this interface. A feedback capability is a type
 * of status the screwdriver is capable of informing PolyScope about.
 * </p>
 *
 * PolyScope will execute the script code associated with a feedback capability at appropriate times in the given context.
 * Script code generated must be idempotent (meaning it has no side effects when called multiple times if all other state
 * has not changed in between calls). The script code generated must also execute fast, since the feedback could be checked
 * often.
 *
 * @since 1.9.0
 */
public interface ScrewdriverFeedbackCapabilities {

	/**
	 * <p>
	 * Register a feedback capability for a screwdriver that is capable of providing information about whether
	 * or not an ongoing screwdriving operation (driving the screw) ended successfully (ended in OK-state).
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> This capability must only be used to provide feedback about the success of the screwing operation.
	 * It should not be used to provide feedback about failures. To support feedback about when the operation fails,
	 * register the Drive Screw Not Ok feedback capability the using the
	 * {@link #registerDriveScrewNotOKCapability(ScriptCodeGenerator)} method.
	 * </p>
	 *
	 * <p>
	 * The provided implementation of the {@link ScriptCodeGenerator} interface must generate the script code for
	 * determining if the screwing operation succeeded. The return value of the script code must be a boolean, i.e.
	 * 'True' or 'False'. 'True' must be returned if the screwing operation was successful, otherwise 'False' must be
	 * returned.
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> A return value of 'False' must not be used to indicate that the operation failed, but simply that a
	 * success was not (yet) detected. If the screwdriver can provide feedback on whether or not the screwing operation
	 * failed, the Drive Screw Not Ok feedback capability must be used.
	 * </p>
	 *
	 * <b>Example:</b> <br>
	 * The digital tool input 0 will go high if the operation ended in OK-state. The script code is:
	 * <pre>
	 *      return get_tool_digital_in(0)
	 * </pre>
	 *
	 * So the implementation of {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} could be:
	 * <pre>
	 * scriptWriter.appendLine("return get_tool_digital_in(0)");
	 * </pre>
	 *
	 * @param scriptCodeGenerator script code generator responsible for generating the script code for determining if
	 * 	                          the screwing operation succeeded. When the script code needs to be generated, the
	 *                            {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} method will be
	 *                            called (by PolyScope). Return value for the generated script code must be a boolean,
	 *                            i.e. 'True' or 'False'.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideScrewdriverConfigurationPhase if this method is called at the wrong time, i.e. outside the scope
	 * of the {@link ScrewdriverContribution#configureScrewdriver(ScrewdriverConfiguration, ScrewdriverAPIProvider)} method.
	 */
	void registerDriveScrewOKCapability(ScriptCodeGenerator<DriveScrewOKParameters> scriptCodeGenerator);

	/**
	 * <p>
	 * Register a feedback capability for a screwdriver that is capable of providing information about whether
	 * or not an ongoing screwdriving operation (driving the screw) failed, i.e. ended in Not Ok (NOK) state.
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> This capability must only be used to provide feedback about the failure of the screwing operation.
	 * It should not be used to provide feedback about successes. To support feedback about when the operation succeeds,
	 * register the Drive Screw Ok feedback capability the using the {@link #registerDriveScrewOKCapability(ScriptCodeGenerator)}
	 * method.
	 * </p>
	 *
	 * <p>
	 * The provided implementation of the {@link ScriptCodeGenerator} interface must generate the script code for
	 * determining if the screwing operation ended in failure. The return value of the script code must be a boolean,
	 * i.e. 'True' or 'False'. 'True' must be returned if the screwing operation failed, otherwise 'False' must be
	 * returned.
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> A return value of 'False' must not be used to indicate that the operation succeeded, but simply that
	 * a failure was not (yet) detected. If the screwdriver can provide feedback on whether or not the screwing operation
	 * succeeded, the Drive Screw Ok feedback capability should be used.
	 * </p>
	 *
	 * <b>Example:</b> <br>
	 * The digital tool input 1 will go high if the operation ended in NOT OK-state. The script code is:
	 * <pre>
	 *    return get_tool_digital_in(1)
	 * </pre>
	 * So the implementation of {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} could be:
	 * <pre>
	 *    scriptWriter.appendLine("return get_tool_digital_in(1)");
	 * </pre>
	 *
	 *
	 * @param scriptCodeGenerator script code generator responsible for generating the script code for determining if
	 * 	                          the screwing operation failed. When the script code needs to be generated,
	 *                            the {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} method will be
	 *                            called (by PolyScope). Return value for the generated script code must be a boolean,
	 *                            i.e. 'True' or 'False'.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideScrewdriverConfigurationPhase if this method is called at the wrong time, i.e. outside the scope
	 * of the {@link ScrewdriverContribution#configureScrewdriver(ScrewdriverConfiguration, ScrewdriverAPIProvider)} method.
	 */
	void registerDriveScrewNotOKCapability(ScriptCodeGenerator<DriveScrewNotOKParameters> scriptCodeGenerator);

	/**
	 * <p>
	 * Register a feedback capability for a screwdriver that is capable of providing information about whether
	 * or not the screwdriver device is ready to operate (receive commands). This capability is used (by PolyScope) in a
	 * program to ensure that the screwdriver is ready before sending commands to it.
	 * </p>
	 *
	 * <p>
	 * The provided implementation of the {@link ScriptCodeGenerator} interface must generate the script code for
	 * determining if the screwdriver is ready. The return value of the script code must be a boolean, i.e. 'True' or
	 * 'False'. 'True' must be returned if the screwdriver is ready, otherwise 'False' must be returned.
	 * </p>
	 *
	 * The generated script code is executed before the script code for the program selected capability (if that
	 * capability has been registered).
	 *
	 * @param scriptCodeGenerator script code generator responsible for generating the script code for determining if
	 *                            the screwdriver is ready. When the script code needs to be generated, the
	 *                            {@link ScriptCodeGenerator#generateScript(ScriptWriter, Object)} method will be
	 *                            called (by PolyScope). Return value for the generated script code must be a boolean,
	 *                            i.e. 'True' or 'False'.
	 * @throws CapabilityAlreadyRegistered if this capability has already been registered
	 * @throws CalledOutsideScrewdriverConfigurationPhase if this method is called at the wrong time, i.e. outside the scope
	 * of the {@link ScrewdriverContribution#configureScrewdriver(ScrewdriverConfiguration, ScrewdriverAPIProvider)} method.
	 */
	void registerScrewdriverReadyCapability(ScriptCodeGenerator<ScrewdriverReadyParameters> scriptCodeGenerator);
}
