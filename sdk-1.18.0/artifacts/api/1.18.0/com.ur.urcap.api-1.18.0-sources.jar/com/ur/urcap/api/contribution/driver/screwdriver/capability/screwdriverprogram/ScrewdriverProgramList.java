/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.driver.screwdriver.capability.screwdriverprogram;

import java.util.List;


/**
 * <p>
 * This interface represents the list of programs, typically defined on an external control box for the screwdriver.
 * </p>
 *
 * Use the interface to provide the list of screw driver programs to PolyScope.
 *
 * @since 1.9.0
 */
public interface ScrewdriverProgramList {

	/**
	 * Add a screwdriver program to the list of programs.
	 *
	 * @param screwdriverProgram program to add, not {@code null}
	 * @throws DuplicateScrewdriverProgramID if the ids of the screwdriver programs (returned by the method
	 *                                       {@link ScrewdriverProgram#getId()}) are not unique.
	 * @throws NameOfScrewdriverProgramCannotBeNullOrEmpty if the display name of a program (returned by the method
	 * 	                                                 {@link ScrewdriverProgram#getDisplayName()}) is {@code null} or
	 * 	                                                 an empty string.
	 */
	void add(ScrewdriverProgram screwdriverProgram);

	/**
	 * Add a list of screwdriver programs to the list of programs.
	 *
	 * @param screwdriverProgramList list of programs to add, not {@code null}
	 * @throws DuplicateScrewdriverProgramID if the ids of the screwdriver programs (returned by the method
	 *                                       {@link ScrewdriverProgram#getId()}) are not unique.
	 * @throws NameOfScrewdriverProgramCannotBeNullOrEmpty if the display name of a program (returned by the method
	 * 	                                                 {@link ScrewdriverProgram#getDisplayName()}) is {@code null} or
	 * 	                                                 an empty string.
	 */
	void addAll(List<ScrewdriverProgram> screwdriverProgramList);
}
