/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.program;

import com.ur.urcap.api.domain.ProgramAPI;
import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.UserInterfaceAPI;


/**
 * Provides access to functionality and services relevant for program nodes. This includes what is available
 * from within PolyScope, as well as creating additional model elements to be used within PolyScope.
 *
 * @since 1.3.0
 */
public interface ProgramAPIProvider {

	/**
	 * Provides access to system related functionality
	 *
	 * @return an instance of SystemAPI
	 */
	SystemAPI getSystemAPI();

	/**
	 * Provides access to functionality related to user interface and end user interaction
	 *
	 * @return an instance of UserInterfaceAPI
	 */
	UserInterfaceAPI getUserInterfaceAPI();

	/**
	 * Provides access to functionality relevant related to programs
	 *
	 * @return an instance of ProgramAPI
	 */
	ProgramAPI getProgramAPI();
}
