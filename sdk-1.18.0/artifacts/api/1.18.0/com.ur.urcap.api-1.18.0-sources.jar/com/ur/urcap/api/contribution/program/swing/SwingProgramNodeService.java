/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.program.swing;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.contribution.URCapProgramNodeService;
import com.ur.urcap.api.contribution.ViewAPIProvider;
import com.ur.urcap.api.contribution.program.ContributionConfiguration;
import com.ur.urcap.api.contribution.program.CreationContext;
import com.ur.urcap.api.contribution.program.ProgramAPIProvider;
import com.ur.urcap.api.domain.data.DataModel;

import java.util.Locale;


/**
 * Defines an API required for defining and adding to PolyScope a new type of program node and corresponding screen where
 * the user interface is Swing-based.
 *
 * @param <C>  the (generic) type parameter for the interface representing the type of {@link ProgramNodeContribution}
 *             created by this SwingProgramNodeService
 * @param <V>  the (generic) type parameter for the interface representing the type of the view used by all the
 *             {@link ProgramNodeContribution} created by this service
 *
 * @since 1.3.0
 */
public interface SwingProgramNodeService<C extends ProgramNodeContribution, V extends SwingProgramNodeView<C>> extends URCapProgramNodeService {

	/**
	 * Get the unique identifier for this kind of program node. The identifier will be used when storing programs that
	 * use the program node.
	 *
	 * @return the unique identifier
	 */
	String getId();

	/**
	 * <p>
	 * This method is called once after the this service is registered. Modify the configuration parameter
	 * to configure your contribution. The configuration object will already have default values for its properties
	 * matching most use cases.
	 * </p>
	 *
	 * <p>
	 * The values of the ContributionConfiguration object will be read once immediately after this method call. Changing
	 * values at a later stage will have no effect, so do not store a reference to the configuration object.
	 * </p>
	 *
	 * If the default values are appropriate, leave this method empty.
	 *
	 * @param configuration a modifiable ContributionConfiguration with default values
	 */
	void configureContribution(ContributionConfiguration configuration);

	/**
	 *
	 * @param locale The current locale of PolyScope. Can be used for supporting titles in several languages.
	 * @return The text displayed in the Structure Tab for program nodes created by this service as well as the title of
	 *         the corresponding program node screen. Called once at start up.
	 */
	String getTitle(Locale locale);

	/**
	 * Creates a new View instance which implements the UI for your program node screen. Called once when a new
	 * program is loaded or created.
	 *
	 * @param apiProvider Provides access to functionality and services available from within PolyScope related to user
	 *                    interface and end user interaction
	 * @return the view
	 */
	V createView(ViewAPIProvider apiProvider);

	/**
	 * <p>
	 * Creates a new program node instance. This happens when the end user clicks the button on the Structure tab or
	 * when an existing program node is loaded
	 * </p>
	 * <p>
	 * The returned node must use the supplied data model object to retrieve and store the data contained in it.
	 * All modifications to the supplied data model from the program node constructor are ignored when an existing program
	 * node is loaded or copy/pasted.
	 * </p>
	 *
	 * @param apiProvider Provides access to functionality and services available from within PolyScope relevant for the
	 *                    program node.
	 * @param view the View created by {@link #createView(ViewAPIProvider)}. This reference can be stored
	 *                and used in {@link ProgramNodeContribution#openView()}
	 *                or as a result of an event for a Swing UI-component.
	 *                <p>
	 *                <b>Note:</b> The view must not be used in the node contribution constructor.
	 *                The view is a shared entity between several contributions
	 *                and is not ready to be used at this time.
	 *                </p>
	 * @param model object where all configuration data of the new program node instance is to be stored in and
	 *              retrieved from
	 * @param context the context in which this node is created
	 * @return the newly constructed program node contribution instance
	 */
	C createNode(ProgramAPIProvider apiProvider, V view, DataModel model, CreationContext context);
}
