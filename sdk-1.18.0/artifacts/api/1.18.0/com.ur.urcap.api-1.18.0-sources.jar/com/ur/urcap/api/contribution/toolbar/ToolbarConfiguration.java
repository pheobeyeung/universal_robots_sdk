/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.toolbar;


/**
 * Provides access to configure a toolbar contribution. Alter functionality, look or usage of the toolbar.
 *
 * @since 1.3.0
 */
public interface ToolbarConfiguration {

	/**
	 * <p>
	 * Sets the height of the toolbar
	 * </p>
	 *
	 * The default value is the maximum allowed height.
	 *
	 * @param desiredHeight the desired pixel height of the toolbar panel.
	 */
	void setToolbarHeight(int desiredHeight);
}
