/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.contribution.toolbar.swing;

import com.ur.urcap.api.contribution.toolbar.ToolbarConfiguration;
import com.ur.urcap.api.contribution.toolbar.ToolbarContext;

import javax.swing.Icon;


/**
 * <p>
 * Defines an API required for defining and adding to PolyScope a toolbar.
 * </p>
 *
 * <b>Note:</b> Toolbar contributions are not supported on CB3 robots.
 *
 * @since 1.3.0
 */
public interface SwingToolbarService {

	/**
	 * @return The icon displayed in PolyScope for the URCap's toolbar. Called once at startup.
	 * @throws NullPointerException in case this methods returns {@code null}.
	 */
	Icon getIcon();

	/**
	 * <p>
	 * This method is called once after this service is registered. Modify the configuration parameter
	 * to configure your contribution. The configuration object will already have default values for its properties
	 * matching most use cases.
	 * </p>
	 *
	 * <p>
	 * The values of the ToolbarConfiguration object will be read once immediately after this method call. Changing
	 * values at a later stage will have no effect, so do not store a reference to the configuration object.
	 * </p>
	 *
	 * If the default values are appropriate, leave this method empty.
	 *
	 * @param configuration a modifiable {@code ToolbarConfiguration} instance with default values.
	 */
	void configureContribution(ToolbarConfiguration configuration);

	/**
	 * Creates a new toolbar instance.
	 *
	 * @param context Provides access to services and APIs relevant for the toolbar.
	 * @return the newly constructed toolbar contribution instance. Called once at startup.
	 */
	SwingToolbarContribution createToolbar(ToolbarContext context);
}
