/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.domain.device.DeviceManager;
import com.ur.urcap.api.domain.feature.FeatureModel;
import com.ur.urcap.api.domain.io.IOModel;
import com.ur.urcap.api.domain.payload.PayloadModel;
import com.ur.urcap.api.domain.resource.ResourceModel;
import com.ur.urcap.api.domain.tcp.TCPModel;
import com.ur.urcap.api.domain.value.ValueFactoryProvider;
import com.ur.urcap.api.domain.variable.VariableModel;
import org.osgi.annotation.versioning.ProviderType;

/**
 * Provides access to functionality and services which are relevant for various different applications and contexts.
 * This includes what is available from within PolyScope, as well as creating additional model elements to be used within
 * PolyScope.
 *
 * @since 1.3.0
 */
@ProviderType
public interface ApplicationAPI {

	/**
	 * @return An interface for working with the inputs and outputs of the robot
	 */
	IOModel getIOModel();

	/**
	 * @return An interface for working with the features of the current installation
	 */
	FeatureModel getFeatureModel();

	/**
	 * @return An interface for accessing the TCPs of the current installation
	 *
	 * @since 1.5.0
	 */
	TCPModel getTCPModel();

	/**
	 * <p>
	 * Gets an interface which provides access the payloads in the current PolyScope installation.
	 * </p>
	 *
	 * @return An interface for accessing the payloads in the current PolyScope installation
	 *
	 * @since 1.13.0
	 */
	PayloadModel getPayloadModel();

	/**
	 * @return An interface for working with variables
	 */
	VariableModel getVariableModel();

	/**
	 * @return An interface with access to various queryable-only system resources
	 *
	 * @since 1.7.0
	 */
	ResourceModel getResourceModel();

	/**
	 * @return An interface for accessing various factories capable of creating value objects.
	 */
	ValueFactoryProvider getValueFactoryProvider();

	/**
	 * This method can be used to get a specific {@link InstallationNodeContribution} instance
	 *
	 * @param installationType The class of the installation node contribution to return
	 * @param <T> The generic for specifying the {@link InstallationNodeContribution}
	 * @return The installation node instance
	 */
	<T extends InstallationNodeContribution> T getInstallationNode(Class<T> installationType);

	/**
	 * This method can be used to get a specific {@link DeviceManager} instance
	 *
	 * @param deviceManagerClass The class for the device manager to return
	 * @param <T> The generic type of class to return
	 * @return An interface for registering and working with a specific device
	 *
	 * @since 1.9.0
	 */
	<T extends DeviceManager> T getDeviceManager(Class<T> deviceManagerClass);
}
