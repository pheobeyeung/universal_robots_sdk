/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.installation.InstallationAPIProvider;
import com.ur.urcap.api.contribution.program.ProgramAPIProvider;
import com.ur.urcap.api.domain.feature.FeatureModel;
import com.ur.urcap.api.domain.function.FunctionModel;
import com.ur.urcap.api.domain.io.IOModel;
import com.ur.urcap.api.domain.program.ProgramModel;
import com.ur.urcap.api.domain.robot.RobotModel;
import com.ur.urcap.api.domain.system.SystemSettings;
import com.ur.urcap.api.domain.userinteraction.UserInteraction;
import com.ur.urcap.api.domain.value.ValueFactoryProvider;
import com.ur.urcap.api.domain.variable.VariableModel;


/**
 * <p>
 * Provides access to functionality available from within PolyScope, as well as creating additional model elements
 * to be used within PolyScope.
 * </p>
 *
 * <b>NOTE</b>: This interface is only relevant for URCap program and installation nodes with a HTML-based user interface
 * (see {@link com.ur.urcap.api.contribution.InstallationNodeService} and {@link com.ur.urcap.api.contribution.ProgramNodeService}).
 *
 * @since 1.0.0
 */
public interface URCapAPI {

	/**
	 * @return The installation api provider gives access to interfaces relevant for contributed installation nodes.
	 *
	 * @since 1.5.0
	 */
	InstallationAPIProvider getInstallationAPIProvider();

	/**
	 * @return The program api provider gives access to interfaces relevant for contributed program nodes.
	 *
	 * @since 1.5.0
	 */
	ProgramAPIProvider getProgramAPIProvider();

	/**
	 * @deprecated Use {@link SystemAPI} instead accessible through both {@link #getInstallationAPIProvider()} and
	 * {@link #getProgramAPIProvider()}.
	 *
	 * @return an interface for obtaining version information about PolyScope.
	 */
	@Deprecated
	SoftwareVersion getSoftwareVersion();

	/**
	 * @deprecated Use {@link SystemAPI} instead accessible through both {@link #getInstallationAPIProvider()} and
	 * {@link #getProgramAPIProvider()}.
	 *
	 * @return an interface for obtaining system settings (e.g. locale) for PolyScope.
	 *
	 * @since 1.2.56
	 */
	@Deprecated
	SystemSettings getSystemSettings();

	/**
	 * @deprecated Use {@link SystemAPI} instead accessible through both {@link #getInstallationAPIProvider()} and
	 * {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface providing information about the robot.
	 */
	@Deprecated
	RobotModel getRobotModel();

	/**
	 * @deprecated Use {@link InstallationAPI} or {@link ProgramAPI} instead accessible through their respective
	 * providers, i.e. {@link #getInstallationAPIProvider()} or {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface for working with the inputs and outputs of the robot.
	 */
	@Deprecated
	IOModel getIOs();

	/**
	 * @deprecated Use {@link InstallationAPI} or {@link ProgramAPI} instead accessible through their respective
	 * providers, i.e. {@link #getInstallationAPIProvider()} or {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface for working with the features of the current installation.
	 */
	@Deprecated
	FeatureModel getFeatures();

	/**
	 * @deprecated Use {@link InstallationAPI} instead accessible through its provider, {@link #getInstallationAPIProvider()}.
	 *
	 * @return An interface for adding script functions to PolyScope.
	 *
	 * @since 1.1.0
	 */
	@Deprecated
	FunctionModel getFunctionModel();

	/**
	 * @deprecated Use {@link ProgramAPI} instead accessible through its provider, {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface for working with the sub-trees of a program node.
	 *
	 * @since 1.1.0
	 */
	@Deprecated
	ProgramModel getProgramModel();

	/**
	 * @deprecated Use {@link InstallationAPI} or {@link ProgramAPI} instead accessible through their respective
	 * providers, i.e. {@link #getInstallationAPIProvider()} or {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface for working with variables.
	 *
	 * @since 1.2.56
	 */
	@Deprecated
	VariableModel getVariableModel();

	/**
	 * @deprecated Use {@link InstallationAPI} or {@link ProgramAPI} instead accessible through their respective
	 * providers, i.e. {@link #getInstallationAPIProvider()} or {@link #getProgramAPIProvider()}.
	 *
	 * @return An interface for accessing various factories capable of creating value objects.
	 *
	 * @since 1.2.56
	 */
	@Deprecated
	ValueFactoryProvider getValueFactoryProvider();

	/**
	 * @deprecated Use {@link UserInterfaceAPI} instead accessible through both {@link #getInstallationAPIProvider()}
	 * and {@link #getProgramAPIProvider()}.
	 *
	 * @return an interface for various ways of interacting with the end user.
	 *
	 * @since 1.2.56
	 */
	@Deprecated
	UserInteraction getUserInteraction();

	/**
	 * This method can be used to get a specific {@link InstallationNodeContribution} instance.
	 *
	 * @deprecated Use {@link InstallationAPI} or {@link ProgramAPI} instead accessible through their respective providers.
	 *
	 * @param installationType The class of the installation node contribution to return.
	 * @param <T> The generic for specifying the {@link InstallationNodeContribution}.
	 * @return The installation node instance.
	 */
	@Deprecated
	<T extends InstallationNodeContribution> T getInstallationNode(Class<T> installationType);
}
