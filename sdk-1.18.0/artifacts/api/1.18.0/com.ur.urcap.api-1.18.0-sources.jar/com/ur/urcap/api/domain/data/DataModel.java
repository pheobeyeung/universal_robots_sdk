/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.data;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.device.Device;
import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.payload.Payload;
import com.ur.urcap.api.domain.tcp.TCP;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;
import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.Position;
import com.ur.urcap.api.domain.value.Rotation;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.Angle;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;
import com.ur.urcap.api.domain.value.simple.AngularSpeed;
import com.ur.urcap.api.domain.value.simple.Current;
import com.ur.urcap.api.domain.value.simple.Force;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.domain.value.simple.Pressure;
import com.ur.urcap.api.domain.value.simple.Speed;
import com.ur.urcap.api.domain.value.simple.Time;
import com.ur.urcap.api.domain.value.simple.Torque;
import com.ur.urcap.api.domain.value.simple.Voltage;
import com.ur.urcap.api.domain.variable.Variable;
import org.osgi.annotation.versioning.ProviderType;

import java.util.Set;


/**
 * <p>
 * This interface is used for storing and managing data that represents the current configuration of, e.g. a
 * {@link ProgramNodeContribution} or {@link InstallationNodeContribution}.
 * Methods for adding, removing, retrieving and changing values in a dictionary are provided.
 * </p>
 *
 * <p>
 * Setting a new value for a key already in use, will overwrite the current value with the new value. This happens
 * regardless of the type of value (e.g. storing the value {@code true} under the key <i>myBool</i> and afterwards storing
 * an {@code Angle} object under the same key will overwrite the value {@code true} with the provided {@code Angle} object).
 * Setting a {@code null} value for a key, will remove the key and its value, if it exists, from the data model.
 * </p>
 *
 * <p>
 * A URCap installation screen has an underlying {@code DataModel} object. That object is saved and loaded along with each
 * PolyScope installation.
 * </p>
 *
 * <p>
 * Similarly, each contributed program node instance has an underlying {@code DataModel} object. That object is saved and
 * loaded along with the program where the node occurs.
 * Undo/redo actions are supported for all modifications to the {@code DataModel} object in HTML-based program node contributions.
 * Swing-based URCaps must use the {@link UndoRedoManager} to record the changes on the undo/redo stack.
 * </p>
 *
 * <p>
 * When retrieving an object, both key and object type must match what was previously stored. This means that if a
 * {@code TCP} object was stored using the key <i>myAngle</i>, then attempting to retrieve it using
 * {@link #get(String key, Angle defaultValue)} with the key <i>myAngle</i> will not return the stored value, since the
 * types do not match. Instead the provided {@code defaultValue} will be returned.
 * </p>
 *
 * @since 1.0.0
 */
@ProviderType
public interface DataModel {

	/**
	 * Assign a {@code boolean} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, boolean value);

	/**
	 * Get the {@code boolean} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	boolean get(String key, boolean defaultValue);

	/**
	 * Assign an {@code int} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, int value);

	/**
	 * Get the {@code int} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	int get(String key, int defaultValue);

	/**
	 * Assign a {@code long} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, long value);

	/**
	 * Get the {@code long} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	long get(String key, long defaultValue);

	/**
	 * Assign a {@code float} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, float value);

	/**
	 * Get the {@code float} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	float get(String key, float defaultValue);

	/**
	 * Assign a {@code double} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, double value);

	/**
	 * Get the {@code double} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	double get(String key, double defaultValue);

	/**
	 * Assign a {@code String} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, String value);

	/**
	 * Get the {@code String} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	String get(String key, String defaultValue);

	/**
	 * Assign a {@code JointPositions} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, JointPositions value);

	/**
	 * Get the {@code JointPositions} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	JointPositions get(String key, JointPositions defaultValue);

	/**
	 * Assign a {@code Variable} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Variable value);

	/**
	 * Get the {@code Variable} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Variable get(String key, Variable defaultValue);

	/**
	 * Assign an {@code Acceleration} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Acceleration value);

	/**
	 * Get the {@code Acceleration} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Acceleration get(String key, Acceleration defaultValue);

	/**
	 * Assign an {@code Angle} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null}or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Angle value);

	/**
	 * Get the {@code Angle} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Angle get(String key, Angle defaultValue);

	/**
	 * Assign an {@code AngularAcceleration} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, AngularAcceleration value);

	/**
	 * Get the {@code AngularAcceleration} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	AngularAcceleration get(String key, AngularAcceleration defaultValue);

	/**
	 * Assign an {@code AngularSpeed} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, AngularSpeed value);

	/**
	 * Get the {@code AngularSpeed} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	AngularSpeed get(String key, AngularSpeed defaultValue);

	/**
	 * Assign a {@code Current} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Current value);

	/**
	 * Get the {@code Current} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Current get(String key, Current defaultValue);

	/**
	 * Assign a {@code Force} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Force value);

	/**
	 * Get the {@code Force} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Force get(String key, Force defaultValue);

	/**
	 * Assign a {@code Length} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Length value);

	/**
	 * Get the {@code Length} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Length get(String key, Length defaultValue);

	/**
	 * Assign a {@code Mass} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.13.0
	 */
	void set(String key, Mass value);

	/**
	 * Get the {@code Mass} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.13.0
	 */
	Mass get(String key, Mass defaultValue);

	/**
	 * Assign a {@code Pose} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Pose value);

	/**
	 * Get the {@code Pose} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Pose get(String key, Pose defaultValue);

	/**
	 * Assign a {@code Position} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Position value);

	/**
	 * Get the {@code Position} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Position get(String key, Position defaultValue);

	/**
	 * Assign a {@code Pressure} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.6.0
	 */
	void set(String key, Pressure value);

	/**
	 * Get the {@code Pressure} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.6.0
	 */
	Pressure get(String key, Pressure defaultValue);

	/**
	 * Assign a {@code Rotation} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Rotation value);

	/**
	 * Get the {@code Rotation} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Rotation get(String key, Rotation defaultValue);

	/**
	 * Assign a {@code Speed} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Speed value);

	/**
	 * Get the {@code Speed} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Speed get(String key, Speed defaultValue);

	/**
	 * Assign a {@code Time} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Time value);

	/**
	 * Get the {@code Time} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Time get(String key, Time defaultValue);

	/**
	 * Assign a {@code Torque} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Torque value);

	/**
	 * Get the {@code Torque} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Torque get(String key, Torque defaultValue);

	/**
	 * Assign a {@code Voltage} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	void set(String key, Voltage value);

	/**
	 * Get the {@code Voltage} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.2.56
	 */
	Voltage get(String key, Voltage defaultValue);

	/**
	 * Assign a {@code boolean[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, boolean[] value);

	/**
	 * Get the {@code boolean[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	boolean[] get(String key, boolean[] defaultValue);

	/**
	 * Assign a {@code int[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, int[] value);

	/**
	 * Get the {@code int[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	int[] get(String key, int[] defaultValue);

	/**
	 * Assign a {@code long[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, long[] value);

	/**
	 * Get the {@code long[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	long[] get(String key, long[] defaultValue);

	/**
	 * Assign a {@code float[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, float[] value);

	/**
	 * Get the {@code float[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	float[] get(String key, float[] defaultValue);

	/**
	 * Assign a {@code double[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, double[] value);

	/**
	 * Get the {@code double[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	double[] get(String key, double[] defaultValue);

	/**
	 * Assign a {@code String[]} as value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	void set(String key, String[] value);

	/**
	 * Get the {@code String[]} as value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 */
	String[] get(String key, String[] defaultValue);

	/**
	 *  Assign a {@code TCP} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.5.0
	 */
	void set(String key, TCP value);

	/**
	 * Get the {@code TCP} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.5.0
	 */
	TCP get(String key, TCP defaultValue);

	/**
	 *  Assign a {@code Feature} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.9.0
	 */
	void set(String key, Feature value);

	/**
	 * Get the {@code Feature} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.9.0
	 */
	Feature get(String key, Feature defaultValue);

	/**
	 *  Assign a {@code Payload} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.13.0
	 */
	void set(String key, Payload value);

	/**
	 * Get the {@code Payload} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @return the value assigned to the key. If not exist, defaultValue is returned.
	 *
	 * @since 1.13.0
	 */
	Payload get(String key, Payload defaultValue);

	/**
	 *  Assign a {@code Device} value to the specified key.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @param value value assigned to key.
	 *
	 * @throws IllegalArgumentException if the key is {@code null} or an empty {@code String}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.9.0
	 */
	void set(String key, Device value);

	/**
	 * Get the {@code Device} value assigned to the specified key.
	 *
	 * @param key key in the data model.
	 * @param defaultValue value to be returned, if key does not exist.
	 * @param deviceClassType device class type to be returned.
	 * @return the value assigned to the key. If not exist, defaultValue is returned..
	 *
	 * @since 1.9.0
	 */
	<T extends Device> T get(String key, T defaultValue, Class<T> deviceClassType);

	/**
	 * Get a set of all the keys in the data model.
	 *
	 * @return A Set of keys.
	 *
	 * @since 1.2.56
	 */
	Set<String> getKeys();

	/**
	 * Check if a key is present in the data model.
	 *
	 * @param key key in the data model (not {@code null} and not an empty {@code String}).
	 * @return {@code true}, if key exist, otherwise {@code false}.
	 */
	boolean isSet(String key);

	/**
	 * Remove a key-value pair from the data model.
	 *
	 * @param key key in the data model  (not {@code null} and not an empty {@code String}).
	 * @return {@code true}, if succeed, otherwise {@code false}.
	 * @throws IllegalStateException if called from a Swing-based URCap program node outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	boolean remove(String key);
}
