/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.device.gripper;

import com.ur.urcap.api.domain.URCapInfo;
import com.ur.urcap.api.domain.device.Device;
import com.ur.urcap.api.domain.device.gripper.capability.CapabilitySupport;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripActionConfigBuilder;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.ReleaseActionConfigBuilder;

import com.ur.urcap.api.util.Optional;

import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents a gripper device in PolyScope.
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperDevice extends Device {

	/**
	 * Get information about the URCap that added/contributed this gripper device to PolyScope.
	 *
	 * @return URCap information for this gripper device
	 */
	URCapInfo getContributorInfo();

	/**
	 * A device cannot be guaranteed to be present in PolyScope. A device will not be present if the URCap that added
	 * the device is not installed. This method can be used to determine, if the device is present.
	 *
	 * @return {@code true} if this gripper device is present in PolyScope, otherwise {@code false}.
	 */
	boolean isResolvable();

	/**
	 * <p>
	 * Get information about the support (provided by the gripper device) for a specific capability. This information
	 * can be used to configure the supported capability when creating a configuration for a Gripper node
	 * (a {@link GripperNode} instance) with the {@link GripActionConfigBuilder} or {@link ReleaseActionConfigBuilder}
	 * interface. The method can also be used just to check if the device supports a specific capability (for instance
	 * to determine how to configure the gripper device or to help decide which gripper device to select based on its
	 * capabilities).
	 * </p>
	 *
	 * <p>
	 * The various grippers available in Polyscope can support different sets of capabilities ranging from a very basic
	 * gripper, which does not provide any additional capabilities (besides basic simple grip and release actions), to a
	 * more advanced gripper supporting several capabilities. Therefore the returned capability support instance is
	 * wrapped in an {@link Optional}. Always use {@link Optional#isPresent()} to check if the specific gripper device
	 * supports the specified capability before accessing it using {@link Optional#get()}.
	 * </p>
	 *
	 * <p>
	 * <b>Code example:</b> <br>
	 * Here is an example of how to get the list of individual grippers available in a multi-gripper device. The returned
	 * list can be used to select a specific gripper when creating a {@link GripperNode} configuration.
	 *
	 * <pre>
	 * {@code
	 *   Optional<MultiGripperSupport> support = gripperDevice.getCapabilitySupport(MultiGripperSupport.class);
	 *   if (support.isPresent()) {
	 *      MultiGripperSupport multiGripperSupport = support.get();
	 *      List<SelectableGripper> selectableGrippers = multiGripperSupport.getSelectableGrippers();
	 *      ...
	 *   }
	 * }
	 * </pre>
	 * </p>
	 *
	 * @param <T> The type of the capability support (an interface extending the {@link CapabilitySupport} base interface)
	 *            to be returned
	 * @param capabilitySupport The class of the capability support instance to be returned, not {@code null}.
	 * @return An instance representing the supported capability wrapped in an {@link Optional}. This instance provides
	 * information relevant for configuring the capability. Note that this information is only applicable for this specific
	 * gripper device. Always use the {@link Optional#isPresent()} method on the returned instance to check if the
	 * capability is supported by the gripper device, prior to accessing the capability support
	 * (using {@link Optional#get()}).
	 *
	 * @since 1.11.0
	 */
	<T extends CapabilitySupport> Optional<T> getCapabilitySupport(Class<T> capabilitySupport);
}
