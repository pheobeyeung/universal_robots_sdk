/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.feature;

import com.ur.urcap.api.domain.value.Pose;


/**
 * <p>
 * This interface provides functionality for adding, updating and removing features in PolyScope.
 * </p>
 *
 * <b>Note:</b> This interface must only be used in an installation contribution.
 *
 * @since 1.9.0
 */
public interface FeatureContributionModel {

	/**
	 * <p>
	 * Add a feature to the current PolyScope installation.
	 * </p>
	 *
	 * This makes the feature selectable by the end user as well as available to other URCap contributions (through the 
	 * {@link FeatureModel} interface). The feature is not modifiable by the end user or other URCaps.
	 *
	 * @param idKey The key to identify this feature by, not {@code null} nor an empty string. The key is for this URCap
	 *              only, i.e. it only has to be unique for this URCap and not "globally" for other URCaps.
	 * @param suggestedName Suggested name for the feature, not {@code null} nor an empty string. Valid names must match
	 *                      regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a total of 15 characters. The final name can be retrieved
	 *                      from the returned feature instance.
	 * @param pose The pose of the feature with respect to the robot base, not {@code null}. 
	 * @return The feature created and registered in PolyScope.
	 * @throws FeatureAlreadyAddedException If a feature has previously been added using the same {@code idKey} identifier.
	 *                                  Use {@link #getFeature(String)} to check if the feature has already been added 
	 *                                  to the current installation.
	 *                                  Use {@link #updateFeature(String, Pose)} to update the feature.
	 * @throws IllegalFeatureNameException If the suggested name does not match required regex.
	 */
	Feature addFeature(String idKey, String suggestedName, Pose pose);

	/**
	 * Returns the feature previously added by this URCap using the same {@code idKey} identifier. Use this to verify if
	 * the feature is present in the current installation.
	 *
	 * @param idKey The key to identify this feature by, not {@code null} nor an empty string.
	 * @return The feature previously added by this URCap.
	 *         Returns {@code null} if no feature exists in the current installation (with the specified {@code idKey} 
	 *         identifier).
	 */
	Feature getFeature(String idKey);

	/**
	 * Update the pose of an existing feature added by this URCap.
	 *
	 * @param idKey The key to identify the feature, not {@code null} nor an empty string. A feature must have been added
	 *              using the same key prior to calling this method.
	 * @param newPose The new pose to set for the feature with respect to the robot base, not {@code null}.
	 * @throws FeatureNotFoundException If no feature exists with the provided {@code idKey} identifier in the current 
	 *         installation.
	 */
	void updateFeature(String idKey, Pose newPose);

	/**
	 * Remove a feature added by this URCap from PolyScope. Program nodes using the feature will be become undefined
	 * because the feature is no longer resolvable.
	 *
	 * @param idKey The identifier key used to add the feature with, not {@code null} nor an empty string.
	 * @throws FeatureNotFoundException If no feature exists with the provided {@code idKey} identifier in the current
	 *         installation.
	 */
	void removeFeature(String idKey);
}
