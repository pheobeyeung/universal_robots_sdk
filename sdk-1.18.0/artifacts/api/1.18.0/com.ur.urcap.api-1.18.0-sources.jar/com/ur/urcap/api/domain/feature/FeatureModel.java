/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.feature;

import com.ur.urcap.api.domain.util.Filter;

import java.util.Collection;


/**
 * Provides methods that returns features from the current robot installation.
 *
 * @since 1.0.0
 */
public interface FeatureModel {

	/**
	 * @return the geometric features of the current installation
	 */
	Collection<Feature> getGeomFeatures();

	/**
	 * @param clazz the sort of geometric feature of interest, e.g. {@code FeaturePoint.class},
	 *              {@code FeatureLine.class}, {@code FeaturePlane.class}
	 * @param <T> The Feature type
	 * @return the collection of the corresponding features
	 */
	<T extends Feature> Collection<T> getGeomFeatures(Class<T> clazz);

	/**
	 * @param filter a filter implementation
	 * @return the collection of geometric features that are accepted by the filter
	 */
	Collection<Feature> getGeomFeatures(Filter<Feature> filter);

	/**
	 * @return the base feature of the current installation.
	 *
	 * @since 1.2.56
	 */
	BaseFeature getBaseFeature();

	/**
	* @return the tool feature of the current installation.
	 */
	ToolFeature getToolFeature();
}
