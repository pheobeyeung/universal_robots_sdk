/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;


/**
 * This interface provides support for digital I/Os.
 *
 * @since 1.0.0
 */
public interface DigitalIO extends IO {

	/**
	 * Set digital I/O output signal. Note that the I/O must be an output I/O.
	 *
	 * @param high the digital value to be set.
	 * @return {@code true} if the digital signal was set, {@code false} if the signal was not set, e.g. because the
	 * controller was not running.
	 */
	boolean setValue(boolean high);

	/**
	 *
	 * @return Returns the last reading of the I/O.
	 */
	boolean getValue();

	/**
	 * Some digital I/Os, such as the digital tool outputs, are in some situations not available for use. This method can
	 * be used to determine, if the I/O is available.
	 *
	 * @return {@code true}, if digital I/O can be resolved.
	 *         {@code false} otherwise, e.g. because a tool output has been configured to Dual Pin Power.
	 *
	 *  @since 1.7.0
	 */
	boolean isResolvable();
}
