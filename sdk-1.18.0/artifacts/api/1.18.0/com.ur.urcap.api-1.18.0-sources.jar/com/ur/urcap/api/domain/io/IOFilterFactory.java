/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;

import com.ur.urcap.api.domain.io.IO.IOType;
import com.ur.urcap.api.domain.io.IO.InterfaceType;
import com.ur.urcap.api.domain.util.Filter;


/**
 *
 * API with predefined filters that be used when searching for particular sorts of I/Os.
 *
 * @since 1.0.0
 */
public class IOFilterFactory {

	/**
	 *
	 * @return a filter for digital input and outputs.
	 */
	public static Filter<IO> digitalFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.getType() == IOType.DIGITAL;
			}
		};
	}

	/**
	 *
	 * @return a filter for integer input and outputs.
	 */
	public static Filter<IO> integerFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.getType() == IOType.INTEGER;
			}
		};
	}


	/**
	 *
	 * @return a filter for analog input and outputs.
	 */
	public static Filter<IO> analogFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.getType() == IOType.ANALOG;
			}
		};
	}

	/**
	 *
	 * @return a filter for the robot tool I/Os.
	 */
	public static Filter<IO> toolFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.getInterfaceType() == InterfaceType.UR_TOOL;
			}

		};
	}

	/**
	 *
	 * @return a filter for MODBUS I/Os.
	 */
	public static Filter<IO> modbusFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.getInterfaceType() == InterfaceType.UR_MODBUS;
			}
		};
	}

	/**
	 *
	 * @return a filter for all types of inputs.
	 */
	public static Filter<IO> inputFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all types of outputs.
	 */
	public static Filter<IO> outputFilter() {
		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return !element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all digital inputs.
	 */
	public static Filter<IO> digitalInputFilter() {
		final Filter<IO> digitalFilter = digitalFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return digitalFilter.accept(element) && element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all digital outputs.
	 */
	public static Filter<IO> digitalOutputFilter() {
		final Filter<IO> digitalFilter = digitalFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return digitalFilter.accept(element) && !element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all analog inputs.
	 *
	 * @since 1.2.56
	 */
	public static Filter<IO> analogInputFilter() {
		final Filter<IO> analogFilter = analogFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return analogFilter.accept(element) && element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all analog outputs.
	 *
	 * @since 1.2.56
	 */
	public static Filter<IO> analogOutputFilter() {
		final Filter<IO> analogFilter = analogFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return analogFilter.accept(element) && !element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all integer inputs.
	 */
	public static Filter<IO> integerInputFilter() {
		final Filter<IO> integerFilter = integerFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return integerFilter.accept(element) && element.isInput();
			}
		};
	}

	/**
	 *
	 * @return a filter for all integer outputs.
	 */
	public static Filter<IO> integerOutputFilter() {
		final Filter<IO> integerFilter = integerFilter();

		return new Filter<IO>() {
			@Override
			public boolean accept(IO element) {
				return integerFilter.accept(element) && !element.isInput();
			}
		};
	}
}
