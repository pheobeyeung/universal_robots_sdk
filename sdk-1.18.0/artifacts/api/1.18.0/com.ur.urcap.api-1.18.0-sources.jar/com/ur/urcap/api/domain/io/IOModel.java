/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.io;

import com.ur.urcap.api.domain.util.Filter;

import java.util.Collection;


/**
 * Provides methods that returns I/Os from the current robot installation.
 *
 * @since 1.0.0
 */
public interface IOModel {

	/**
	 *
	 * @return the collection of available I/Os, including Modbus, EuroMap67 and named General Purpose Registers.
	 */
	Collection<IO> getIOs();

	/**
	 *
	 * @param clazz the sort of I/O of interest, e.g. {@code AnalogIO.class}, {@code DigitalIO.class}, or
	 * {@code ModbusIO.class}.
	 * @param <T> The I/O type.
	 * @return the collection of the corresponding I/Os.
	 */
	<T extends IO> Collection<T> getIOs(Class<T> clazz);

	/**
	 *
	 * @param filter a filter, see {@link IOFilterFactory} for examples.
	 * @return the collection of IOs that are accepted by the filter.
	 */
	Collection<IO> getIOs(Filter<IO> filter);

}
