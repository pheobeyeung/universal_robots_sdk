/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes;

import com.ur.urcap.api.contribution.URCapProgramNodeService;
import com.ur.urcap.api.domain.program.nodes.builtin.AssignmentNode;
import com.ur.urcap.api.domain.program.nodes.builtin.CircleMoveNode;
import com.ur.urcap.api.domain.program.nodes.builtin.CommentNode;
import com.ur.urcap.api.domain.program.nodes.builtin.DirectionNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ElseIfNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ElseNode;
import com.ur.urcap.api.domain.program.nodes.builtin.FolderNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ForceNode;
import com.ur.urcap.api.domain.program.nodes.builtin.HaltNode;
import com.ur.urcap.api.domain.program.nodes.builtin.HomeNode;
import com.ur.urcap.api.domain.program.nodes.builtin.IfNode;
import com.ur.urcap.api.domain.program.nodes.builtin.IllegalWaypointNameException;
import com.ur.urcap.api.domain.program.nodes.builtin.LoopNode;
import com.ur.urcap.api.domain.program.nodes.builtin.MoveNode;
import com.ur.urcap.api.domain.program.nodes.builtin.PalletNode;
import com.ur.urcap.api.domain.program.nodes.builtin.PopupNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ScrewdrivingNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SeekNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SetNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SetPayloadNode;
import com.ur.urcap.api.domain.program.nodes.builtin.UntilNode;
import com.ur.urcap.api.domain.program.nodes.builtin.WaitNode;
import com.ur.urcap.api.domain.program.nodes.builtin.WaypointNode;
import com.ur.urcap.api.domain.program.nodes.contributable.URCapProgramNode;
import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.CapabilityNotSupportedException;
import com.ur.urcap.api.domain.system.capability.programnodefactory.ProgramNodeCapability;
import com.ur.urcap.api.domain.system.capability.programnodefactory.annotation.RequiredCapability;
import org.osgi.annotation.versioning.ProviderType;

import static com.ur.urcap.api.domain.system.capability.programnodefactory.ProgramNodeCapability.SCREWDRIVING;

/**
 * <p>
 * This interfaces supplies methods to create different types of program nodes.
 * </p>
 *
 * <p>
 * Both built-in program nodes (provided by Universal Robots) and URCap program nodes can be created. Most methods will
 * create a node with the same default configuration as if the end user added the node manually.
 * </p>
 *
 * Note: The default configuration may change between PolyScope versions.
 *
 * @since 1.1.0
 */
@ProviderType
public interface ProgramNodeFactory {

	/**
	 * This method creates a URCap program node which is an instance of a {@link com.ur.urcap.api.contribution.ProgramNodeContribution}.
	 *
	 * @param urcapProgramNodeService is the service creating the program node contribution.
	 *
	 * @return the {@link URCapProgramNode} which represents the {@link com.ur.urcap.api.contribution.ProgramNodeContribution}
	 * created by {@link URCapProgramNodeService}. Returns {@code null} if URCap providing urcapProgramNodeService is
	 * not installed.
	 *
	 * @throws IllegalArgumentException if the argument urcapProgramNodeService is {@code null}or urcapProgramNodeService
	 * does not implement {@link URCapProgramNodeService}.
	 */
	URCapProgramNode createURCapProgramNode(Class<? extends URCapProgramNodeService> urcapProgramNodeService);


	//Basic nodes

	/**
	 * Creates a default Move node with one default Waypoint node under it.
	 *
	 *  @return A new Move Node.
	 */
	MoveNode createMoveNode();

	/**
	 * <p>
	 * Creates a default Move node without a Waypoint node under it. This can, for instance, be used to create a Move
	 * node with waypoints with custom names under it (created using {@link #createWaypointNode(String)}).
	 * </p>
	 *
	 * <b>NOTE:</b> At least one Waypoint node must be under a Move node for it to be valid.
	 *
	 * @return A new Move Node.
	 *
	 * @since 1.4.0
	 */
	MoveNode createMoveNodeNoTemplate();

	/**
	 * @since 1.2.56
	 */
	CircleMoveNode createCircleMoveNode();

	/**
	 * Creates a default Waypoint node with default waypoint name (corresponds to the name generated if the end user
	 * added a new node manually).
	 *
	 * @return A new Waypoint Node.
	 *
	 */
	WaypointNode createWaypointNode();

	/**
	 * <p>
	 * Creates a default Waypoint node with a suggested custom name.
	 * </p>
	 *
	 * <p>
	 * The final waypoint name can be different if the specified suggested name is already registered. The waypoint name
	 * is registered when the Waypoint node is inserted into the program tree.
	 * </p>
	 *
	 * Variable waypoints will use the name of the selected variable instead of the suggested name.
	 *
	 * @param suggestedName The suggested name for the waypoint. Valid names must match regex [a-zA-Z][a-zA-Z0-9_]{0,14}
	 *                      for a total of 15 characters.
	 * @return A new Waypoint Node.
	 * @throws IllegalWaypointNameException If the suggested name does not match required regex.
	 *
	 * @since 1.4.0
	 */
	WaypointNode createWaypointNode(String suggestedName);

	/**
	 * Creates a default Until Node where the type of the until stop condition is not specified.
	 *
	 * @return A new Until Node.
	 *
	 * @since 1.6.0
	 */
	UntilNode createUntilNode();

	/**
	 * @since 1.6.0
	 */
	DirectionNode createDirectionNode();

	WaitNode createWaitNode();

	SetNode createSetNode();

	PopupNode createPopupNode();

	HaltNode createHaltNode();

	CommentNode createCommentNode();

	FolderNode createFolderNode();

	/**
	 * Creates a default Set Payload Node where the default payload (defined in the installation) is selected.
	 *
	 * @return A new Set Payload node.
	 *
	 * @since 1.13.0
	 */
	SetPayloadNode createSetPayloadNode();

	//Advanced nodes

	LoopNode createLoopNode();

	AssignmentNode createAssignmentNode();

	IfNode createIfNode();

	ElseIfNode createElseIfNode();

	ElseNode createElseNode();

	/**
	 * Creates a default Home Node.
	 *
	 * @since 1.13.0
	 */
	HomeNode createHomeNode();

	//Wizard nodes

	PalletNode createPalletNode();

	SeekNode createSeekNode();

	ForceNode createForceNode();

	/**
	 * Creates a Screwdriving node. This type of node is used for programming screwing operations with a screwdriver
	 * device.
	 *
	 * @return A new Screwdriving node.
	 * @throws CapabilityNotSupportedException If the Screwdriving capability is not available. Use
	 *                                         {@link CapabilityManager#hasCapability(Capability)} with
	 *                                         {@link ProgramNodeCapability#SCREWDRIVING} as argument to verify
	 *                                         availability.
	 *
	 * @since 1.8.0
	 */
	@RequiredCapability(SCREWDRIVING)
	ScrewdrivingNode createScrewdrivingNode();
}

