/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.directionnode.DirectionNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.directionnode.DirectionNodeConfigBuilder;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;

/**
 * @since 1.6.0
 */
public interface DirectionNode extends ProgramNode {

	/**
	 * Creates a new {@link DirectionNodeConfigBuilder} instance for building a single Direction node configuration. Each
	 * configuration being built should ideally use a new {@link DirectionNodeConfigBuilder} instance.
	 *
	 * @return the builder for creating a single configuration for a Direction node.
	 */
	DirectionNodeConfigBuilder createConfigBuilder();

	/**
	 *
	 * @return The current configuration for this node.
	 */
	DirectionNodeConfig getConfig();

	/**
	 * Set a configuration on this node.
	 *
	 * @param config the configuration to be set.
	 * @return this node.
	 * @throws IllegalStateException If called from a Swing-based URCap outside of an {@link UndoableChanges} scope
	 *                               (see also {@link UndoRedoManager}).
	 */
	DirectionNode setConfig(DirectionNodeConfig config);
}
