/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface represents a Folder program node. The Folder node is a built-in program node provided by Universal
 * Robots.
 * </p>
 *
 * The purpose of this program node is to contain other program node (as children) in order thereby to organize and label
 * specific parts of a program, to clean up the program tree, and to make the program easier to read and navigate.
 *
 * @since 1.1.0
 */
@ProviderType
public interface FolderNode extends ProgramNode {

	/**
	 * Sets the name of the Folder node.
	 *
	 * @param name The name of the folder.
	 * @return This node.
	 * @throws IllegalStateException If called from a Swing-based URCap outside of an {@link UndoableChanges} scope (see
	 *         also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	FolderNode setName(String name);

	/**
	 * @return The name of the Folder node.
	 *
	 * @since 1.2.56
	 */
	String getName();

	/**
	 * Configure whether or not the subtree of the Folder node is hidden, i.e.  whether or not the child nodes under the
	 * Folder node are visible in the Program Tree in PolyScope.
	 *
	 * @param subtreeHidden {@code true}, if the Folder node's subtree should be hidden in the Program Tree.
	 *                      {@code false} if the subtree should be visible.
	 *
	 * @return This node.
	 * @throws IllegalStateException If called from a Swing-based URCap outside of an {@link UndoableChanges} scope (see
	 *                               also {@link UndoRedoManager}).
	 *
	 * @since 1.12.0
	 */
	FolderNode setSubtreeHidden(boolean subtreeHidden);

	/**
	 * Indicates whether the Folder node's subtree is hidden in the Program Tree in PolyScope, i.e.  whether the child
	 * nodes under the Folder node are not visible.
	 *
	 * @return {@code true} if the Folder node's subtree is hidden, and {@code false} if the subtree is visible in the
	 *         Program Tree in PolyScope.
	 *
	 * @since 1.12.0
	 */
	boolean isSubtreeHidden();
}
