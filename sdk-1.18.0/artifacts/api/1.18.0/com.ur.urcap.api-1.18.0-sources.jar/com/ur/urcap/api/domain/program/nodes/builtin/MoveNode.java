/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.MoveNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.MoveNodeConfigFactory;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelectionFactory;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.builder.MoveNodeConfigBuilders;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;

/**
 * @since 1.1.0
 */
public interface MoveNode extends ProgramNode {
	/**
	 * @deprecated Use {@link #getConfigBuilders()} instead.
	 *
	 * @return This method returns a factory for creating various configurations for this node.
	 *
	 * @since 1.2.56
	 */
	@Deprecated
	MoveNodeConfigFactory getConfigFactory();

	/**
	 * Set a configuration on this node.
	 *
	 * @param config the configuration to be set.
	 * @return This node.
	 * @throws IllegalArgumentException if this node is a MoveP containing one or more {@link CircleMoveNode} and the node
	 * configuration is attempted to be changed to MoveJ or MoveL. {@link CircleMoveNode} is only allowed under a MoveP.
	 * All instances of {@link CircleMoveNode} need to be deleted before the configuration can be changed from a MoveP to
	 * MoveJ or MoveL.
	 * @throws IllegalArgumentException if this node is a MoveL or MoveP containing one or more {@link DirectionNode} and
	 * the node configuration is attempted to be changed to a MoveJ.
	 * {@link DirectionNode} is only allowed under a MoveL or MoveP. All instances of {@link DirectionNode} need to be
	 * deleted before the configuration can be changed from a MoveL or MoveP to a MoveJ.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	MoveNode setConfig(MoveNodeConfig config);

	/**
	 *
	 * @return The current configuration for this node.
	 *
	 * @since 1.2.56
	 */
	MoveNodeConfig getConfig();

	/**
	 * This method returns a {@link MoveNodeConfigBuilders} to build configurations for this node type.
	 *
	 * @return the builders to build configurations.
	 *
	 * @since 1.6.0
	 */
	MoveNodeConfigBuilders getConfigBuilders();

	/**
	 * This method returns a {@link TCPSelectionFactory} to create a TCP selection.
	 *
	 * @return The factory for creating TCP selections for Move node configurations.
	 *
	 * @since 1.6.0
	 */
	TCPSelectionFactory getTCPSelectionFactory();
}
