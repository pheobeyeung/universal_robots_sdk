/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.builtin.configurations.waypointnode.WaypointNodeConfig;


/**
 * <p>
 * This exception is thrown, if it is not possible to compute joint positions corresponding to the specified target pose
 * (inverse kinematics failed to find solution), when applying a Waypoint node configuration.
 * </p>
 *
 * See {@link WaypointNode#setConfig(WaypointNodeConfig)}.
 *
 * @since 1.11.0
 */
public class UnreachablePositionException extends IllegalArgumentException {
	public UnreachablePositionException(String message) {
		super(message);
	}
}
