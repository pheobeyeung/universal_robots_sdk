/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode.UntilNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode.UntilNodeConfigFactory;
import com.ur.urcap.api.domain.program.structure.TreeNode;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;


/**
 * <p>
 * The Until node is a type of program node that must be under a Waypoint node or Direction node.
 * </p>
 *
 * <p>
 * It has special behavior when calling {@link TreeNode#addChild(ProgramNode)} and {@link TreeNode#removeChild(TreeNode)}.
 * Until nodes by default are leaf nodes, however they can have actions added to them. When that happens they are
 * transformed into branch nodes that allow child nodes. When the last child is removed they become leaf nodes again.
 * This is all automatically handled when {@link TreeNode#addChild(ProgramNode)} and {@link TreeNode#removeChild(TreeNode)}
 * are called.
 * </p>
 *
 * @since 1.6.0
 */
public interface UntilNode extends ProgramNode {

	/**
	 *
	 * @return This method returns a factory for creating various configurations for this type of node.
	 */
	UntilNodeConfigFactory getConfigFactory();

	/**
	 * Set a configuration on this node.
	 *
	 * @param config the configuration to be set.
	 * @return this node.
	 * @throws IllegalArgumentException If the Until node is placed under an invalid parent node
	 * e.g. trying to added a Until Distance node under a Waypoint node instead of a Direction node.
	 * @throws InvalidDomainException if applying an I/O Input configuration with a Voltage threshold value when the
	 * selected analog input is using the Current electrical domain or vice versa.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges} scope
	 * (see also {@link UndoRedoManager}).
	 */
	UntilNode setConfig(UntilNodeConfig config);

	/**
	 *
	 * @return the current configuration for this node.
	 */
	UntilNodeConfig getConfig();
}
