/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin;

import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.waitnode.WaitNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.waitnode.WaitNodeConfigFactory;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;

/**
 * @since 1.1.0
 */
public interface WaitNode extends ProgramNode {

	/**
	 *
	 * @return This method returns a factory for creating various configurations for this node.
	 *
	 * @since 1.2.56
	 */
	WaitNodeConfigFactory getConfigFactory();

	/**
	 * Set a configuration on this node.
	 *
	 * @param config the configuration to be set.
	 * @return this node.
	 * @throws InvalidDomainException if config is analog input using voltage and the IO is configured to current
	 * or vice versa.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 *
	 * @since 1.2.56
	 */
	WaitNode setConfig(WaitNodeConfig config);

	/**
	 *
	 * @return the current configuration for this node.
	 *
	 * @since 1.2.56
	 */
	WaitNodeConfig getConfig();
}
