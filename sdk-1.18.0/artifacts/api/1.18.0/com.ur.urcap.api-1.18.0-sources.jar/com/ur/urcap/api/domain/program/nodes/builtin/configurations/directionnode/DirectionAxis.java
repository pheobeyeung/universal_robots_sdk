/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.directionnode;

/**
 * @since 1.6.0
 */
public interface DirectionAxis extends DirectionSelection {

	enum Axis {
		/**
		 * Move in the positive X direction relative to the feature.
		 */
		X_PLUS,

		/**
		 * Move in the negative X direction relative to the feature.
		 */
		X_MINUS,

		/**
		 * Move in the positive Y direction relative to the feature.
		 */
		Y_PLUS,

		/**
		 * Move in the negative Y direction relative to the feature.
		 */
		Y_MINUS,

		/**
		 * Move in the positive Z direction relative to the feature.
		 */
		Z_PLUS,

		/**
		 * Move in the negative Z direction relative to the feature.
		 */
		Z_MINUS
	}

	/**
	 * @return the Axis used to define the direction.
	 */
	Axis getAxis();
}
