/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.forcenode;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.simple.Angle;
import com.ur.urcap.api.domain.value.simple.AngularSpeed;
import com.ur.urcap.api.domain.value.simple.Force;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Speed;
import com.ur.urcap.api.domain.value.simple.Torque;

/**
 * @since 1.2.56
 */
public interface ForceNodeConfigFactory {
	/**
	 * Creates a linear force setting for a compliant axis.
	 *
	 * @param limit The maximum speed the robot arm is allowed to move along the axis, not {@code null}.
	 * @param limitErrorHandler The error handler for the limit value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid speed value.
	 * @param force The force the robot arm will exert, not {@code null}.
	 * @param forceErrorHandler The error handler for the force value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid force value.
	 * @return A linear force settings for a compliant axis.
	 */
	CompliantLinearAxisForce createCompliantLinearAxisForce(Force force,
	                                                        ErrorHandler<Force> forceErrorHandler,
	                                                        Speed limit,
	                                                        ErrorHandler<Speed> limitErrorHandler);

	/**
	 * Creates a linear deviation limit setting for a non-compliant axis.
	 *
	 * @param limit The maximum distance the robot arm is allowed to deviate from the path, not {@code null}.
	 * @param limitErrorHandler The error handler for the limit value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid distance value.
	 * @return A linear deviation limit setting for a non-compliant axis, not {@code null}.
	 */
	NonCompliantLinearAxisLimit createNonCompliantLinearAxisLimit(Length limit, ErrorHandler<Length> limitErrorHandler);

	/**
	 * Creates a torque (rotational force) setting for a compliant axis.
	 *
	 * @param limit The maximum angular speed the robot arm is allowed to move, not {@code null}.
	 * @param limitErrorHandler The error handler for the limit value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid angular speed value.
	 * @param torque The torque (rotational force) the robot arm will exert, not {@code null}.
	 * @param torqueErrorHandler The error handler for the torque value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid torque value.
	 * @return A torque (rotational force) setting for a compliant axis.
	 */
	CompliantRotationalAxisTorque createCompliantRotationalAxisTorque(Torque torque,
	                                                                  ErrorHandler<Torque> torqueErrorHandler,
	                                                                  AngularSpeed limit,
	                                                                  ErrorHandler<AngularSpeed> limitErrorHandler);

	/**
	 * Creates a maximum rotational deviation limit setting for a non-compliant axis.
	 *
	 * @param limit The maximum angle the robot arm is allowed to deviate from the path, not {@code null}.
	 * @param limitErrorHandler The error handler for the limit value. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will clamp the value to the nearest valid angle value.
	 * @return A maximum rotational deviation limit setting for a non-compliant axis.
	 */
	NonCompliantRotationalAxisLimit createNonCompliantRotationalAxisLimit(Angle limit, ErrorHandler<Angle> limitErrorHandler);

	/**
	 * Creates a Frame configuration type for the Force node. This consists of settings for all six degrees of freedom as well
	 * as a feature.
	 *
	 * @param feature The feature defining the coordinate system (axes) that will be used in force mode, not {@code null}.
	 * @param x The compliant force or non-compliant maximum linear deviation setting for the x-axis, not {@code null}.
	 * @param y The compliant force or non-compliant maximum linear deviation setting for the y-axis, not {@code null}.
	 * @param z The compliant force or non-compliant maximum linear deviation setting for the z-axis, not {@code null}.
	 * @param rx The compliant torque (rotational force) or non-compliant maximum rotational deviation setting for the
	 *           x-axis (Rx rotation), not {@code null}.
	 * @param ry The compliant torque (rotational force) or non-compliant maximum rotational deviation setting for the
	 *           y-axis (Ry rotation), not {@code null}.
	 * @param rz The compliant torque (rotational force) or non-compliant maximum rotational deviation setting for the
	 *           z-axis (Rz rotation), not {@code null}.
	 * @return the configuration.
	 */
	FrameForceNodeConfig createFrameForceConfig(Feature feature,
	                                            LinearAxisSettings x,
	                                            LinearAxisSettings y,
	                                            LinearAxisSettings z,
	                                            RotationalAxisSettings rx,
	                                            RotationalAxisSettings ry,
	                                            RotationalAxisSettings rz);
}
