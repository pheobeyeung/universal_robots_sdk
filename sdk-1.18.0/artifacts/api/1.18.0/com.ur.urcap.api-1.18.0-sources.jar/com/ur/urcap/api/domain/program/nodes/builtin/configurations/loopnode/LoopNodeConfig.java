/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.loopnode;

/**
 * @since 1.2.56
 */
public interface LoopNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * <p>
		 * Looping infinitely has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AlwaysLoopNodeConfig}
		 */
		ALWAYS,

		/**
		 * <p>
		 * Looping a certain number of times has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link CounterLoopNodeConfig}
		 */
		COUNTER,

		/**
		 * <p>
		 * Looping as long as the evaluation of an expression is true has been selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link ExpressionLoopNodeConfig}
		 */
		EXPRESSION
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return the type of this config.
	 */
	ConfigType getConfigType();
}