/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode;

import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.optimove.OptiMoveMoveNodeConfig;

/**
 * @since 1.2.56
 */
public interface MoveNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {
		/**
		 * <p>
		 * Movement type is OptiMove.
		 * </p>
		 *
		 * The config instance can be cast to {@link OptiMoveMoveNodeConfig}.
		 *
		 * @since 1.17.0
		 */
		OPTI_MOVE,

		/**
		 * <p>
		 * Movement type is MoveJ.
		 * </p>
		 *
		 * The config instance can be cast to {@link MoveJMoveNodeConfig}.
		 */
		MOVE_J,

		/**
		 * <p>
		 * Movement type is MoveL.
		 * </p>
		 *
		 * The config instance can be cast to {@link MoveLMoveNodeConfig}.
		 */
		MOVE_L,

		/**
		 * <p>
		 * Movement type is MoveP.
		 * </p>
		 *
		 * The config instance can be cast to {@link MovePMoveNodeConfig}.
		 */
		MOVE_P
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return the type of this config.
	 */
	ConfigType getConfigType();
}
