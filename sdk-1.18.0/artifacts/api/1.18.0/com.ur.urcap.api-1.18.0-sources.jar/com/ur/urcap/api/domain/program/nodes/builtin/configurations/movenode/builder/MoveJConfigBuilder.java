/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.builder;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.MoveJMoveNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelection;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelectionFactory;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;
import com.ur.urcap.api.domain.value.simple.AngularSpeed;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface can be used to build a single MoveJ configuration that can be applied to a Move node. Each configuration
 * to be built should ideally use a new {@link MoveJConfigBuilder} instance.
 * </p>
 *
 * <p>
 * For any configuration parameter where a value is not specified (using the corresponding set method), a default value
 * will be used when the new configuration is built whereas the original value will be used when an existing configuration
 * was copied using the {@link #copyFrom(MoveJMoveNodeConfig)} method.
 * </p>
 *
 * <p>
 * To build a configuration with non-default values for the TCP selection and joint speed parameter, use the following
 * code snippet:
 * </p>
 *
 * <pre>
 * {@code
 * MoveJMoveNodeConfig newConfig = configBuilder.setTCPSelection(tcpSelection)
 *                                              .setJointSpeed(jointSpeed, ErrorHandler.AUTO_CORRECT)
 *                                              .build();
 * }
 * </pre>
 *
 * To change the value of the joint acceleration in the current configuration, use the following code snippet to build
 * a new updated configuration:
 *
 * <pre>
 * {@code
 *  configBuilder.copyFrom(currentConfig);
 *  MoveJMoveNodeConfig updatedConfig = configBuilder.setJointAcceleration(newJointAcceleration)
 *                                                   .build();
 * }
 * </pre>
 *
 * @since 1.6.0
 */
@ProviderType
public interface MoveJConfigBuilder {

	/**
	 * Copy configuration parameter values from one configuration (source) to another (this) builder
	 *
	 * @param source The original configuration to copy parameter values from.
	 * @return This builder.
	 */
	MoveJConfigBuilder copyFrom(MoveJMoveNodeConfig source);

	/**
	 * <p>
	 * Set joint speed parameter for the MoveJ configuration.
	 * </p>
	 *
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 *
	 * @param jointSpeed The shared joint speed to be achieved, not {@code null}.
	 * @param jointSpeedErrorHandler Error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT},
	 *                     this will clamp the value to the nearest valid joint speed value.
	 * @return This builder.
	 */
	MoveJConfigBuilder setJointSpeed(AngularSpeed jointSpeed, ErrorHandler<AngularSpeed> jointSpeedErrorHandler);

	/**
	 * <p>
	 * Set joint acceleration parameter for the MoveJ configuration.
	 * </p>
	 *
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 *
	 * @param jointAcceleration The shared joint acceleration to be used, not {@code null}.
	 * @param jointAccelerationErrorHandler Error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT},
	 *                     this will clamp the value to the nearest valid joint acceleration value.
	 * @return This builder.
	 */
	MoveJConfigBuilder setJointAcceleration(AngularAcceleration jointAcceleration, ErrorHandler<AngularAcceleration> jointAccelerationErrorHandler);

	/**
	 * <p>
	 * Set feature for the MoveJ configuration.
	 * </p>
	 *
	 * The feature will be used for the movement of the robot arm, from the previous position through the waypoints
	 * under the Move node.
	 *
	 * @param feature The shared feature for this movement, not {@code null}.
	 * @return This builder.
	 *
	 * @since 1.13.0
	 */
	MoveJConfigBuilder setFeature(Feature feature);

	/**
	 * <p>
	 * Set the TCP selection for the MoveJ configuration.
	 * </p>
	 *
	 * <p>
	 * The TCP will be set as the active TCP before the movement of the robot arm, from the previous position through the
	 * waypoints under the Move node, is performed.
	 * </p>
	 *
	 * See {@link TCPSelection} which can be created using the {@link TCPSelectionFactory} interface.
	 *
	 * @param tcpSelection The TCP setting to be applied.
	 * @return This builder.
	 */
	MoveJConfigBuilder setTCPSelection(TCPSelection tcpSelection);

	/**
	 * <p>
	 * Build the MoveJ configuration for the Move node.
	 * </p>
	 *
	 * A default configuration can be built by calling this method without invoking any of the set methods in this
	 * interface.
	 *
	 * @return The new MoveJ configuration.
	 */
	MoveJMoveNodeConfig build();
}
