/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.builder;

import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.optimove.builder.OptiMoveConfigBuilder;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides access to a set of builders which can be used to create Move node configurations
 * for all the different supported move types.
 *
 * @since 1.6.0
 */
@ProviderType
public interface MoveNodeConfigBuilders {

	/**
	 * Creates a new {@link MoveJConfigBuilder} instance for building a single MoveJ configuration. Each configuration
	 * being built should ideally use a new {@link MoveJConfigBuilder} instance.
	 *
	 * @return The builder to build a single MoveJ configuration
	 */
	MoveJConfigBuilder createMoveJConfigBuilder();

	/**
	 * Creates a new {@link MoveLConfigBuilder} instance for building a single MoveL configuration. Each configuration
	 * being built should ideally use a new {@link MoveLConfigBuilder} instance.
	 *
	 * @return The builder to build a single MoveL configuration
	 */
	MoveLConfigBuilder createMoveLConfigBuilder();

	/**
	 * Creates a new {@link MovePConfigBuilder} instance for building a single MoveP configuration. Each configuration
	 * being built should ideally use a new {@link MovePConfigBuilder} instance.
	 *
	 * @return The builder to build a single MoveP configuration
	 */
	MovePConfigBuilder createMovePConfigBuilder();

	/**
	 * Creates a new {@link OptiMoveConfigBuilder} instance for constructing a single OptiMove configuration for a MoveL
	 * or MoveJ node. Each configuration being built should ideally use a new {@link OptiMoveConfigBuilder} instance.
	 *
	 * @return The builder to construct a single OptiMove configuration
	 *
	 * @since 1.17.0
	 */
	OptiMoveConfigBuilder createOptiMoveConfigBuilder();
}
