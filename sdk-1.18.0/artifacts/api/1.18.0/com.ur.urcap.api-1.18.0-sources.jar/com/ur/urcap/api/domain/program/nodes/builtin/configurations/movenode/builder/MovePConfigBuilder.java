/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.builder;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.MovePMoveNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelection;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelectionFactory;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.blend.Blend;
import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.Speed;


/**
 * <p>
 * This interface can be used to build a single MoveP configuration that can be applied to a Move node. Each configuration
 * to be built should ideally use a new {@link MovePConfigBuilder} instance.
 * </p>
 *
 * <p>
 * For any configuration parameter where a value is not specified (using the corresponding set method), a default value
 * will be used when the new configuration is built whereas the original value will be used when an existing configuration
 * was copied using {@link #copyFrom(MovePMoveNodeConfig)}.
 * </p>
 *
 * <p>
 * To build a configuration with non-default values for the TCP selection and tool speed parameter, use the following
 * code snippet:
 * </p>
 *
 * <pre>
 * {@code
 * MovePMoveNodeConfig config = configBuilder.setTCPSelection(tcpSelection)
 *                                           .setToolSpeed(toolSpeed, ErrorHandler.AUTO_CORRECT)
 *                                           .build();
 * }
 * </pre>
 *
 * To change the value of the blend parameter in the current configuration, use the following code snippet to build
 * a new updated configuration:
 * <pre>
 * {@code
 *  configBuilder.copyFrom(currentConfig);
 *  MovePMoveNodeConfig newConfig = configBuilder.setBlend(blend, ErrorHandler.AUTO_CORRECT)
 *                                               .build();
 * }
 * </pre>
 *
 * @since 1.6.0
 */
public interface MovePConfigBuilder {

	/**
	 * Copy configuration parameter values from one configuration (source) to another (this) builder
	 *
	 * @param source The original configuration to copy parameter values from.
	 * @return This builder.
	 */
	MovePConfigBuilder copyFrom(MovePMoveNodeConfig source);

	/**
	 * <p>
	 * Set tool speed parameter for the MoveP configuration.
	 * </p>
	 *
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 *
	 * @param toolSpeed The shared tool speed to be achieved, not {@code null}.
	 * @param toolSpeedErrorHandler Error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT},
	 *                     this will clamp the value to the nearest valid tool speed value.
	 * @return This builder.
	 */
	MovePConfigBuilder setToolSpeed(Speed toolSpeed, ErrorHandler<Speed> toolSpeedErrorHandler);

	/**
	 * <p>
	 * Set tool acceleration parameter for the MoveP configuration.
	 * </p>
	 *
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 *
	 * @param toolAcceleration The shared tool acceleration to be used, not {@code null}.
	 * @param toolAccelerationErrorHandler Error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT},
	 *                                     this will clamp the value to the nearest valid tool acceleration value.
	 * @return This builder.
	 */
	MovePConfigBuilder setToolAcceleration(Acceleration toolAcceleration, ErrorHandler<Acceleration> toolAccelerationErrorHandler);

	/**
	 * <p>
	 * Set the blend parameter for the MoveP configuration.
	 * </p>
	 *
	 * The blend parameter will be used between all waypoints in the movement of the robot arm, from the previous
	 * position through the waypoint under the Move node.
	 *
	 * @param blend The shared blend used in the motion of this Move node, not {@code null}.
	 * @param blendErrorHandler Error handler for handling validation. If using {@link ErrorHandler#AUTO_CORRECT},
	 *                     this will clamp the value to the nearest valid blend value.
	 * @return This builder.
	 */
	MovePConfigBuilder setBlend(Blend blend, ErrorHandler<Blend> blendErrorHandler);

	/**
	 * <p>
	 * Set feature for the MoveP configuration.
	 * </p>
	 *
	 * The feature will be used for the movement of the robot arm, from the previous position through the waypoints
	 * under the Move node.
	 *
	 * @param feature The shared feature for this movement, not {@code null}.
	 * @return This builder.
	 */
	MovePConfigBuilder setFeature(Feature feature);

	/**
	 * <p>
	 * Set the TCP selection for the MoveP configuration.
	 * </p>
	 *
	 * <p>
	 * The TCP will be set as the active TCP before the movement of the robot arm, from the previous position through the
	 * waypoints under the Move node, is performed.
	 * </p>
	 *
	 * See {@link TCPSelection} which can be created using the {@link TCPSelectionFactory} interface.
	 *
	 * @param tcpSelection The TCP setting to be applied.
	 * @return This builder.
	 */
	MovePConfigBuilder setTCPSelection(TCPSelection tcpSelection);

	/**
	 * <p>
	 * Build the MoveP configuration for the Move node.
	 * </p>
	 *
	 * A default configuration can be built by calling this method without invoking any of the set methods in this
	 * interface.
	 *
	 * @return The new MoveP configuration.
	 */
	MovePMoveNodeConfig build();
}
