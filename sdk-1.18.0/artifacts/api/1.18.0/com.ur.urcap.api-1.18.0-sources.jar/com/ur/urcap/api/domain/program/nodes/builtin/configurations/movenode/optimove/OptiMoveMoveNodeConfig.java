/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.optimove;

import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.FeatureSelection;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.MoveNodeConfig;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelection;


/**
 * @since 1.17.0
 */
public interface OptiMoveMoveNodeConfig extends MoveNodeConfig {

	/**
	 * Movement types supported by Move nodes using OptiMove.
	 */
	enum MotionType {
		MOVE_J,
		MOVE_L
	}

	/**
	 * @return The movement type of this Move node
	 */
	MotionType getMoveType();

	/**
	 * @return The OptiMove motion parameters for this Move node
	 */
	OptiMoveMotionParameters getMotionParameters();

	/**
	 *
	 * @return The feature selection for this Move node.
	 */
	FeatureSelection getFeatureSelection();

	/**
	 *
	 * @return The TCP selection for this Move node.
	 */
	TCPSelection getTCPSelection();
}
