/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.optimove.builder;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelection;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.TCPSelectionFactory;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.movenode.optimove.OptiMoveMoveNodeConfig;
import com.ur.urcap.api.domain.value.simple.Percentage;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface can be used to build a single OptiMove configuration that can be applied to a MoveJ or MoveL node.
 * OptiMove motions are agnostic to tool or joint motion types. Each configuration to be built should ideally use a new
 * {@link OptiMoveConfigBuilder} instance.
 * </p>
 *
 * <p>
 * OptiMove is a motion control option that dynamically adapts speed and acceleration to perform smooth motions, while
 * maintaining hardware limits. The speed and acceleration parameters control the speed profile of the move.
 * </p>
 *
 * <p>
 * The motion type of the OptiMove configuration can either MoveJ or MoveL. The motion type is determined by which
 * build function is called.
 * Use {@link #buildMoveJ()} to generate an OptiMove configuration with the MoveJ motion type
 * or {@link #buildMoveL()} to generate an OptiMove configuration with the MoveL motion type.
 * </p>
 *
 * <p>
 * For any configuration parameter where a value is not specified (using the corresponding set method), a default value
 * will be used when the new configuration is built whereas the original value will be used when an existing configuration
 * was copied using the {@link #copyFrom(OptiMoveMoveNodeConfig)} method.
 * </p>
 *
 * <p>
 * <b>Example:</b> <br>
 * To build a configuration with non-default values for the TCP selection and OptiMove speed parameter, while using the
 * MoveJ motion type, use the following code snippet:
 * </p>
 *
 * <pre>
 * {@code
 * OptiMoveMoveNodeConfig newConfig = configBuilder.setTCPSelection(tcpSelection)
 *                                              .setOptiMove(speedPercentage)
 *                                              .buildMoveJ();
 * }
 * </pre>
 *
 * <b>Example:</b> <br>
 * To change the value of the OptiMove acceleration parameter in the current configuration, use the following code snippet
 * to build a new updated configuration:
 *
 * <pre>
 * {@code
 *  configBuilder.copyFrom(currentConfig);
 *  MoveJMoveNodeConfig updatedConfig = configBuilder.setOptiMove(speedPercentage, accelerationPercentage)
 *                                                   .buildMoveJ();
 * }
 * </pre>
 *
 * @since 1.17.0
 */
@ProviderType
public interface OptiMoveConfigBuilder {

	/**
	 * Copy configuration parameter values from one configuration (source) to another (this) builder
	 *
	 * @param source The original configuration to copy parameter values from.
	 * @return This builder.
	 */
	OptiMoveConfigBuilder copyFrom(OptiMoveMoveNodeConfig source);

	/**
	 * Individually set the OptiMove speed and acceleration parameter for the OptiMove node configuration.
	 *
	 * <p>
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 * </p>
	 *
	 * @param speed The tool/joint speed to be achieved as a fraction of what the maximum speed the robot/joints can move
	 *              with during the motion, not {@code null}. Valid range is (0.0, 1.0] where 1.0 represents 100%.
	 * @param acceleration The tool/joint acceleration to be achieved as a fraction of what the robot/joints is able to
	 *                     perform, not {@code null}. Valid range is (0.0, 1.0] where 1.0 represents 100%.
	 * @return This builder.
	 */
	OptiMoveConfigBuilder setOptiMove(Percentage speed, Percentage acceleration);

	/**
	 * <p>
	 * Set the OptiMove speed parameter for the OptiMove Node configuration. The OptiMove acceleration parameter will
	 * automatically be derived from the specified OptiMove speed.
	 * </p>
	 *
	 * The parameter applies to the movement of the robot arm, from the previous position through the waypoints under the
	 * Move node.
	 *
	 * @param speed The tool/joint speed to be achieved as a fraction of what the maximum speed the robot/joints can move
	 * 	            with during the motion, not {@code null}. Valid range is (0.0, 1.0] where 1.0 represents 100%. The
	 * 	            OptiMove acceleration parameter will automatically be derived from this speed.
	 * @return This builder.
	 */
	OptiMoveConfigBuilder setOptiMove(Percentage speed);

	/**
	 * <p>
	 * Set feature for the OptiMove Node configuration.
	 * </p>
	 *
	 * The feature will be used for the movement of the robot arm, from the previous position through the waypoints
	 * under the Move node.
	 *
	 * @param feature The shared feature for this movement, not {@code null}.
	 * @return This builder.
	 */
	OptiMoveConfigBuilder setFeature(Feature feature);

	/**
	 * <p>
	 * Set the TCP selection for the OptiMove Node configuration.
	 * </p>
	 *
	 * <p>
	 * The TCP will be set as the active TCP before the movement of the robot arm, from the previous position through the
	 * waypoints under the Move node, is performed.
	 * </p>
	 *
	 * See {@link TCPSelection} which can be created using the {@link TCPSelectionFactory} interface.
	 *
	 * @param tcpSelection The TCP setting to be applied.
	 * @return This builder.
	 */
	OptiMoveConfigBuilder setTCPSelection(TCPSelection tcpSelection);

	/**
	 * <p>
	 * Build the MoveJ configuration with OptiMove for the Move node.
	 * </p>
	 *
	 * A default configuration can be built by calling this method without invoking any of the set methods in this
	 * interface.
	 *
	 * @return The new MoveJ configuration using OptiMove.
	 * @throws IllegalArgumentException if the speed percentage or acceleration percentage are outside the valid range
	 *                                  of (0.0, 1.0].
	 */
	OptiMoveMoveNodeConfig buildMoveJ();

	/**
	 * <p>
	 * Build the MoveL configuration with OptiMove for the Move node.
	 * </p>
	 *
	 * A default configuration can be built by calling this method without invoking any of the set methods in this
	 * interface.
	 *
	 * @return The new MoveL configuration using OptiMove.
	 * @throws IllegalArgumentException if the speed percentage or acceleration percentage are outside the valid range
	 *                                  of (0.0, 1.0].
	 */
	OptiMoveMoveNodeConfig buildMoveL();
}
