/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setnode;

/**
 * @since 1.2.56
 */
public interface DigitalOutputSelection {

	enum SelectionType {

		/**
		 * No digital output is selected.
		 */
		NO_DIGITAL_OUTPUT,

		/**
		 * The selected digital output is no longer available (e.g. because the end user has removed the output in
		 * the Installation or the needed Installation is not currently loaded).
		 */
		UNRESOLVED_DIGITAL_OUTPUT,

		/**
		 * <p>
		 * Digital output is selected.
		 * </p>
		 *
		 * The Selection instance can be cast to {@link DigitalOutput}.
		 */
		DIGITAL_OUTPUT
	}

	SelectionType getType();
}
