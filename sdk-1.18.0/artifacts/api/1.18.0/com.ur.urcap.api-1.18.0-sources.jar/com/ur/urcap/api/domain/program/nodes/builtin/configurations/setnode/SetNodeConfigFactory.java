/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setnode;

import com.ur.urcap.api.domain.io.AnalogIO;
import com.ur.urcap.api.domain.io.BooleanRegister;
import com.ur.urcap.api.domain.io.DigitalIO;
import com.ur.urcap.api.domain.io.FloatRegister;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.io.ModbusIO;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.expression.Expression;
import com.ur.urcap.api.domain.value.simple.Current;
import com.ur.urcap.api.domain.value.simple.Time;
import com.ur.urcap.api.domain.value.simple.Voltage;


/**
 * This interface can be used to construct configurations that can be set on a SetNode.
 *
 * @since 1.2.56
 */
public interface SetNodeConfigFactory {
	/**
	 * Creates a digital output configuration.
	 *
	 * @param output the digital output to apply the output action to, not {@code null}.
	 * @param valueToSet if {@code true} the output will be set to HIGH, otherwise LOW.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	DigitalOutputSetNodeConfig createDigitalOutputConfig(DigitalIO output, boolean valueToSet);

	/**
	 * Creates a digital MODBUS output configuration.
	 *
	 * @param output the digital MODBUS output to apply the output action to, not {@code null}.
	 * @param valueToSet if {@code true} the MODBUS output will be set to HIGH, otherwise LOW.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values)
	 * or if {@code output} is not a digital output. See {@link IO#isInput()} and {@link IO#getType()} .
	 */
	DigitalOutputSetNodeConfig createDigitalOutputConfig(ModbusIO output, boolean valueToSet);

	/**
	 * Creates a digital output configuration.
	 *
	 * @param output the the boolean register output to apply the output action to, not {@code null}.
	 * @param valueToSet the value to apply to the output register.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	DigitalOutputSetNodeConfig createDigitalOutputConfig(BooleanRegister output, boolean valueToSet);

	/**
	 * Creates an analog output current configuration.
	 *
	 * @param output the analog output to apply the output action to. The output should be configured to use electric
	 *               current domain, not {@code null}.
	 * @param current the electric current value/level to set, not {@code null}.
	 * @param errorHandler error handler for handling validation or domain (i.e. current or voltage) errors. If using
	 *                     {@link ErrorHandler#AUTO_CORRECT} this will clamp the value, and in case of domain error, set
	 *                     the value regardless of the output's domain type.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	AnalogOutputCurrentSetNodeConfig createAnalogOutputCurrentConfig(AnalogIO output, Current current, ErrorHandler<Current> errorHandler);

	/**
	 * Creates an analog output voltage configuration.
	 *
	 * @param output the analog output to apply the output action to. The output should be configured to use voltage
	 *               domain, not {@code null}.
	 * @param voltage the voltage value/level to set, not {@code null}.
	 * @param errorHandler error handler for handling validation or domain (i.e. current or voltage) errors. If using
	 *                     {@link ErrorHandler#AUTO_CORRECT} this will clamp the value, and in case of domain error, set
	 *                     the value regardless of the output's domain type.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	AnalogOutputVoltageSetNodeConfig createAnalogOutputVoltageConfig(AnalogIO output, Voltage voltage, ErrorHandler<Voltage> errorHandler);

	/**
	 * Create a float register output configuration.
	 *
	 * @param output the register to apply the value to, not {@code null}.
	 * @param valueToSet the value to be set.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	FloatRegisterOutputSetNodeConfig createFloatRegisterOutputConfig(FloatRegister output, float valueToSet);

	/**
	 * Create an expression output configuration.
	 *
	 * @param output the output to set to the result of the evaluation of the expression, not {@code null}.
	 * @param expression the expression whose evaluation will be set on the output, not {@code null}.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 */
	ExpressionOutputSetNodeConfig createExpressionOutputConfig(IO output, Expression expression);

	/**
	 * Creates a single digital pulse configuration.
	 *
	 * @param output the digital output to apply the output action to, not {@code null}.
	 * @param pulseTime the time to pulse the pin for.
	 * @param errorHandler error handler for handling validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will default the value to 0.5 seconds.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 *
	 * @since 1.6.0
	 */
	SingleDigitalPulseSetNodeConfig createSingleDigitalPulseConfig(DigitalIO output, Time pulseTime, ErrorHandler<Time> errorHandler);

	/**
	 * Creates a single digital pulse MODBUS configuration.
	 *
	 * @param output the digital MODBUS output to apply the output action to, not {@code null}.
	 * @param pulseTime the time to pulse the pin for.
	 * @param errorHandler error handler for handling validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                    this will default the value to 0.5 seconds.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values)
	 * or if {@code output} is not a digital output. See {@link IO#isInput()} and {@link IO#getType()} .
	 *
	 * @since 1.6.0
	 */
	SingleDigitalPulseSetNodeConfig createSingleDigitalPulseConfig(ModbusIO output, Time pulseTime, ErrorHandler<Time> errorHandler);

	/**
	 * Creates a single digital pulse configuration.
	 *
	 * @param output the the boolean register output to apply the output action to, not {@code null}.
	 * @param pulseTime the time to pulse the pin for.
	 * @param errorHandler error handler for handling validation errors. If using {@link ErrorHandler#AUTO_CORRECT}
	 *                     this will default the value to 0.5 seconds.
	 * @return the configuration.
	 * @throws IllegalArgumentException if {@code output} is an input (does not support writing of values). See {@link IO#isInput()}.
	 *
	 * @since 1.6.0
	 */
	SingleDigitalPulseSetNodeConfig createSingleDigitalPulseConfig(BooleanRegister output, Time pulseTime, ErrorHandler<Time> errorHandler);
}
