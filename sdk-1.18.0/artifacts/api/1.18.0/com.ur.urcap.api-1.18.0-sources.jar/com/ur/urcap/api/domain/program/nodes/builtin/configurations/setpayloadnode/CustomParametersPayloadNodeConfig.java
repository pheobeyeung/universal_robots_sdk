/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode;

import com.ur.urcap.api.domain.value.Position;
import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.domain.value.simple.Time;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents a configuration of the Set Payload node which is using custom payload parameters. The
 * specified custom payload parameters can be accessed with this interface.
 *
 * @since 1.13.0
 */
@ProviderType
public interface CustomParametersPayloadNodeConfig extends PayloadNodeConfig {

	/**
	 * @return The total mass of the payload
	 */
	Mass getMass();

	/**
	 * Gets the payload's center of gravity (CoG), also referred to as center of mass. It is defined as the offset
	 * between the center of the tool output flange and the center of gravity of the attached payload.
	 *
	 * @return The center of gravity (CoG) of the payload relative to the center of the tool output flange
	 */
	Position getCenterOfGravity();

	/**
	 * @return The defined transition time when ramping to this payload. The Transition time is the time used to ramp
	 *         the payload from the robot's current active payload to this payload.
	 *
	 * @since 1.14.0
	 */
	Time getTransitionTime();
}
