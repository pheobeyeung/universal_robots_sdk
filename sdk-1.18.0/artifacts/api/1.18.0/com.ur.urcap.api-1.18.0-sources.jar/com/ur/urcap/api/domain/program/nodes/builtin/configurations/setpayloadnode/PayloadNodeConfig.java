/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode;

import com.ur.urcap.api.domain.program.nodes.builtin.SetPayloadNode;


/**
 * This base interface represents a configuration of the Set Payload program node, i.e. a {@link SetPayloadNode}
 * instance.
 *
 * @since 1.13.0
 */
public interface PayloadNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * <p>
		 * A payload (from the installation) is selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link SelectionPayloadNodeConfig}.
		 */
		PAYLOAD_SELECTION,

		/**
		 * <p>
		 * Custom payload parameters are specified.
		 * </p>
		 *
		 * The config instance can be cast to {@link CustomParametersPayloadNodeConfig}.
		 */
		CUSTOM_PARAMETERS
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return The type of this config.
	 */
	ConfigType getConfigType();
}
