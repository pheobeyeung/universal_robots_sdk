/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode;

import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.payload.IllegalCenterOfGravityException;
import com.ur.urcap.api.domain.payload.IllegalMassException;
import com.ur.urcap.api.domain.payload.Payload;
import com.ur.urcap.api.domain.payload.PayloadModel;
import com.ur.urcap.api.domain.program.nodes.builtin.SetPayloadNode;
import com.ur.urcap.api.domain.robot.RobotLimits;
import com.ur.urcap.api.domain.robot.RobotModel;
import com.ur.urcap.api.domain.validation.ErrorHandler;
import com.ur.urcap.api.domain.value.Position;
import com.ur.urcap.api.domain.value.PositionFactory;
import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.domain.value.simple.SimpleValueFactory;
import com.ur.urcap.api.domain.value.simple.Time;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface can be used to create configurations that can be applied to a Set Payload program node, i.e. a
 * {@link SetPayloadNode} instance.
 * </p>
 *
 * @since 1.13.0
 */
@ProviderType
public interface PayloadNodeConfigFactory {

	/**
	 * <p>
	 * This method creates a configuration for the Set Payload node with a pre-selected payload (from the installation)
	 * and with default value for the transition time.
	 * </p>
	 *
	 * Use the {@link PayloadModel} interface to get a list of available payloads from the installation to choose from.
	 *
	 * @param payload The payload (from the installation) to be selected in the Set Payload node, not {@code null}.
	 * @return A Set Payload node configuration with the specified payload selection and default transition time
	 */
	SelectionPayloadNodeConfig createSelectionConfig(Payload payload);


	/**
	 * <p>
	 * This method creates a configuration for the Set Payload node with a pre-selected payload (from the installation)
	 * and specified transition time.
	 * </p>
	 *
	 * Use the {@link PayloadModel} interface to get a list of available payloads from the installation to choose from
	 * and use {@link SimpleValueFactory#createTime(double, Time.Unit)} to create the required time parameter.
	 *
	 * @param payload The payload (from the installation) to be selected in the Set Payload node, not {@code null}.
	 * @param transitionTime Transition time is the time it will take to ramp the payload from the actual payload to the
	 *                       new payload. This can be set to avoid protective stops when handling heavy payloads.
	 *                       Cannot be {@code null}.
	 * @param transitionTimeErrorHandler Error handler for handling validation. If {@link ErrorHandler#AUTO_CORRECT} is
	 *                                   used, this will clamp the specified value to the nearest valid transition time
	 *                                   value.
	 * @return A Set Payload node configuration with the specified payload selection and transition time
	 *
	 * @since 1.14.0
	 */
	SelectionPayloadNodeConfig createSelectionConfig(Payload payload,
													 Time transitionTime,
													 ErrorHandler<Time> transitionTimeErrorHandler);

	/**
	 * <p>
	 * This method creates a configuration for the Set Payload node with custom payload parameters and default value for
	 * the transition time.
	 * </p>
	 *
	 * <p>
	 * Use {@link SimpleValueFactory#createMass(double, Mass.Unit)} and the {@link PositionFactory} interface to create
	 * the required custom payload parameters.
	 * </p>
	 *
	 * The valid range for the payload mass and the coordinates of the center of gravity (CoG) are available through the
	 * {@link RobotLimits} interface which can be accessed with {@link RobotModel#getRobotLimits()} (an instance of the
	 * {@link RobotModel} interface can be retrieved through {@link SystemAPI#getRobotModel()}).
	 *
	 * @param mass The total mass of the payload attached to the tool flange of the robot, not {@code null}. Create it
	 *             using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity (CoG), also referred to as center of mass, for the payload. It is
	 *                        defined as the offset between the center of the tool output flange and the center of gravity
	 *                        of the attached payload. Cannot be {@code null}. Create it using the {@link PositionFactory}
	 *                        interface.
	 * @return A Set Payload node configuration with the specified custom payload parameters and default value for the
	 *         transition time.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *
	 * @since 1.14.0
	 */
	CustomParametersPayloadNodeConfig createCustomParametersConfig(Mass mass, Position centerOfGravity);

	/**
	 * <p>
	 * This method creates a configuration for the Set Payload node with custom payload parameters and specified
	 * transition time.
	 * </p>
	 *
	 * <p>
	 * Use {@link SimpleValueFactory#createMass(double, Mass.Unit)}, {@link SimpleValueFactory#createTime(double, Time.Unit)}
	 * and the {@link PositionFactory} interface to create the required parameters.
	 * </p>
	 *
	 * The valid range for the payload mass and the coordinates of the center of gravity (CoG) are available through the
	 * {@link RobotLimits} interface which can be accessed with {@link RobotModel#getRobotLimits()} (an instance of the
	 * {@link RobotModel} interface can be retrieved through {@link SystemAPI#getRobotModel()}).
	 *
	 * @param mass The total mass of the payload attached to the tool flange of the robot, not {@code null}. Create it
	 *             using {@link SimpleValueFactory#createMass(double, Mass.Unit)}.
	 * @param centerOfGravity The center of gravity (CoG), also referred to as center of mass, for the payload. It is
	 *                        defined as the offset between the center of the tool output flange and the center of gravity
	 *                        of the attached payload. Cannot be {@code null}. Create it using the {@link PositionFactory}
	 *                        interface.
	 * @param transitionTime Transition time is the time it will take to ramp the payload from the actual payload to the
	 *                       new payload. This can be set to avoid protective stops when handling heavy payloads. Cannot
	 *                       be {@code null}.
	 * @param transitionTimeErrorHandler Error handler for handling validation. If {@link ErrorHandler#AUTO_CORRECT} is
	 *                                   used, this will clamp the specified value to the nearest valid transition time
	 *                                   value.
	 * @return A Set Payload node configuration with the specified custom payload parameters and transition time.
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 * @throws IllegalCenterOfGravityException If any of the values of the specified center of gravity are not inside
	 *                                         the valid range as defined by PolyScope.
	 *
	 * @since 1.14.0
	 */
	CustomParametersPayloadNodeConfig createCustomParametersConfig(Mass mass,
																   Position centerOfGravity,
																   Time transitionTime,
																   ErrorHandler<Time> transitionTimeErrorHandler);
}
