/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;

import com.ur.urcap.api.domain.value.simple.Acceleration;
import com.ur.urcap.api.domain.value.simple.AngularAcceleration;

/**
 * @since 1.6.0
 */
public interface CustomDecelerationParameters extends DecelerationParameters {

	enum Type {

		/**
		 * This deceleration was either created specifying values for both {@link AngularAcceleration} and {@link Acceleration}
		 * and/or is in use in an Until node that is not yet in the program tree.
		 */
		Unknown,

		/**
		 * This deceleration is currently used under a MoveJ node.
		 */
		Angular,

		/**
		 * This deceleration is currently used under a MoveL or MoveP node.
		 */
		Cartesian
	}

	/**
	 *
	 * @return the deceleration type. This can change depending on the Move node type above the Until node.
	 */
	Type getCurrentType();

	/**
	 * The rate at which to decelerate when the until condition is met.
	 *
	 * @return the specified angular deceleration of the until node (absolute value).
	 */
	AngularAcceleration getAngularDeceleration();

	/**
	 * The rate at which to decelerate when the until condition is met.
	 *
	 * @return the specified Cartesian deceleration of the until node (absolute value).
	 */
	Acceleration getCartesianDeceleration();
}
