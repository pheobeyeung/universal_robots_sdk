/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;

/**
 * @since 1.7.0
 */
public interface IOInputUntilNodeConfig extends UntilNodeConfig {

	/**
	 * The type of the input selection.
	 */
	enum SelectionType {

		/**
		 * The node is not fully configured.
		 */
		NONE,

		/**
		 * <p>
		 * Digital input is selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link DigitalInputUntilNodeConfig}.
		 */
		DIGITAL_INPUT,

		/**
		 * <p>
		 * Analog input is selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link AnalogInputUntilNodeConfig}.
		 */
		ANALOG_INPUT,

		/**
		 * <p>
		 * A float input register is selected.
		 * </p>
		 *
		 * The config instance can be cast to {@link FloatRegisterInputUntilNodeConfig}.
		 */
		FLOAT_REGISTER_INPUT
	}

	SelectionType getType();
}

