/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.untilnode;


/**
 * This interface represents a configuration of the Until program node.
 *
 * @since 1.6.0
 */
public interface UntilNodeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * An undefined Until node with no type set yet.
		 */
		NONE,

		/**
		 * <p>
		 * An Until node where the until condition is true once the evaluation of an expression is true.
		 * </p>
		 *
		 * The config instance can be cast to {@link ExpressionUntilNodeConfig}.
		 */
		EXPRESSION,

		/**
		 * <p>
		 * An Until node where the until condition is true once a given distance is reached.
		 * </p>
		 *
		 * The config can be cast to {@link DistanceUntilNodeConfig}.
		 */
		DISTANCE,

		/**
		 * <p>
		 * An Until node where the until condition is true once its parent Waypoint is reached.
		 * </p>
		 *
		 * The config can be cast to {@link ReachedWaypointUntilNodeConfig}.
		 */
		REACHED_WAYPOINT,

		/**
		 * <p>
		 * An Until node where the until condition is true once a given I/O reaches a certain value.
		 * </p>
		 *
		 * The config can be cast to {@link IOInputUntilNodeConfig}.
		 */
		IO_INPUT,

		/**
		 * <p>
		 * An Until node where the until condition is true once an impact on the Tool is detected.
		 * </p>
		 *
		 * This functionality is not supported by the API.
		 */
		TOOL_CONTACT
	}

	/**
	 * This method returns the type of configuration. Cast this instance appropriately to have access to specific getters.
	 *
	 * @return the type of this config.
	 */
	ConfigType getConfigType();
}

