/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waypointnode;

/**
 * @since 1.2.56
 */
public interface BlendParameters {

	/**
	 * The blend parameters type used to determine which type of blend parameters this instance is.
	 */
	enum ParameterType {

		/**
		 * No blend has been selected (the robot arm will stop at this point).
		 */
		NO_BLEND,

		/**
		 * Shared blend has been selected.
		 */
		SHARED_BLEND,

		/**
		 * <p>>
		 * Waypoint blend has been selected.
		 * </p>
		 *
		 * The blend instance can be cast to {@link WaypointBlendParameters}.
		 */
		WAYPOINT_BLEND
	}

	ParameterType getType();
}
