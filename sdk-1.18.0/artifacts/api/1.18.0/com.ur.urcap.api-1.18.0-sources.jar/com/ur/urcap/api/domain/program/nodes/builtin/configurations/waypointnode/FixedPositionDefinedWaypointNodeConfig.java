/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.builtin.configurations.waypointnode;

import com.ur.urcap.api.domain.program.structure.TreeNode;
import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import com.ur.urcap.api.util.Optional;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents a fixed position configuration for a Waypoint node which has a defined Cartesian location
 * (i.e. pose).
 *
 * @since 1.2.56
 */
@ProviderType
public interface FixedPositionDefinedWaypointNodeConfig extends FixedPositionWaypointNodeConfig {

	/**
	 * This method returns the pose for the Cartesian location of the Waypoint node, i.e. the Cartesian position and
	 * orientation of the waypoint. The returned pose includes the TCP offset specified when the waypoint was
	 * defined/taught.
	 *
	 * @return A pose representing the Cartesian location of the waypoint (its Cartesian position and orientation)
	 */
	Pose getPose();

	/**
	 * <p>
	 * This method returns the joint positions corresponding to the defined Cartesian location of the waypoint (accessible
	 * through {@link #getPose()}).
	 * </p>
	 *
	 * <p>
	 * The waypoint's joint positions depend on the TCP and feature selection in the Move node, that is parent to the
	 * Waypoint node in the program tree. The joint positions will change accordingly, when these selections are changed
	 * in the parent Move node, or when the Cartesian position and/or orientation of the TCP/feature are changed in the
	 * installation. They can also change as a result of the end user loading a different installation. Note that this
	 * means that the joint positions can be subject to change after this method has been called.
	 * </p>
	 *
	 * The waypoint's joint positions will <b>not</b> be available when:
	 * <ul>
	 *     <li>
	 *         The Waypoint node and all its ancestors (including the parent Move node) are not in the program tree,
	 *         i.e. the joint positions are not accessible during subtree construction (using the {@link TreeNode}
	 *         interface).
	 *     </li>
	 *     <li>
	 *         The TCP or feature selection in the parent Move node is not resolvable, i.e. the selected TCP/feature is
	 *         not present in the current installation. This can occur, if the end user loads a different installation
	 *         which does not contain the TCP/feature, or if the TCP/feature is removed by the end user or the URCap
	 *         that added the it.
	 *     </li>
	 *     <li>
	 *         The Cartesian location of the waypoint is not reachable, i.e. it was not possible to compute joint
	 *         positions corresponding to the waypoint's Cartesian location (inverse kinematics failed to find a
	 *         solution).
	 *     </li>
	 * </ul>
	 *
	 * <p>
	 * Because of this, the returned joint positions are wrapped in an {@link Optional}, which will not have any value
	 * available in the situations described above. Always use {@link Optional#isPresent()} to check if the waypoint's
	 * joint positions are available before accessing them using {@link Optional#get()}.
	 * </p>
	 *
	 * <p>
	 * <b>Note:</b> If the parent Move node is configured to use the active TCP (i.e. the 'Use Active TCP' option), the
	 * returned joint positions will depend on which TCP is currently active. <br>
	 *
	 * <b>Note:</b> Even though the returned joint positions correspond to the Cartesian location of the waypoint, they
	 * can differ from the joint positions used at runtime of the robot program, as many things influence the joint
	 * positions during the execution of a program. For instance, during execution of a MoveL parent node, the achieved
	 * joint positions for the Waypoint node depend on the current position of the robot (e.g. determined by a previous
	 * executed Waypoint node) when computing the joint positions corresponding to the waypoint's Cartesian location
	 * (using inverse kinematics). Joint positions can also depend on the currently active TCP if the parent Move node
	 * is configured to use that.
	 * </p>
	 *
	 * @return Joint positions corresponding to the defined Cartesian location of the waypoint (Cartesian position and
	 *         orientation) wrapped in an {@link Optional}. Always use {@link Optional#isPresent()} to verify that the
	 * 	       waypoint's joint positions are available before using {@link Optional#get()} to retrieve them.
	 *
	 * @since 1.12.0
	 */
	Optional<JointPositions> getJointPositions();
}
