/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.program.nodes.ProgramNode;


/**
 * This interface is a representation of an instance of a {@link ProgramNodeContribution}.
 *
 * @since 1.1.0
 */
public interface URCapProgramNode extends ProgramNode {

	/**
	 * This method returns {@code true} if a subsequent call to {@link #getAs(Class)} using the same parameter will be
	 * successful.
	 *
	 * @param urCapProgramNodeInterface the interface the program node implements, not {@code null}.
	 * @return {@code true} if the program node can be represented as the specified interface. {@code false} otherwise.
	 *
	 * @since 1.2.56
	 */
	boolean canGetAs(Class<?> urCapProgramNodeInterface);

	/**
	 * <p>
	 * The URCap program node contribution (i.e. the class implementing {@link ProgramNodeContribution}) can optionally
	 * implement additional interfaces providing access to various information and/or methods.
	 * If such an interface is implemented, the {@link #getAs(Class)} method can be used to retrieve the program node as
	 * said interface.
	 * </p>
	 *
	 * <b>Note:</b> Do not use {@link ProgramNodeContribution} (or an extension/implementation thereof) nor
	 * {@link Object} as argument, otherwise an {@link IllegalArgumentException} is thrown.
	 *
	 * @param urCapProgramNodeInterface the interface the program node implements, not {@code null}.
	 * @param <T> The (generic) type parameter for the interface.
	 * @return the program node represented as the interface specified. If the program node has not been added to the
	 *         program tree, null will be returned.
	 * @throws ClassCastException If the program node does not implement the interface a class cast exception will be thrown.
	 * @throws IllegalArgumentException If the type parameter is an implementation/extension of{@link ProgramNodeContribution}
	 * or {@link Object}.
	 *
	 * @since 1.2.56
	 */
	<T> T getAs(Class<T> urCapProgramNodeInterface);
}
