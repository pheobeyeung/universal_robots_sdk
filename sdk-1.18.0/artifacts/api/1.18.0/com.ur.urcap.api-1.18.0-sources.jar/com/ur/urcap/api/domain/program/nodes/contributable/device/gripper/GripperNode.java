/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper;

import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.contributable.device.UnsupportedConfig;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripActionConfigBuilder;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.GripperNodeConfig;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration.ReleaseActionConfigBuilder;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;
import org.osgi.annotation.versioning.ProviderType;


/**
 * <p>
 * This interface represents a program node which can be used for programming grip and release actions with a selected
 * gripper device.
 * </p>
 * 
 * <p>
 * An instance of this interface can be built using the {@link GripperNodeFactory} interface and is returned as a result
 * when {@link GripperNodeFactory#createGripperNode(GripperDevice)} is called.
 * </p>
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripperNode extends ProgramNode {

	/**
	 * Creates a new {@link GripActionConfigBuilder} instance for building a single Gripper node configuration for a
	 * grip action. Each configuration being built should ideally use a new {@link GripActionConfigBuilder} instance.
	 *
	 * @return a new builder for creating a single Gripper node configuration for a grip action
	 */
	GripActionConfigBuilder createGripActionConfigBuilder();

	/**
	 * Creates a new {@link ReleaseActionConfigBuilder} instance for building a single Gripper node configuration for a
	 * release action. Each configuration being built should ideally use a new {@link ReleaseActionConfigBuilder} instance.
	 *
	 * @return A new builder for creating a single Gripper node configuration for a release action
	 */
	ReleaseActionConfigBuilder createReleaseActionConfigBuilder();

	/**
	 * @return The gripper device used by this Gripper node
	 */
	GripperDevice getGripperDevice();

	/**
	 * @return The current configuration of this node
	 */
	GripperNodeConfig getConfig();

	/**
	 * <p>
	 * Sets a configuration on this node.
	 * </p>
	 *
	 * <b>Note:</b> The various available gripper devices can support different sets of capabilities. Therefore use
	 * {@link GripperDevice#getCapabilitySupport(Class)} to ensure that the gripper device used by the Gripper node
	 * (accessible through {@link #getGripperDevice()}) supports a specific desired capability (or set of
	 * capabilities) before applying a configuration. Applying a configuration not supported by the gripper node/device
	 * will throw an exception.
	 *
	 * @param config The configuration to be set.
	 * @return This node
	 * @throws UnsupportedConfig If the specified {@link GripperNodeConfig} is not supported by this node. This can
	 * occur when the specified {@link GripperNodeConfig} is a newly built configuration which uses a capability not
	 * supported by the gripper device used by this node. It will also occur when an existing configuration is taken
	 * from another node that uses a different gripper device, i.e. the two gripper devices <b>must</b> be identical.
	 * @throws IllegalStateException If called from a Swing-based URCap outside of an {@link UndoableChanges} scope (see
	 *  also {@link UndoRedoManager}).
	 */
	GripperNode setConfig(GripperNodeConfig config);
}
