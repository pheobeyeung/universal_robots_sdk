/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration;

import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.device.gripper.GripperDevice;
import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import com.ur.urcap.api.domain.payload.IllegalMassException;
import com.ur.urcap.api.domain.payload.Payload;
import com.ur.urcap.api.domain.payload.PayloadModel;
import com.ur.urcap.api.domain.program.nodes.contributable.device.UnsupportedConfig;
import com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.GripperNode;
import com.ur.urcap.api.domain.robot.RobotLimits;
import com.ur.urcap.api.domain.robot.RobotModel;
import com.ur.urcap.api.domain.value.simple.Mass;
import com.ur.urcap.api.domain.value.simple.SimpleValueFactory;
import com.ur.urcap.api.util.Optional;
import org.osgi.annotation.versioning.ProviderType;

/**
 * <p>
 * This interface can be used to build a single gripper configuration for a grip action. The resulting configuration
 * can be applied to a {@link GripperNode} instance.
 * </p>
 *
 * <p>
 * Each configuration being built should ideally use a new {@link GripActionConfigBuilder} instance. Note that if a
 * gripper selection was specified when the builder was used to create a configuration for a Gripper node (which is using
 * a multi-gripper device), then a new builder instance <b>must</b> be obtained to create a new configuration for another
 * Gripper node which is using a single gripper device.
 * </p>
 *
 * <b>Note:</b> The various available gripper devices can support different sets of capabilities. Therefore use
 * {@link GripperDevice#getCapabilitySupport(Class)} to ensure that the gripper device used by a Gripper node
 * (accessible through {@link GripperNode#getGripperDevice()}) supports a specific capability (or set of capabilities)
 * before applying a configuration. Applying a configuration not supported by the gripper node/device will
 * throw an exception.
 *
 * @since 1.9.0
 */
@ProviderType
public interface GripActionConfigBuilder {

	/**
	 * <p>
	 * Set an empty gripper selection for a Gripper node that uses a multi-gripper device, i.e. a gripper device
	 * supporting the multi-gripper capability (see the {@link MultiGripperSupport} interface). No individual gripper/zone
	 * will be selected in the Gripper node (any existing selection will be cleared).
	 * </p>
	 *
	 * <b>Note:</b> Not all grippers support the multi-gripper capability. Use the method
	 * {@link GripperDevice#getCapabilitySupport(Class)} with the class of the {@link MultiGripperSupport} interface as
	 * argument to verify that the gripper device used by a Gripper node (accessible through
	 * {@link GripperNode#getGripperDevice()}) supports multiple grippers. Attempting to apply a configuration to a
	 * Gripper node (using {@link GripperNode#setConfig(GripperNodeConfig)}) will throw the {@link UnsupportedConfig}
	 * exception, if the node uses a single gripper device.
	 *
	 * @return This builder
	 *
	 * @since 1.11.0
	 */
	GripActionConfigBuilder setEmptyGripperSelection();

	/**
	 * <p>
	 * Apply an existing gripper selection to a Gripper node that uses a multi-gripper device, i.e. a gripper device
	 * supporting the multi-gripper capability (see the {@link MultiGripperSupport} interface). The specified gripper/zone
	 * selection must be taken from an existing configuration by using the return value of
	 * {@link GripActionConfig#getGripperSelection()} or {@link ReleaseActionConfig#getGripperSelection()}.
	 * </p>
	 *
	 * <b>Note:</b> Not all grippers support the multi-gripper capability. Use the method
	 * {@link GripperDevice#getCapabilitySupport(Class)} with the class of the {@link MultiGripperSupport} interface as
	 * argument to verify that the gripper device used by a Gripper node (accessible through
	 * {@link GripperNode#getGripperDevice()}) supports multiple grippers. Attempting to apply a configuration to a
	 * Gripper node (using {@link GripperNode#setConfig(GripperNodeConfig)}) will throw the {@link UnsupportedConfig}
	 * exception, if the node uses a single gripper device.
	 *
	 * @param gripperSelection The existing gripper selection to apply, not {@code null}
	 * @return This builder
	 *
	 * @since 1.11.0
	 */
	GripActionConfigBuilder setGripperSelection(Optional<SelectableGripper> gripperSelection);

	/**
	 * <p>
	 * Select the specified individual gripper/zone for a Gripper node that uses a multi-gripper device, i.e. a gripper
	 * device supporting the multi-gripper capability (see the {@link MultiGripperSupport} interface).
	 * </p>
	 *
	 * <b>Note:</b> Not all grippers support the multi-gripper capability. Use the method
	 * {@link GripperDevice#getCapabilitySupport(Class)} with the class of the {@link MultiGripperSupport} interface as
	 * argument to verify that the gripper device used by a Gripper node (accessible through
	 * {@link GripperNode#getGripperDevice()}) supports multiple grippers. Attempting to apply a configuration to a
	 * Gripper node (using {@link GripperNode#setConfig(GripperNodeConfig)}) will throw the {@link UnsupportedConfig}
	 * exception, if the node uses a single gripper device.
	 *
	 * @param gripper The individual gripper/zone to be selected, not {@code null}
	 * @return This builder
	 *
	 * @since 1.11.0
	 */
	GripActionConfigBuilder setGripperSelection(SelectableGripper gripper);

	/**
	 * <p>
	 * Enable the payload setting for a Gripper node and configure it to apply the specified total payload mass after
	 * the grip action has finished executing.
	 * </p>
	 *
	 * <p>
	 * Use the {@link SimpleValueFactory#createMass(double, Mass.Unit)} method to create the payload mass. The valid
	 * range for the payload mass is available through the {@link RobotLimits} interface which can be accessed with
	 * {@link RobotModel#getRobotLimits()} (an instance of the {@link RobotModel} interface can be retrieved through
	 * {@link SystemAPI#getRobotModel()}).
	 * </p>

	 * <p>
	 * <b>Note:</b> The specified mass must be the total mass of the payload attached to the tool output flange of the
	 * robot.
	 * </p>
	 *
	 * <p>
	 * Consider instead using the {@link #setPayloadSelection(Payload)} method which allows for selecting a pre-defined
	 * payload from the installation in PolyScope.
	 * </p>
	 *
	 * @param mass The total mass of the payload (attached to the tool ouput flange of the robot) to be applied after the
	 *             execution of this grip action, not {@code null}.
	 * @return This builder
	 * @throws IllegalMassException If the specified mass is not inside the valid range as defined by PolyScope.
	 *
	 * @since 1.13.0
	 */
	GripActionConfigBuilder setPayloadMass(Mass mass);

	/**
	 * Enable the payload setting and configure it to apply a total payload mass (to be applied after the grip action has
	 * finished executing), but clear the associated 'Set Total Payload' payload mass field. This will make the Gripper 
	 * node undefined.
	 *
	 * @return This builder
	 *
	 * @since 1.13.0
	 */
	GripActionConfigBuilder setEmptyPayloadMass();

	/**
	 * <p>
	 * Enable the payload setting for a Gripper node and configure it to apply the specified payload (from the
	 * installation) after the grip action has finished executing.
	 * </p>
	 *
	 * <p>
	 * Use the {@link PayloadModel} interface to get a list of available payloads from the installation to choose from.
	 * </p>
	 *
	 * @param payload The payload (from the installation) to be applied after the execution of this grip action, not
	 *                {@code null}
	 * @return This builder
	 *
	 * @since 1.13.0
	 */
	GripActionConfigBuilder setPayloadSelection(Payload payload);

	/**
	 * Disable the payload setting for a Gripper node. The Gripper node will be defined and no change in payload will be 
	 * applied after the grip action has finished executing.
	 *
	 * @return This builder
	 *
	 * @since 1.13.0
	 */
	GripActionConfigBuilder setPayloadSettingDisabled();

	/**
	 * Build the gripper configuration for a Gripper program node.
	 *
	 * @return The Gripper node configuration for a grip action
	 */
	GripActionConfig build();
}
