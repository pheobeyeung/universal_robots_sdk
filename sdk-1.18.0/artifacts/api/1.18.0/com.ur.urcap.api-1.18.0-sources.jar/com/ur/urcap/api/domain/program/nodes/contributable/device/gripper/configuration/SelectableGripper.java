/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.nodes.contributable.device.gripper.configuration;

import com.ur.urcap.api.domain.device.gripper.capability.MultiGripperSupport;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface represents an individual gripper in a multi-gripper device, i.e. a gripper device supporting the
 * multi-gripper capability (see the {@link MultiGripperSupport} interface). The gripper is selectable by the end user
 * when configuring a Gripper program node for a multi-gripper device.
 *
 * @since 1.11.0
 */
@ProviderType
public interface SelectableGripper {

	/**
	 * <p>
	 * Get the unique identifier (id) for this gripper. This can be used to identify this specific gripper among the
	 * set of individual grippers available in a specific multi-gripper device.
	 * </p>
	 *
	 * Note that this id is not "globally" unique, but only unique for the individual grippers belonging to a specific
	 * multi-gripper device.
	 *
	 * @return The unique identifier of this gripper
	 */
	String getId();

	/**
	 * <p>
	 * The name of the gripper displayed in the PolyScope UI, e.g. in the Gripper toolbar and program node.
	 * </p>
	 *
	 * <b>Note:</b> This name must not be used to uniquely identify a specific individual gripper, since the name might
	 * be translated (depending on the selected language in PolyScope) or be changed between versions of the URCap that
	 * added the gripper.
	 *
	 * @return The name of this gripper displayed in PolyScope
	 */
	String getDisplayName();

	/**
	 * <p>
	 * An individual gripper cannot be guaranteed to be present in PolyScope. This method can be used to determine, if
	 * the gripper is present.
	 * </p>
	 *
	 * The gripper will not be present if the owning multi-gripper device has disabled that specific individual gripper.
	 *
	 * @return {@code true}, if this individual gripper is present in PolyScope, otherwise {@code false}.
	 */
	boolean isResolvable();
}
