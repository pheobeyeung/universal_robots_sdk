/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.structure;

import com.ur.urcap.api.domain.program.nodes.builtin.AssignmentNode;
import com.ur.urcap.api.domain.program.nodes.builtin.CircleMoveNode;
import com.ur.urcap.api.domain.program.nodes.builtin.CommentNode;
import com.ur.urcap.api.domain.program.nodes.builtin.DirectionNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ElseIfNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ElseNode;
import com.ur.urcap.api.domain.program.nodes.builtin.FolderNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ForceNode;
import com.ur.urcap.api.domain.program.nodes.builtin.HaltNode;
import com.ur.urcap.api.domain.program.nodes.builtin.HomeNode;
import com.ur.urcap.api.domain.program.nodes.builtin.IfNode;
import com.ur.urcap.api.domain.program.nodes.builtin.LoopNode;
import com.ur.urcap.api.domain.program.nodes.builtin.MoveNode;
import com.ur.urcap.api.domain.program.nodes.builtin.PalletNode;
import com.ur.urcap.api.domain.program.nodes.builtin.PopupNode;
import com.ur.urcap.api.domain.program.nodes.builtin.ScrewdrivingNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SeekNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SetNode;
import com.ur.urcap.api.domain.program.nodes.builtin.SetPayloadNode;
import com.ur.urcap.api.domain.program.nodes.builtin.UntilNode;
import com.ur.urcap.api.domain.program.nodes.builtin.WaitNode;
import com.ur.urcap.api.domain.program.nodes.builtin.WaypointNode;
import com.ur.urcap.api.domain.program.nodes.contributable.URCapProgramNode;


/**
 * This abstract class is used in conjunction with the {@link TreeNode#traverse(ProgramNodeVisitor)} to visit all
 * nodes in the sub-tree under the node on which {@link TreeNode#traverse} is called.
 *
 * @since 1.2.56
 */
public abstract class ProgramNodeVisitor {

	/**
	 * <p>
	 * This method is called whenever an Assignment node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Assignment program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(AssignmentNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Circle Move node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Circle Move program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(CircleMoveNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Comment node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Comment program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(CommentNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever an Else-If node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Else-If program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(ElseIfNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever an Else node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Else program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(ElseNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Folder node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Folder program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(FolderNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Force node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Force program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0)..
	 */
	public void visit(ForceNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Halt node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Halt program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(HaltNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever an If node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The If program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(IfNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Loop node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Loop program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(LoopNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Move node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Move program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(MoveNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Pallet node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Pallet program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(PalletNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Set Payload node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Set Payload program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 *
	 * @since 1.13.0
	 */
	public void visit(SetPayloadNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Popup node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Popup program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(PopupNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Seek node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Seek program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(SeekNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Set node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Set program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(SetNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever an Until node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The UntilNode program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 *
	 * @since 1.6.0
	 */
	public void visit(UntilNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Wait node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Wait program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(WaitNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Waypoint node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Waypoint program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(WaypointNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Direction node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Direction program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 *
	 * @since 1.6.0
	 */
	public void visit(DirectionNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a Screwdriving node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The ScrewdrivingNode program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 *
	 * @since 1.8.0
	 */
	public void visit(ScrewdrivingNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a HomeNode node is encountered.
	 * </p>
	 *
	 * Override it to execute custom code.
	 *
	 * @param programNode The Direction program node.
	 * @param index       Zero-based index among the program node's siblings (at this depth).
	 * @param depth       Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *                    is at depth 0).
	 * @since 1.13.0
	 */
	public void visit(HomeNode programNode, int index, int depth) {

	}

	/**
	 * <p>
	 * This method is called whenever a URCap program node is encountered.
	 * </p>
	 *
	 * <p>
	 * Override it to execute custom code.
	 * </p>
	 *
	 * See also {@link URCapProgramNodeInterfaceVisitor#visitURCapAs(Object, int, int)} for visiting specific URCap
	 * program nodes.
	 *
	 * @param programNode The URCap program node.
	 * @param index Zero-based index among the program node's siblings (at this depth).
	 * @param depth Relative depth to the node calling the {@link TreeNode#traverse(ProgramNodeVisitor)} (calling node
	 *              is at depth 0).
	 */
	public void visit(URCapProgramNode programNode, int index, int depth) {

	}
}
