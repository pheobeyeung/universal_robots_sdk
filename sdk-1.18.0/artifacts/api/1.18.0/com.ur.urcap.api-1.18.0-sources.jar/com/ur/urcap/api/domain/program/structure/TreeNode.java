/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.program.structure;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.domain.program.ProgramModel;
import com.ur.urcap.api.domain.program.nodes.ProgramNode;
import com.ur.urcap.api.domain.program.nodes.ProgramNodeFactory;
import com.ur.urcap.api.domain.program.nodes.contributable.URCapProgramNode;
import com.ur.urcap.api.domain.undoredo.UndoRedoManager;
import com.ur.urcap.api.domain.undoredo.UndoableChanges;
import org.osgi.annotation.versioning.ProviderType;

import java.util.List;


/**
 * <p>
 * This interface represents a node in the program tree that can be used to construct a sub-tree rooted in a URCap program
 * node.
 * </p>
 *
 * Using the {@link ProgramModel#getRootTreeNode(ProgramNodeContribution)} to obtain a root for the sub-tree, it is
 * possible to add children. For each call to {@link TreeNode#addChild(ProgramNode)}, a new {@link TreeNode} is returned,
 * that can, in turn, act as a root for yet another sub-tree.
 *
 * @since 1.1.0
 */
@ProviderType
public interface TreeNode {

	/**
	 * Add a child program node to the sub-tree.
	 *
	 * @param programNode the {@link ProgramNode} constructed using the {@link ProgramNodeFactory}
	 * @return Returns a TreeNode that can be used to add children to the newly added child.
	 * @throws TreeStructureException If it is not allowed to insert the {@link ProgramNode} at this position a
	 * {@link TreeStructureException} will be thrown.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	TreeNode addChild(ProgramNode programNode) throws TreeStructureException;

	/**
	 * Inserts a child program node in the sub-tree directly before the existing selected child node. Shifts the selected
	 * child node and any subsequent nodes to positions after the newly added child.
	 *
	 * @param existingChildNode existing TreeNode child of this TreeNode.
	 * @param programNode the {@link ProgramNode} constructed using the {@link ProgramNodeFactory}.
	 * @return Returns a TreeNode that can be used to add children to the newly added child.
	 * @throws TreeStructureException If it is not allowed to insert the {@link ProgramNode} at this position or if the
	 * selected child node is not a child of this TreeNode a {@link TreeStructureException} will be thrown.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	TreeNode insertChildBefore(TreeNode existingChildNode, ProgramNode programNode) throws TreeStructureException;

	/**
	 * Inserts a child program node under in the sub-tree directly after the existing selected child node. Shifts any
	 * subsequent nodes to positions after the newly added child.
	 *
	 * @param existingChildNode existing TreeNode child of this TreeNode.
	 * @param programNode the {@link ProgramNode} constructed using the {@link ProgramNodeFactory}.
	 * @return Returns a TreeNode that can be used to add children to the newly added child.
	 * @throws TreeStructureException If it is not allowed to insert the {@link ProgramNode} at this position or if the
	 * selected child node is not a child of this TreeNode a {@link TreeStructureException} will be thrown.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	TreeNode insertChildAfter(TreeNode existingChildNode, ProgramNode programNode) throws TreeStructureException;

	/**
	 * Removes a child node from the sub-tree. Be aware that removing the last child will trigger the insertion of an
	 * {@literal <empty>} child node.
	 *
	 * @param child The TreeNode child to be removed.
	 * @return Returns {@code true} if removed successfully. {@code false} otherwise.
	 * @throws TreeStructureException If the removed child would leave the tree in an illegal state a
	 * {@link TreeStructureException} will be thrown.
	 * @throws IllegalStateException if called from a Swing-based URCap outside of an {@link UndoableChanges}
	 * scope (see also {@link UndoRedoManager}).
	 */
	boolean removeChild(TreeNode child) throws TreeStructureException;

	/**
	 * @return a list of {@code TreeNode} objects that represents all the children of this {@code TreeNode} (both
	 * programmatically added as well as inserted by the end user).
	 */
	List<TreeNode> getChildren();

	/**
	 * @return Returns the {@link ProgramNode} at this position in the sub-tree.
	 * Can either be a built-in PolyScope program node (provided by Universal Robots) or a URCap program node.
	 */
	ProgramNode getProgramNode();

	/**
	 * <p>
	 * Gets a corresponding {@link TreeNode} instance for a child program node (a {@link ProgramNode} instance) in the
	 * sub-tree under this {@link TreeNode}.
	 * </p>
	 *
	 * This method can for instance be used to gain access to the sub-tree under a child program node encountered when
	 * iterating the sub-tree of the parent node using the {@link ProgramNodeVisitor} (or any derived sub class thereof).
	 *
	 * @param programNode program node to get a corresponding {@link TreeNode} representation for, not {@code null}.
	 *                    Can either be a built-in PolyScope program node (provided by Universal Robots) or a URCap
	 *                    program node.
	 * @return the {@code TreeNode} instance for the specified program node.
	 * @throws ProgramNodeNotInSubTreeException when the program node cannot be found because it is not in the sub-tree.
	 *
	 * @since 1.9.0
	 */
	TreeNode locateDescendantTreeNode(ProgramNode programNode);

	/**
	 * Configures whether or not child nodes can be rearranged, deleted or have other nodes inserted into the child
	 * sequence by the end user.
	 *
	 * @param isChildSequenceLocked If {@code true} then the immediate children under this {@code TreeNode} will be locked.
	 * @return The same TreeNode.
	 */
	TreeNode setChildSequenceLocked(boolean isChildSequenceLocked);

	/**
	 * <p>
	 * This method traverses the entire sub-tree under this tree node in a depth-first fashion (this corresponds to a
	 * top-down approach in the program tree).
	 * </p>
	 *
	 * <p>
	 * A node visitor is used for callbacks to the visit-overloads you choose to override. The overload called depends
	 * on the node type encountered. Override the overloads for the node types you are concerned with. All visit-methods
	 * have the program node, sibling index and depth as arguments to help filter nodes if needed.
	 * </p>
	 *
	 * <p>
	 * The node visitor can be either a {@link ProgramNodeVisitor} implementation with optional overrides or a
	 * {@link URCapProgramNodeInterfaceVisitor} implementation. In the latter case, the
	 * {@link URCapProgramNodeInterfaceVisitor#visitURCapAs(Object, int, int)} method must be implemented.
	 * </p>
	 *
	 * <p>
	 * The {@link URCapProgramNodeInterfaceVisitor} can be used when targeting URCap program nodes implementing the
	 * (generic) type parameter specified in {@link URCapProgramNodeInterfaceVisitor} (see also
	 * {@link URCapProgramNode#getAs(Class)}).
	 * </p>
	 *
	 * Note that this method is sometimes called {@code accept()} in the Visitor software design pattern.
	 *
	 * @param nodeVisitor the instance callbacks are made to.
	 *
	 * @since 1.2.56
	 */
	void traverse(ProgramNodeVisitor nodeVisitor);
}
