/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.domain.resource.tooliointerface.control.ToolIOInterfaceController;


/**
 * This interface makes it possible to request exclusive control of various system resources.
 *
 * @since 1.7.0
 */
public interface ControllableResourceModel extends ResourceModel {

	/**
	 * <p>
	 * Request control of the Tool I/O Interface.
	 * </p>
	 *
	 * <b>NOTE:</b> Requests made outside the scope of the constructor of an {@link InstallationNodeContribution}
	 * instance will be ignored (except for driver contributions, see javadoc for the given contribution). <br>
	 * <b>NOTE:</b> Controlling the Tool I/O Interface only refers to the ability to control the configuration of this
	 * interface. Any URCap or the end user can, at any time, modify the value of any of the I/O signals in the connector
	 * in the robot tool.
	 *
	 * @param controller the controller of the Tool I/O Interface resource. When control is granted or about to be
	 *                   revoked, callbacks will be made to this controller. Not {@code null}.
	 */
	void requestControl(ToolIOInterfaceController controller);
}
