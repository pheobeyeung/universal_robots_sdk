/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface;

import com.ur.urcap.api.domain.resource.tooliointerface.control.AnalogInputModeConfigFactory;
import com.ur.urcap.api.domain.resource.tooliointerface.control.ToolIOInterfaceControllable;


/**
 * <p>
 * This interface represents the analog input domain configuration for the two analog inputs in the Tool I/O Interface.
 * </p>
 *
 * <p>
 * To create a new configuration, see the {@link AnalogInputModeConfigFactory} interface which is accessible through
 * {@link ToolIOInterfaceControllable#getAnalogInputModeConfigFactory()}. <br>
 *
 * To apply a configuration, see {@link ToolIOInterfaceControllable#setAnalogInputModeConfig(AnalogInputModeConfig)}.
 * </p>
 *
 * @since 1.7.0
 */
public interface AnalogInputDomainConfig extends AnalogInputModeConfig {

	/**
	 * The type of the electrical domain used by the analog inputs in the connector in the robot tool
	 */
	enum AnalogDomain {

		/**
		 * Analog input configured for electric current.
		 */
		CURRENT,

		/**
		 * Analog input configured for voltage.
		 */
		VOLTAGE
	}

	/**
	 * This method returns the type of electrical domain used by analog input 0 in the connector in the robot tool
	 * (labeled 'analog_in[2]' in PolyScope)
	 *
	 * @return electrical domain type for analog tool input 0.
	 */
	AnalogDomain getAnalogDomainForInput0();

	/**
	 * This method returns the type of electrical domain used by analog input 1 in the connector in the robot tool
	 * (labeled 'analog_in[3]' in PolyScope).
	 *
	 * @return electrical domain type for analog tool input 1.
	 */
	AnalogDomain getAnalogDomainForInput1();
}
