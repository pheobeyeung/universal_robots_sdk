/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface;


/**
 * This interface represents a configuration of the output mode for the digital outputs in the Tool I/O Interface.
 *
 * @since 1.7.0
 */
public interface DigitalOutputModeConfig {

	/**
	 * The configuration type used to determine which type of configuration this instance is.
	 */
	enum ConfigType {

		/**
		 * <p>
		 * Dual Pin Power is used as a source of power for the tool.
		 * </p>
		 *
		 * This mode disables the two digital outputs in the connector in the robot tool.
		 */
		DUAL_PIN_POWER_MODE,

		/**
		 * <p>
		 * This setting allows for individual configuration of the two digital outputs in the connector in the robot
		 * tool.
		 * </p>
		 *
		 * This instance can be cast to {@link StandardDigitalOutputModeConfig}.
		 */
		STANDARD_DIGITAL_OUTPUT_MODE
	}

	/**
	 * This method returns the type of the configuration. Cast this instance appropriately to have access to specific
	 * getters.
	 *
	 * @return the type of this configuration.
	 */
	ConfigType getConfigType();
}
