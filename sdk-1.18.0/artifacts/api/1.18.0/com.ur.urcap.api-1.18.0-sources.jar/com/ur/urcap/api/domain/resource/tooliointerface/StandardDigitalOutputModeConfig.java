/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface;

import com.ur.urcap.api.domain.resource.tooliointerface.control.DigitalOutputModeConfigFactory;
import com.ur.urcap.api.domain.resource.tooliointerface.control.ToolIOInterfaceControllable;


/**
 * <p>
 * This interface represents the digital output mode configuration for the digital outputs in the Tool I/O Interface.
 * </p>
 *
 * <p>
 * To create a new configuration, see the {@link DigitalOutputModeConfigFactory} interface which is accessible through
 * {@link ToolIOInterfaceControllable#getDigitalOutputModeConfigFactory()}. <br>
 *
 * To apply a configuration, see {@link ToolIOInterfaceControllable#setDigitalOutputModeConfig(DigitalOutputModeConfig)}.
 * </p>
 *
 * @since 1.7.0
 */
public interface StandardDigitalOutputModeConfig extends DigitalOutputModeConfig {

	/**
	 * Available output modes for the digital outputs in the connector in the robot tool.
	 */
	enum OutputMode {

		/**
		 * When the digital output is off, the pin allows a current to flow to the ground.
		 * This can be used in conjunction with the PWR pin to create a full circuit.
		 */
		SINKING_NPN,

		/**
		 * When the digital output is on, the pin provides a positive voltage source.
		 * This can be used in conjunction with the GND pin to create a full circuit.
		 */
		SOURCING_PNP,

		/**
		 * This is a combination of sinking and sourcing.
		 */
		PUSH_PULL
	}

	/**
	 * @return Output mode for the digital output 0 in the connector in the robot tool.
	 */
	OutputMode getOutputModeForOutput0();

	/**
	 * @return Output mode for the digital output 1 in the connector in the robot tool.
	 */
	OutputMode getOutputModeForOutput1();
}
