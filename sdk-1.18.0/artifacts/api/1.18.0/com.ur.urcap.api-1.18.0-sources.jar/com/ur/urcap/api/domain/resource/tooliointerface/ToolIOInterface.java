/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface;

import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.CapabilityNotSupportedException;
import com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import static com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability.DIGITAL_OUTPUT_MODE;


/**
 * This interface allows for querying the settings of the Tool I/O Interface
 *
 * @since 1.7.0
 */
public interface ToolIOInterface {

	/**
	 * Available options for the output voltage level for the power supply that delivers power to the connector in the
	 * robot tool
	 */
	enum OutputVoltage {
		OUTPUT_VOLTAGE_0V,
		OUTPUT_VOLTAGE_12V,
		OUTPUT_VOLTAGE_24V
	}

	/**
	 * @return The tool output voltage level for the power supply that delivers power to the connector in the robot tool.
	 */
	OutputVoltage getOutputVoltage();

	/**
	 * @return Configuration of the output mode for the digital outputs in the connector in the robot tool
	 * @throws CapabilityNotSupportedException If the digital output mode capability is not available on the system.
	 *                                         Use {@link CapabilityManager#hasCapability(Capability)} with 
	 *                                         {@link ToolIOCapability#DIGITAL_OUTPUT_MODE} as argument to verify the 
	 *                                         availability.
	 */
	@RequiredCapability(DIGITAL_OUTPUT_MODE)
	DigitalOutputModeConfig getDigitalOutputModeConfig();

	/**
	 * @return Configuration of the input mode for the analog inputs in the connector in the robot tool
	 */
	AnalogInputModeConfig getAnalogInputModeConfig();
}
