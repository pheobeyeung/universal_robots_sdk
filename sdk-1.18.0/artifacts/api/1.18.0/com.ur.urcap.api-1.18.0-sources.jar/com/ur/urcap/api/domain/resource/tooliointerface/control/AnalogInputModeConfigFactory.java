/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface.control;

import com.ur.urcap.api.domain.resource.tooliointerface.AnalogInputDomainConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.AnalogInputDomainConfig.AnalogDomain;
import com.ur.urcap.api.domain.resource.tooliointerface.CommunicationInterfaceConfig;
import com.ur.urcap.api.domain.resource.tooliointerface.CommunicationInterfaceConfig.BaudRate;
import com.ur.urcap.api.domain.system.capability.Capability;
import com.ur.urcap.api.domain.system.capability.CapabilityManager;
import com.ur.urcap.api.domain.system.capability.CapabilityNotSupportedException;
import com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability;
import com.ur.urcap.api.domain.system.capability.tooliointerface.annotation.RequiredCapability;

import static com.ur.urcap.api.domain.resource.tooliointerface.CommunicationInterfaceConfig.Parity;
import static com.ur.urcap.api.domain.resource.tooliointerface.CommunicationInterfaceConfig.StopBits;
import static com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability.COMMUNICATION_INTERFACE_MODE;


/**
 * Factory for creating configurations of the analog input mode for the analog inputs in the connector in the robot tool.
 *
 * @since 1.7.0
 */
public interface AnalogInputModeConfigFactory {

	/**
	 * Create a configuration to set the electrical domain of the analog inputs in the connector in the robot tool
	 *
	 * @param input0 The electrical domain type for analog input 0 in the robot tool (labeled 'analog_in[2]' in PolyScope).
	 * @param input1 The electrical domain type for analog input 1 in the robot tool (labeled 'analog_in[3]' in PolyScope).
	 * @return The analog domain configuration for the analog tool inputs.
	 */
	AnalogInputDomainConfig createAnalogInputDomainConfig(AnalogDomain input0, AnalogDomain input1);

	/**
	 * <p>
	 * Create a Tool Communication Interface (TCI) configuration to enable communication with an external device via
	 * the analog inputs in the connector in the robot hereby avoiding external wiring. When this configuration is applied,
	 * all analog tool inputs will be unavailable.
	 * </p>
	 *
	 * Use {@link CapabilityManager#hasCapability(Capability)} with {@link ToolIOCapability#COMMUNICATION_INTERFACE_MODE}
	 * as argument to verify the availability of this functionality on the system.
	 *
	 * @param baudRate     The used baud rate. See {@link BaudRate} for the available options.
	 * @param parity       The used parity. See {@link Parity} for the available options.
	 * @param stopBits     The number of stop bits. See {@link StopBits} for the available options.
	 * @param rxIdleChars  Amount of chars the RX unit in the robot tool should wait before marking a message as over /
	 *                     sending it to the PC. Valid values: min=1.0 max=40.0.
	 * @param txIdleChars  Amount of chars the TX unit in the robot tool should wait before starting a new transmission
	 *                     since last activity on bus. Valid values: min=1.0 max=40.0.
	 * @return the Tool Communication Interface configuration for analog tool inputs.
	 * @throws IllegalArgumentException if an invalid value was specified for the {@code rxIdleChars} or
	 *                                  {@code txIdleChars} parameter.
	 * @throws CapabilityNotSupportedException If the Tool Communication Interface capability is not available on the 
	 *                                         system. Use {@link CapabilityManager#hasCapability(Capability)} with 
	 *                                         {@link ToolIOCapability#COMMUNICATION_INTERFACE_MODE} as argument to 
	 *                                         verify the availability.
	 */
	@RequiredCapability(COMMUNICATION_INTERFACE_MODE)
	CommunicationInterfaceConfig createCommunicationInterfaceConfig(BaudRate baudRate,
	                                                                Parity parity,
	                                                                StopBits stopBits,
	                                                                double rxIdleChars,
	                                                                double txIdleChars);
}
