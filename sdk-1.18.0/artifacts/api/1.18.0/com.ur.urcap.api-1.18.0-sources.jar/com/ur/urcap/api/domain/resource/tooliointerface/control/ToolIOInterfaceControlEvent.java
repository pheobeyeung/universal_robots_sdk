/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface.control;


/**
 * <p>
 * This interface holds information relevant to the {@link ToolIOInterfaceController#onControlGranted(ToolIOInterfaceControlEvent)}
 * and {@link ToolIOInterfaceController#onControlToBeRevoked(ToolIOInterfaceControlEvent)} events that occur when
 * the control of the Tool I/O Interface resource has been assigned to a URCap or when the control is about to be revoked,
 * respectively.
 * </p>
 *
 * This information includes access to the controllable resource instance.
 *
 * @since 1.7.0
 */
public interface ToolIOInterfaceControlEvent {

	/**
	 * @return The Tool I/O Interface resource instance that can be controlled exclusively.
	 */
	ToolIOInterfaceControllable getControllableResource();
}
