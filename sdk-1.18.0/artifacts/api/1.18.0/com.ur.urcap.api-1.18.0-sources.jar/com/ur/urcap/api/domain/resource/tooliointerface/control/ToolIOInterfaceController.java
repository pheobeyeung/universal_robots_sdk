/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.resource.tooliointerface.control;

import com.ur.urcap.api.domain.resource.ControllableResourceModel;


/**
 * <p>
 * This interface can be implemented to request control of the Tool I/O Interface.
 * </p>
 *
 * Pass the implementation of this interface to {@link ControllableResourceModel#requestControl(ToolIOInterfaceController)}
 * to request control of the Tool I/O Interface. If granted control by the end user, a callback will be made with a
 * {@link ToolIOInterfaceControlEvent} instance containing the resource.
 *
 * @since 1.7.0
 */
public interface ToolIOInterfaceController {

	/**
	 * This callback method is called when the control is assigned to this URCap by the end user.
	 *
	 * @param event This object holds information about the control granted event (containing the resource instance
	 *              which can now be controlled exclusively)
	 */
	void onControlGranted(ToolIOInterfaceControlEvent event);

	/**
	 * <p>
	 * This callback method is called when the control is about to be revoked.
	 * </p>
	 *
	 *
	 * <p>
	 * The control can be revoked in the following situations:
	 * <ul>
	 *     <li> The control is reassigned to a different URCap </li>
	 *     <li> Manual control for the end user is selected </li>
	 *     <li> A new installation is created </li>
	 *     <li> A different installation is loaded </li>
	 *     <li> The robot is shut down </li>
	 * </ul>
	 *</p>
	 *
	 * This controller still has control of the resource until exiting the scope of the method. This allows for a
	 * safe/graceful shutdown of attached devices while still in control of the resource.
	 *
	 * @param event This object holds information related to the control about to be revoked event (containing the
	 *              resource instance)
	 */
	void onControlToBeRevoked(ToolIOInterfaceControlEvent event);
}
