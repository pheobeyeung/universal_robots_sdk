/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.robot;

import com.ur.urcap.api.domain.value.Range;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Mass;


/**
 * <p>
 * This interface provides access to the limits of various physical/hardware and software properties/parameters of the
 * underlying Universal Robots robot. For each property/parameter, it is possible to get the valid range, such as the
 * supported range for the mass of the payload attached to the robot's tool output flange.
 * </p>
 *
 * These ranges (limits) can, for instance, be used for validation of input provided by the end user.
 *
 * @since 1.13.0
 */
public interface RobotLimits {

	/**
	 * <p>
	 * Get the range for the rated payload mass (attached to the robot's tool output flange) supported by the underlying
	 * robot, including the minimum and maximum supported values.
	 * </p>
	 *
	 * The minimum and maximum allowed values for the payload mass are accessible in the returned {@link Range} instance
	 * through {@link Range#getLowerBound()} and {@link Range#getUpperBound()}.
	 *
	 * @return The range for the rated payload mass supported by the underlying robot
	 */
	Range<Mass> getPayloadMassRange();

	/**
	 * <p>
	 * Get the range for the payload mass (attached to the robot's tool output flange) accepted in PolyScope. Note that
	 * part of this range includes values that exceed the rated maximum supported payload mass of the robot (see
	 * {@link #getPayloadMassRange()}), but these values are accepted by PolyScope. Using values above the rated maximum
	 * payload mass could affect performance of the robot.
	 *
	 * <p>
	 * The range returned by this method will have the same minimum value (lower bound) as the range returned by
	 * {@link #getPayloadMassRange()}, but the upper bound is the maximum allowed exceeded value for the payload mass.
	 * The minimum and maximum allowed values are accessible in the returned {@link Range} instance through
	 * {@link Range#getLowerBound()} and {@link Range#getUpperBound()}.
	 * <p>
	 *
	 * @return The exceeded range for the payload mass of the robot accepted by PolyScope
	 */
	Range<Mass> getPayloadMassExceededRange();

	/**
	 * <p>
	 * Get the supported range for the x-coordinate for the center of gravity (CoG) of a payload as defined by PolyScope.
	 * </p>
	 *
	 * The minimum and maximum allowed values are accessible in the returned {@link Range} instance through
	 * {@link Range#getLowerBound()} and {@link Range#getUpperBound()}.
	 *
	 * @return The valid range for the x-coordinate of the center of gravity (CoG) of a payload (i.e. the range of values
	 *         accepted in PolyScope).
	 */
	Range<Length> getCenterOfGravityXRange();

	/**
	 * <p>
	 * Get the supported range for the y-coordinate for the center of gravity (CoG) of a payload as defined by PolyScope.
	 * </p>
	 *
	 * The minimum and maximum allowed values are accessible in the returned {@link Range} instance through
	 * {@link Range#getLowerBound()} and {@link Range#getUpperBound()}.
	 *
	 * @return The valid range for the y-coordinate of the center of gravity (CoG) of a payload (i.e. the range of values
	 *         accepted in PolyScope).
	 */
	Range<Length> getCenterOfGravityYRange();

	/**
	 * <p>
	 * Get the supported range for the z-coordinate for the center of gravity (CoG) of a payload as defined by PolyScope.
	 * </p>
	 *
	 * The minimum and maximum allowed values are accessible in the returned {@link Range} instance through
	 * {@link Range#getLowerBound()} and {@link Range#getUpperBound()}.
	 *
	 * @return The valid range for the z-coordinate of the center of gravity (CoG) of a payload (i.e. the range of values
	 *         accepted in PolyScope).
	 */
	Range<Length> getCenterOfGravityZRange();
}
