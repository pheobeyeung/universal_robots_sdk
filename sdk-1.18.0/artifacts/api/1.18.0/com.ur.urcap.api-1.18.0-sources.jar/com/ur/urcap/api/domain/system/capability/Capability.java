/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */

package com.ur.urcap.api.domain.system.capability;

import com.ur.urcap.api.domain.system.capability.tooliointerface.ToolIOCapability;


/**
 * <p>
 * This marker interface represents a capability that may or may not be available on the underlying robot/system.
 * </p>
 *
 * <p>
 * A capability is a feature which may or may not be present on a given robot/system. The feature can be hardware-based or
 * software-based (e.g. certain types of program nodes). Some capabilities are not available on all robot platforms, e.g.
 * the Tool Communication Interface functionality is not present on CB3 robots.
 * </p>
 *
 * <p>
 * The specific system capabilities are defined as enums ({@code enum}) implementing this interface, e.g.
 * {@link ToolIOCapability}.
 * </p>
 *
 * <p>
 * Use {@link CapabilityManager#hasCapability(Capability)} to check if a capability is present on the system.
 * </p>
 *
 * @since 1.7.0
 */
public interface Capability {

}
