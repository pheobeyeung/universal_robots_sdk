/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.tcp;

import com.ur.urcap.api.domain.value.Pose;


/**
 * This interface represents a TCP in the installation in PolyScope. This can either be a user-defined TCP or a TCP
 * added by a URCap.
 *
 * @since 1.5.0
 */
public interface TCP {

	/**
	 * @return The offset of the TCP with respect to the tool output flange, if the TCP is resolvable, otherwise null.
	 */
	Pose getOffset();

	/**
	 * <p>
	 * Gets the name of the TCP displayed in the PolyScope UI.
	 * </p>
	 *
	 * <b>Note:</b> The TCP can change name at any time, and thus the name must not be used to uniquely identify a
	 * specific TCP. The TCP name can change in the following situations:
	 * <ul>
	 *      <li> The TCP is renamed by the end user </li>
	 *      <li> The name gets translated (depending on the selected language in PolyScope) </li>
	 *      <li> The name is changed between versions of the URCap that added the TCP</li>
	 * </ul>
	 *
	 * @return The name of the TCP displayed in PolyScope
	 */
	String getDisplayName();

	/**
	 * <p>
	 * A TCP cannot be guaranteed to be present in PolyScope. This method can be used to determine, if the TCP is
	 * present.
	 * </p>
	 *
	 * The TCP will not be present, if the end user loads a different installation which does not contain the TCP,
	 * or if the TCP is removed by the end user or the URCap that added the TCP.
	 *
	 * @return {@code true} if this TCP is present in PolyScope, otherwise {@code false}.
	 */
	boolean isResolvable();
}
