/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.tcp;

import com.ur.urcap.api.domain.value.Pose;


/**
 * <p>
 * This interface provides functionality for adding, updating and removing TCPs in PolyScope.
 * </p>
 *
 * <b>Note: </b> This interface must only be used in an installation contribution.
 *
 * @since 1.5.0
 */
public interface TCPContributionModel {

	/**
	 * <p>
	 * Add a TCP to the current PolyScope installation. 
	 * </p>
	 *
	 * This makes the TCP selectable by the end user as well as available to to other URCap contributions (through the
	 * {@link TCPModel} interface). The TCP is not modifiable by the end user or other URCaps.
	 *
	 * @param idKey The key to identify this TCP by, not {@code null} nor an empty string. The key is for this URCap only,
	 *              i.e. it only has to be unique for this URCap and not "globally" for other URCaps.
	 * @param suggestedName Suggested name for the TCP, not {@code null} nor an empty string. Valid names must match
	 *                      regex [a-zA-Z][a-zA-Z0-9_]{0,14} for a total of 15 characters. The final name can be retrieved
	 *                      from the returned TCP instance.
	 * @param offset The offset of the TCP with respect to the tool output flange, not {@code null}.
	 * @return The TCP created and registered in PolyScope.
	 * @throws TCPAlreadyAddedException If a TCP has previously been added using the same {@code idKey} identifier.
	 *                                  Use {@link #getTCP(String)} to check if the TCP has already been added to the
	 *                                  current installation.
	 *                                  Use {@link #updateTCP(String, Pose)} to update the TCP if the offset of the TCP
	 *                                  has changed.
	 * @throws IllegalTCPNameException If the suggested name does not match required regex.
	 * @throws IllegalArgumentException If any of the values of the pose specified for the TCP offset are not inside the
	 *                                  valid range of a TCP offset as defined by PolyScope.
	 */
	TCP addTCP(String idKey, String suggestedName, Pose offset);

	/**
	 * Returns the TCP previously added by this URCap using the same {@code idKey} identifier. Use this to verify if the
	 * TCP is present in the current installation.
	 *
	 * @param idKey The key to identify this TCP by, not {@code null} nor an empty string.
	 * @return The TCP previously added by this URCap.
	 *         Returns {@code null} if no TCP exists in current installation (with the specified {@code idKey} identifier).
	 */
	TCP getTCP(String idKey);

	/**
	 * Update the offset of an existing TCP added by this URCap.
	 *
	 * @param idKey The key to identify the TCP, not {@code null} nor an empty string. A TCP must have been added using
	 *              the same identifier key prior to calling this method.
	 * @param newOffset The new offset to set for the TCP with respect to the tool output flange, not {@code null}.
	 * @throws TCPNotFoundException If no TCP exists with the provided {@code idKey} identifier in the current installation.
	 * @throws IllegalArgumentException If any of the values of the pose specified for the TCP offset is not inside the
	 *                                  valid range of a TCP offset as defined by PolyScope.
	 */
	void updateTCP(String idKey, Pose newOffset);

	/**
	 * Remove a TCP added by this URCap from PolyScope. Program nodes using the TCP will be become undefined because the
	 * TCP is no longer resolvable.
	 *
	 * @param idKey The identifier key used to add the TCP with, not {@code null} nor an empty string.
	 * @throws TCPNotFoundException If no TCP exists with the provided {@code idKey} identifier in the current installation.
	 */
	void removeTCP(String idKey);
}
