/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.undoredo;


/**
 * <p>
 * This interface is used to record changes triggered by an end user in the screen of a URCap program node contribution
 * (e.g. when a button is clicked). It should be used in a URCap program node to support the Undo/Redo functionality in
 * PolyScope.
 * </p>
 *
 * <p>
 * NOTE: Do not use this functionality for URCap installation nodes, since it is not supported (and has no effect). <br>
 *
 * NOTE: This functionality is not relevant for URCap program nodes with a HTML-based user interface, since
 * automatic undo is supported for these.
 * </p>
 *
 * @since 1.3.0
 */
public interface UndoRedoManager {

	/**
	 * <p>
	 * Group changes into one Undo/Redo step.
	 * </p>
	 *
	 * Currently Undo/Redo supports changes to the program tree and the data model.
	 *
	 * @param undoableChanges Code to be recorded as one Undo/Redo step.
	 *                        Pressing Undo in PolyScope will undo all changes done to the program tree
	 *                        and the data model inside this block of code.
	 */
	void recordChanges(UndoableChanges undoableChanges);
}
