/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction;

import com.ur.urcap.api.domain.value.robotposition.PositionParameters;


/**
 * The robot position callback based on {@link PositionParameters} which composes several parameters defining a position
 * of the robot. Override this abstract class to execute custom code when the end user accepts or cancels a request for
 * defining a robot position.
 *
 * @since 1.10.0
 */
public abstract class RobotPositionCallback2 {

	/**
	 * This method is called if the end user accepts the robot position. Overriding this method is mandatory.
	 *
	 * @param parameters the parameters that define the robot position
	 */
	public abstract void onOk(PositionParameters parameters);

	/**
	 * This method is called if the end user cancels inputting the robot position. Overriding this method is optional.
	 */
	public void onCancel() {

	}
}
