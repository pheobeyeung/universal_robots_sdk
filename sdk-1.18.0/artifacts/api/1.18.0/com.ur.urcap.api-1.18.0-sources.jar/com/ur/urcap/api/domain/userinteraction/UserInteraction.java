/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction;

import com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidationFactory;
import com.ur.urcap.api.domain.userinteraction.keyboard.KeyboardInputFactory;
import com.ur.urcap.api.domain.userinteraction.robot.movement.RobotMovement;
import com.ur.urcap.api.domain.value.Pose;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import com.ur.urcap.api.domain.value.robotposition.PositionParameters;
import org.osgi.annotation.versioning.ProviderType;


/**
 * This interface provides functionality for requesting input or actions from end users
 *
 * @since 1.2.56
 */
@ProviderType
public interface UserInteraction {

	/**
	 * <p>
	 * Request the end user to use the robot to define a robot position. Override the
	 * {@link RobotPositionCallback2#onOk(PositionParameters)} method to execute code once the end user is done.
	 * Optionally override the {@link RobotPositionCallback2#onCancel()} method to execute code if the end user cancels
	 * the operation.
	 * </p>
	 *
	 * <p>
	 * This method is asynchronous, i.e. the method will return immediately. Only when the end user is done, either
	 * {@link RobotPositionCallback2#onOk(PositionParameters)} or {@link RobotPositionCallback2#onCancel()} will be called.
	 * </p>
	 *
	 * NOTE: This functionality should not be used in a toolbar contribution
	 * (see {@link com.ur.urcap.api.contribution.toolbar.swing.SwingToolbarService}).
	 *
	 * @param callback the instance callbacks will be made to.
	 *
	 * @since 1.10.0
	 */
	void getUserDefinedRobotPosition(RobotPositionCallback2 callback);

	/**
	 * <p>
	 * Request the end user to use the robot to define a robot position. Override the
	 * {@link RobotPositionCallback#onOk(Pose, JointPositions)} method to execute code once the end user is done.
	 * Optionally override the {@link RobotPositionCallback#onCancel()} method to execute code if the end user cancels
	 * the operation.
	 * </p>
	 *
	 * <p>
	 * This method is asynchronous, i.e. the method will return immediately. Only when the end user is done, either
	 * {@link RobotPositionCallback#onOk(Pose, JointPositions)} or {@link RobotPositionCallback#onCancel()} will be called.
	 * </p>
	 *
	 * NOTE: This functionality should not be used in a toolbar contribution
	 * (see {@link com.ur.urcap.api.contribution.toolbar.swing.SwingToolbarService}).
	 *
	 * @deprecated Use {@link #getUserDefinedRobotPosition(RobotPositionCallback2)} instead.
	 *
	 * @param callback the instance callbacks will be made to.
	 */
	@Deprecated
	void getUserDefinedRobotPosition(RobotPositionCallback callback);

	/**
	 *
	 * @return an interface providing means of requesting the end user to move the robot.
	 *
	 * @since 1.5.0
	 */
	RobotMovement getRobotMovement();

	/**
	 * <p>
	 * This method provides a factory for creating keyboard inputs which are used to configure a virtual keyboard/keypad
	 * and to request it to be displayed for a Swing GUI component.
	 * </p>
	 *
	 * NOTE: This functionality is only relevant for URCap nodes with a Swing-based user interface
	 * (see {@link com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService},
	 * {@link com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeService} and
	 * {@link com.ur.urcap.api.contribution.toolbar.swing.SwingToolbarService}).
	 *
	 * @return factory providing access to keyboard inputs.
	 *
	 * @since 1.3.0
	 */
	KeyboardInputFactory getKeyboardInputFactory();

	/**
	 * <p>
	 * This method provides a factory for creating standard input validators that can be used for configuring the virtual
	 * keyboard. The validators are used to validate the input entered by the user.
	 * </p>
	 *
	 * NOTE: This functionality is only relevant for URCap nodes with a Swing-based user interface
	 * (see {@link com.ur.urcap.api.contribution.program.swing.SwingProgramNodeService},
	 * {@link com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeService} and
	 * {@link com.ur.urcap.api.contribution.toolbar.swing.SwingToolbarService}).
	 *
	 * @return factory providing access to a set of standard input validators.
	 *
	 * @since 1.3.0
	 */
	InputValidationFactory getInputValidationFactory();
}
