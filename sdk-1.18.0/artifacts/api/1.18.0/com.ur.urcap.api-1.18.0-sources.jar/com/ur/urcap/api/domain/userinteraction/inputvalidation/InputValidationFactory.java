/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.inputvalidation;


/**
 * Factory for creating standard input validators that can be used for configuring the virtual
 * keyboard/keypad. The validators are used to validate the input entered by the user.
 *
 * @since 1.3.0
 */
public interface InputValidationFactory {

	/**
	 * <p>
	 * Creates a range validator for integers which can be used to ensure that input values are between a specified
	 * upper and lower boundary. This validator can be used for configuring the virtual numeric keypad.
	 * </p>
	 *
	 * When an invalid value is entered on the virtual keypad, the default PolyScope error message will be displayed
	 * informing the user of the specified valid value range.
	 *
	 * @param minValue the minimal valid value of the validation range.
	 * @param maxValue the maximal valid value of the validation range.
	 * @return new range validator for integers.
	 */
	InputValidator<Integer> createIntegerRangeValidator(int minValue, int maxValue);

	/**
	 * <p>
	 * Creates a range validator for doubles which can be used to ensure that input values are between a specified
	 * upper and lower boundary. This validator can be used for configuring the virtual numeric keypad.
	 * </p>
	 *
	 * When an invalid value is entered on the virtual keypad, the default PolyScope error message will be displayed
	 * informing the user of the specified valid value range.
	 *
	 * @param minValue the minimal valid value of the validation range.
	 * @param maxValue the maximal valid value of the validation range.
	 * @return new range validator for doubles.
	 */
	InputValidator<Double> createDoubleRangeValidator(double minValue, double maxValue);

	/**
	 * <p>
	 * Creates a validator which checks that the length of an input string is within the specified range. This validator
	 * can be used for configuring the virtual keyboard.
	 * </p>
	 *
	 * When a too short or too long string is entered on the virtual keyboard, the default PolyScope error message will
	 * be displayed informing the user of the specified string length requirement.
	 *
	 * @param minLength the minimal valid length of the input string.
	 * @param maxLength the maximal valid length of the input string.
	 * @return validator for string length.
	 */
	InputValidator<String> createStringLengthValidator(int minLength, int maxLength);
}
