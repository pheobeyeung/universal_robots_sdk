/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.keyboard;

import com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;


/**
 * Interface representing the virtual keyboard used for configuring it and requesting it to be displayed in PolyScope.
 *
 * @since 1.3.0
 */
public interface KeyboardTextInput {

	/**
	 * <p>
	 * Sets an input validator for the virtual keyboard. This validator will be used to validate the input entered
	 * by the user. Some standard validators are available in
	 * {@link com.ur.urcap.api.domain.userinteraction.inputvalidation.InputValidationFactory}.
	 * </p>
	 *
	 * <p>
	 * Specifying an input validator is recommended, but optional.
	 * </p>
	 *
	 * In case {@link InputValidator#isValid(Object)} (in this case parameter is {@link String}) returns {@code false}, the accept
	 * button on the virtual keyboard will be disabled and the error message from {@link InputValidator#getMessage(Object)}
	 * (parameter is {@link String}) will be shown.
	 *
	 * @param validator the validator to be used to validate keyboard user input.
	 * @return this KeyboardTextInput object.
	 * @throws NullPointerException in case the validator is {@code null}.
	 */
	KeyboardTextInput setErrorValidator(InputValidator<String> validator);

	/**
	 * Sets the text which will be displayed when the virtual keyboard is shown.
	 *
	 * @param initialText the initial text for the virtual keyboard.
	 * @return this KeyboardTextInput object.
	 */
	KeyboardTextInput setInitialValue(String initialText);

	/**
	 * This method requests the virtual keyboard to be shown.
	 *
	 * @param component the JTextField that will be used to define the screen position of the virtual keyboard.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the user exits the keyboard by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JTextField component, KeyboardInputCallback<String> callback);

	/**
	 * This method requests the virtual keypad to be shown.
	 *
	 * @param component the JLabel that will be used to define the screen position of the virtual keyboard.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the user exits the keyboard by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JLabel component, KeyboardInputCallback<String> callback);

	/**
	 * This method requests the virtual keypad to be shown.
	 *
	 * @param component the JButton that will be used to define the screen position of the virtual keyboard.
	 *                  The component must be visible on the screen at the time of showing the keypad.
	 * @param callback  the callback to be used when the user exits the keyboard by accepting or canceling the input.
	 * @throws NullPointerException in case any parameter is {@code null}.
	 */
	void show(JButton component, KeyboardInputCallback<String> callback);
}
