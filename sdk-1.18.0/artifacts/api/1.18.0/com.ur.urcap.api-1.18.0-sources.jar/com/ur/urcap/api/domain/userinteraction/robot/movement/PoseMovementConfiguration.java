/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.userinteraction.robot.movement;

import com.ur.urcap.api.domain.value.simple.Speed;
import org.osgi.annotation.versioning.ProviderType;

/**
 * This interface represents an object for requesting the user to move the robot to a certain position at an optional speed.
 *
 * @since 1.15.0
 */
@ProviderType
public interface PoseMovementConfiguration {
	/**
	 * <p>
	 * Set an optional speed that the robot should move at.
	 * <p>
	 * The requested speed will not be slower than 0.1 mm/s.
	 * The requested speed will not exceed the default speed.
	 * </p>
	 * <p>
	 * If the speed have not been set, the default speed will be applied.
	 * If a speed lower than 0.1 mm/s but not zero is provided, the speed will be set to 0.1 mm/s instead
	 * If a speed higher than the default is provided, the default speed will apply instead.
	 * If a speed of 0 is provided, an {@link IllegalArgumentException} will be thrown
	 * </p>
	 * </p>
	 *
	 * @param speed The speed that the robot should move at during auto move.
	 * @throws IllegalArgumentException if provided speed is 0, negative or ${@code null}
	 */
	void setSpeed(Speed speed);
}
