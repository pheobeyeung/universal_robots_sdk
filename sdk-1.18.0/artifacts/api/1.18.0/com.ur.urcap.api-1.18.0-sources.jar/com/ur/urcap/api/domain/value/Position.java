/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Length.Unit;


/**
 * This interface represents a Cartesian position.
 *
 * @since 1.0.0
 */
public interface Position {

	/**
	 * @deprecated Use {@link #getX(Length.Unit)} instead.
	 *
	 * @return X coordinate value in meters.
	 */
	@Deprecated
	double getX();

	/**
	 * @deprecated Use {@link #getY(Length.Unit)} instead.
	 *
	 * @return Y coordinate value in meters.
	 */
	@Deprecated
	double getY();

	/**
	 * @deprecated Use {@link #getZ(Length.Unit)} instead.
	 *
	 * @return Z coordinate value in meters.
	 */
	@Deprecated
	double getZ();

	/**
	 * Provides the X coordinate value in specified units.
	 *
	 * @param unit The length unit for which to return the X coordinate value
	 * @return The X coordinate value in specified units.
	 *
	 * @since 1.2.56
	 */
	double getX(Unit unit);

	/**
	 * Provides the Y coordinate value in specified units.
	 *
	 * @param unit The length unit for which to return the Y coordinate value
	 * @return The Y coordinate value in specified units.
	 *
	 * @since 1.2.56
	 */
	double getY(Unit unit);

	/**
	 * Provides the Z coordinate value in specified units.
	 *
	 * @param unit The length unit for which to return the Z coordinate value
	 * @return The Z coordinate value in specified units.
	 *
	 * @since 1.2.56
	 */
	double getZ(Unit unit);

	/**
	 * Indicates whether some other {@code Position} object is "approximately equal" to this one.
	 *
	 * @param other   Another {@code Position} object.
	 * @param epsilon The tolerance value to be used for the comparison of coordinate values (i.e. X, Y, Z) in specified
	 * 	              units
	 * @param unit    The length unit for the specified {@code epsilon} tolerance.
	 * @return {@code true} if the values of this object are "approximately equal" to the values of the {@code other}
	 *          argument; {@code false} otherwise.
	 *
	 * @since 1.2.56
	 */
	boolean epsilonEquals(Position other, double epsilon, Length.Unit unit);

	/**
	 * Indicates whether some other {@code Position} object is "equal to" this one.
	 *
	 * @param obj Another {@code Position} object.
	 * @return {@code true}, if the values of this {@code Position} instance and the {@code obj} argument are exactly the
	 *         same; otherwise {@code false}.
	 */
	boolean equals(Object obj);

	/**
	 * @return A hash code value for this object.
	 *
	 * @since 1.2.56
	 */
	int hashCode();

	/**
	 * @return A string representation of the position.
	 *
	 * @since 1.2.56
	 */
	String toString();
}
