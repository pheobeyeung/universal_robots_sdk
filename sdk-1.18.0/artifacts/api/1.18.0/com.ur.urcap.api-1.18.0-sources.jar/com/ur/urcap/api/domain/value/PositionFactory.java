/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.value.simple.Mass;


/**
 * <p>
 * Factory for creating positions in Cartesian space (relative to a reference coordinate system).
 * </p>
 *
 * The factory can, for example, be used to:
 * <ul>
 *     <li> Create a position to be used when constructing a pose with {@link PoseFactory#createPose(Position, Rotation)}.
 *     </li>
 *     <li> Create the center of gravity to be used when constructing a custom parameters configuration for a Set Payload
 *          node with
 *          {@link com.ur.urcap.api.domain.program.nodes.builtin.configurations.setpayloadnode.PayloadNodeConfigFactory#createCustomParametersConfig(Mass, Position)}.
 *     </li>
 *     <li> Create the center of gravity to be used when adding a payload to PolyScope or updating an existing payload
 *          with the {@link com.ur.urcap.api.domain.payload.PayloadContributionModel} interface (e.g. using the method
 *          {@link com.ur.urcap.api.domain.payload.PayloadContributionModel#addPayload(String, String, Mass, Position, InertiaMatrix)}).
 *     </li>
 * </ul>
 *
 * @since 1.13.0
 */
public interface PositionFactory {

	/**
	 * Creates an object representing a Cartesian position with the specified coordinates.
	 *
	 * @param x X coordinate of the Cartesian position
	 * @param y Y coordinate of the Cartesian position
	 * @param z Z coordinate of the Cartesian position
	 * @param lengthUnit Length unit for the specified coordinates
	 * @return A new Cartesian position
	 */
	Position createPosition(double x, double y, double z, Length.Unit lengthUnit);
}
