/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value;

import com.ur.urcap.api.domain.value.simple.Angle;

/**
 * <p>
 * Factory for creating a rotation vector specifying a Cartesian orientation.
 * </p>
 *
 * The factory can, for example, to be used when constructing a pose with
 * {@link PoseFactory#createPose(Position, Rotation)}
 *
 * @since 1.13.0
 */
public interface RotationFactory {

	/**
	 * Creates an object representing a rotation vector for a Cartesian orientation with the specified rotation
	 * parameters.
	 *
	 * @param rx Rx parameter of the rotation vector specifying the Cartesian orientation.
	 * @param ry Ry parameter of the rotation vector specifying the Cartesian orientation.
	 * @param rz Rz parameter of the rotation vector specifying the Cartesian orientation.
	 * @param angleUnit The angular unit for the specified rotation vector parameters.
	 * @return A new Cartesian rotation vector
	 */
	Rotation createRotation(double rx, double ry, double rz, Angle.Unit angleUnit);
}
