/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.blend;

import com.ur.urcap.api.domain.value.simple.Length;


/**
 * <p>
 * This interface can be used for creating blends.
 * </p>
 *
 * A blend can be used for configuration of various built-in program nodes, such as Waypoint nodes. It describes how the
 * robot can transition between trajectories (e.g. defined by waypoints).
 *
 * @since 1.2.56
 */
public interface BlendFactory {

	/**
	 * This method creates a blend with a given radius length.
	 *
	 * @param radiusLength the length of the radius for the blend.
	 * @return a new blend.
	 */
	Blend createBlend(Length radiusLength);
}
