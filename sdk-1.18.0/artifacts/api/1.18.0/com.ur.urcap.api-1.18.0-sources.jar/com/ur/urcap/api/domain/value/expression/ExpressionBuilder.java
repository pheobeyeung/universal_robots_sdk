/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.expression;

import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.program.nodes.builtin.WaypointNode;
import com.ur.urcap.api.domain.variable.Variable;


/**
 * <p>
 * This interface provides methods to build a single expression consisting of PolyScope entities, such as
 * variables, Features, I/Os and/or waypoints, as well as string parts. Each expression being built must use
 * a new {@code ExpressionBuilder} instance.
 * </p>
 *
 * To build an expression looking like, e.g. 'var_1 + var_2 + 5', use the following code snippet:
 *
 * <pre>
 * {@code
 * Expression expr = builder.appendVariable(var_1)
 *                          .append(" + ")
 *                          .appendVariable(var_2)
 *                          .append(" + 5")
 *                          .build();
 * }
 * </pre>
 *
 * The expression built will have information about the entities and their type (in the example the variables 'var_1' and
 * 'var_2'). Should the entities for some reason not be present, the expression can still be valid but will be undefined.
 * This can be the case for, e.g. installation variables, if a different installation is loaded or the end user has deleted
 * the variable. When the variable is present again, the expression will become defined.
 *
 * @since 1.2.56
 */
public interface ExpressionBuilder {

	/**
	 * Append a string part of the expression. This can be anything that is valid in an expression or even the full
	 * expression if it does not contain references to any entities (such as variables and features among others).
	 *
	 * @param expressionPart the expression part to be appended.
	 * @return the ExpressionBuilder
	 */
	ExpressionBuilder append(String expressionPart);

	/**
	 * Append a variable object to the expression.
	 *
	 * @param variable the variable to append.
	 * @return the ExpressionBuilder
	 */
	ExpressionBuilder appendVariable(Variable variable);

	/**
	 * Append a Feature object to the expression. When this part is evaluated the pose of the Feature is used.
	 *
	 * @param feature the Feature to append
	 * @return the ExpressionBuilder
	 */
	ExpressionBuilder appendFeature(Feature feature);

	/**
	 * Append a waypoint to the expression. When this part is evaluated the pose of the waypoint is used.
	 *
	 * @param waypoint the waypoint to append
	 * @return the ExpressionBuilder
	 */
	ExpressionBuilder appendWaypoint(WaypointNode waypoint);

	/**
	 * Append an I/O object to the expression.
	 *
	 * @param io the I/O to append.
	 * @return the ExpressionBuilder
	 */
	ExpressionBuilder appendIO(IO io);

	/**
	 * Build the expression consisting of all the appended parts.
	 *
	 * @return the expression
	 * @throws InvalidExpressionException if the expression is syntactically incorrect/invalid.
	 */
	Expression build() throws InvalidExpressionException;
}
