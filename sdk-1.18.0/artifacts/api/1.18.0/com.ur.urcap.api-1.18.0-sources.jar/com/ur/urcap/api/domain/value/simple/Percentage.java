/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.simple;



/**
 * <p>
 * This interface represents a percentage value.
 * </p>
 *
 * The percentage values can be created using the {@link SimpleValueFactory} interface.
 *
 * @since 1.17.0
 */
public interface Percentage {

	/**
	 * Provides the percentage value.
	 *
	 * @return {@code double} the percentage represented as a double value where 0.0 is 0% and 1.0 is 100%.
	 */
	double getValue();

	/**
	 * @return a hash code value for this object.
	 */
	int hashCode();

	/**
	 * Indicates whether some other {@code Percentage} object is "equal to" this one.
	 *
	 * @param obj another {@code Percentage} object.
	 * @return {@code true} if this object contains the same value as the {@code obj} argument; {@code false} otherwise.
	 */
	boolean equals(Object obj);

	/**
	 * @return a string representation of the percentage.
	 */
	String toString();
}
