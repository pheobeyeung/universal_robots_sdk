/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.value.simple;


/**
 * <p>
 * This interface represents pressure values.
 * </p>
 *
 * The pressure values can be created using the {@link SimpleValueFactory} interface.
 *
 * @since 1.6.0
 */
public interface Pressure {

	enum Unit {

		/**
		 *  Newton per square metre (Pascal) [Pa] SI unit.
		 */
		PA,

		/**
		 *  Kilo newton per square metre [kPa].
		 */
		KPA,

		/**
		 * Metric unit of pressure [mbar].
		 * */
		MBAR,

		/**
		 * Metric unit of pressure [bar].
		 * */
		BAR,

		/**
		 *  Standard atmosphere [atm].
		 */
		ATM,

		/**
		 *  Pounds per square inch [lbf/in²] imperial unit.
		 */
		PSI,

		/**
		 *  Inch of mercury at 32°F [inHg] imperial unit.
		 */
		INHG
	}

	/**
	 * Provides the value in specified units.
	 *
	 * @param unit the unit type.
	 * @return {@code double} value in the specified unit.
	 */
	double getAs(Unit unit);

	/**
	 * @return a hash code value for this object.
	 */
	int hashCode();

	/**
	 * Indicates whether some other {@code Pressure} object is "equal to" this one.
	 *
	 * @param obj another {@code Pressure} object.
	 * @return  {@code true} if this object contains the same value as the {@code obj} argument; {@code false} otherwise.
	 */
	boolean equals(Object obj);

	/**
	 * @return a string representation of the pressure.
	 */
	String toString();
}