/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.variable;

/**
 * @since 1.2.56
 */
public interface Variable {

	/**
	 * The variable type used to determine which type of variable this instance is.
	 */
	enum Type {

		/**
		 * <p>
		 * GLOBAL means that the variable is available everywhere in a program.
		 * </p>
		 *
		 * This variable instance can be cast to {@link GlobalVariable}.
		 */
		GLOBAL,

		/**
		 * <p>
		 * VALUE_PERSISTED means that the variable is stored with the installation. These variables are defined in the
		 * installation and will retain their values even when a robot is turned off and on.
		 * </p>
		 *
		 * This variable instance can be cast to {@link ValuePersistedVariable}.
		 */
		VALUE_PERSISTED,

		/**
		 * <p>
		 * FEATURE means that a Feature is marked as a variable. The variable is defined in the installation and will
		 * exist even when a robot is turned off and on.
		 * </p>
		 *
		 * This variable instance can be cast to {@link FeatureVariable}.
		 */
		FEATURE
	}

	/**
	 * @return the type of variable.
	 */
	Type getType();

	/**
	 * Note: The variable can be renamed at any time.
	 *
	 * @return the display name of the variable.
	 */
	String getDisplayName();

	/**
	 * @return true if object references the same internal Variable.
	 */
	boolean equals(Object object);

	/**
	 * @return hashCode for this object.
	 */
	int hashCode();

	/**
	 * @return a string representation of the variable.
	 */
	String toString();
}
