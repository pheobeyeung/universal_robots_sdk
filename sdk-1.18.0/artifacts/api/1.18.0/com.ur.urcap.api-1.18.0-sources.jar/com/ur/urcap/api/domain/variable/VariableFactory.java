/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.domain.variable;

import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.value.expression.Expression;


/**
 * <p>
 * This interface supplies methods to create variable objects.
 * </p>
 *
 * <b>NOTE:</b> Only use this functionality in a URCap program node (not relevant for an installation node).
 *
 * @since 1.2.56
 */
public interface VariableFactory {

	/**
	 * <p>
	 * Creates a global variable. Registering the variable in PolyScope (by storing it in a {@link DataModel} instance
	 * or using it for the configuration of a built-in PolyScope program node) will make it accessible to all program nodes.
	 * </p>
	 *
	 * <b>NOTE:</b> Only use this method in a URCap program node (not relevant for an installation node).
	 *
	 * @param suggestedName Suggested name of the variable. Valid names must match regex [a-zA-Z][a-zA-Z0-9_]{0,14} for
	 *                      a total of 15 characters.
	 *
	 * @return GlobalVariable.
	 * @throws VariableException In case of an illegal name.
	 */
	GlobalVariable createGlobalVariable(String suggestedName) throws VariableException;

	/**
	 * <p>
	 * Creates a global variable.
	 * </p>
	 *
	 * <p>
	 * Registering the variable in PolyScope (by storing it in a {@link DataModel} instance or using it for the
	 * configuration of a built-in PolyScope program node) will make it accessible to all program nodes.
	 * </p>
	 *
	 * <p>
	 * Setting an initial value will make it possible to read from the variable immediately without having to assign
	 * a value to it first. This can be useful in various constructs which requires an initial value, e.g.
	 * 'var_1 = var_1 + 1' or 'if (var_2 == 0):'.
	 * </p>
	 *
	 * <b>NOTE:</b> Only use this method in a URCap program node (not relevant for an installation node).
	 *
	 * @param suggestedName Suggested name of the variable. Valid names must match regex [a-zA-Z][a-zA-Z0-9_]{0,14} for
	 *                      a total of 15 characters.
	 * @param initialValue The expression that will be evaluated in order to initialize the value of the variable.
	 *                     This value is assigned before the actual program runs.
	 *
	 * @return GlobalVariable.
	 * @throws VariableException In case of an illegal name.
	 */
	GlobalVariable createGlobalVariable(String suggestedName, Expression initialValue) throws VariableException;
}
