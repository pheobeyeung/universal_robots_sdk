/**
 * This file is part of the URCap API that allows development of URCaps that extend
 * PolyScope with custom functionality.
 * The information herein is subject to change without notice and should not
 * be construed as a commitment by Universal Robots A/S. This API is periodically
 * reviewed and revised.
 *
 * Copyright (C) 2016-2025 by Universal Robots A/S.
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Universal Robots A/S and its suppliers, if any. The intellectual and technical
 * concepts contained herein are proprietary to Universal Robots A/S and its
 * suppliers and may be covered by U.S. and Foreign Patents, patents in process,
 * and are protected by trade secret or copyright law. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Universal Robots A/S.
 */
package com.ur.urcap.api.ui.component;


/**
 * <p>
 * Support for input events from UI component.
 * </p>
 *
 * NOTE: When also subscribing to {@link TouchEvent}, the ordering of events is not guaranteed.
 *
 * @since 1.0.0
 */
public interface InputEvent {

	/**
	 * ON_CHANGE -  an event of this type is issued when an input widgets changes state.
	 * For example: a check-box that goes from a checked state to an unchecked <br>
	 * ON_PRESSED -  an event of this type is issued on mouse/touchscreen pressed <br>
	 * ON_RELEASE -  an event of this type is issued when the mouse/touchscreen is released <br>
	 *
	 */
	enum EventType {
		ON_CHANGE,
		ON_PRESSED,
		ON_RELEASED
	}

	/**
	 *
	 * @return Get the type of event.
	 */
	EventType getEventType();

	/**
	 *
	 * @return The component that issued the event.
	 */
	HTMLComponent getComponent();
}
